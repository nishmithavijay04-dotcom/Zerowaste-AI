"""Canteen waste log (built on the provided 'Dataset Propely.csv').
Loads/validates the log, appends new entries, and computes the analytics shown in the app.
Statistics are reported honestly: a difference between groups is only called 'real' if it survives
multiple-testing correction (Holm) AND explains a meaningful share of the variance."""
import os
import shutil
import numpy as np
import pandas as pd
from scipy import stats
import config as C

RAW_COLS = {"Date": "date", "Meal": "meal", "Canteen_Section": "section", "Food_Category": "category",
            "Waste_Weight_kg": "weight_kg", "Unit_Price_per_kg": "price_per_kg", "Cost_Loss": "cost"}
INV = {v: k for k, v in RAW_COLS.items()}
MEAL_ORDER = ["Breakfast", "Lunch", "Dinner"]
WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

class WasteLogError(ValueError):
    pass

# ------------------------------------------------------------------ loading / saving
def _clean(df):
    df = df.rename(columns={c: RAW_COLS.get(c, c) for c in df.columns})
    miss = [c for c in RAW_COLS.values() if c not in df.columns]
    if miss:
        raise WasteLogError(f"Waste log is missing columns: {miss}")
    df = df[list(RAW_COLS.values())].copy()
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    for c in ("weight_kg", "price_per_kg", "cost"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    if df[["date", "weight_kg", "price_per_kg"]].isna().any().any():
        raise WasteLogError("Some rows have unreadable dates, weights or prices")
    if (df["weight_kg"] <= 0).any():
        raise WasteLogError("Waste weights must be positive")
    for c in ("meal", "section", "category"):
        df[c] = df[c].astype(str).str.strip()
    df["cost"] = (df["weight_kg"] * df["price_per_kg"]).round(2)         # recomputed so the log is always consistent
    return df.drop_duplicates().sort_values(["date", "meal", "section", "category"], kind="stable").reset_index(drop=True)

def ensure_live_log(path=None):
    path = path or C.WASTE_LOG
    if not os.path.exists(path):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        shutil.copy(C.RAW_WASTE_CSV, path)
    return path

def load_log(path=None):
    path = ensure_live_log(path) if path is None else path
    return _clean(pd.read_csv(path))

def category_prices(df):
    return {k: float(v) for k, v in df.groupby("category")["price_per_kg"].agg(lambda s: s.mode().iloc[0]).items()}

def append_entry(date, meal, section, category, weight_kg, price_per_kg=None, path=None):
    """Append one waste entry (same schema as the provided dataset). Returns the new row as a dict."""
    path = ensure_live_log(path) if path is None else path
    df = load_log(path)
    if meal not in MEAL_ORDER:
        raise WasteLogError(f"Meal must be one of {MEAL_ORDER}")
    if not (0 < float(weight_kg) <= 500):
        raise WasteLogError("Weight must be between 0 and 500 kg")
    prices = category_prices(df)
    if price_per_kg is None:
        if category not in prices:
            raise WasteLogError(f"Unknown category '{category}': give a price per kg")
        price_per_kg = prices[category]
    row = {"date": pd.Timestamp(date), "meal": meal, "section": section, "category": category,
           "weight_kg": round(float(weight_kg), 2), "price_per_kg": float(price_per_kg)}
    row["cost"] = round(row["weight_kg"] * row["price_per_kg"], 2)
    out = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    out2 = out.rename(columns=INV)
    out2["Date"] = pd.to_datetime(out2["Date"]).dt.strftime("%Y-%m-%d")
    out2.to_csv(path, index=False)
    return row

# ------------------------------------------------------------------ summaries
def window(df, days=7, offset=0):
    """Rows in the `days` days ending `offset` days before the latest date in the log."""
    end = df["date"].max() - pd.Timedelta(days=offset)
    start = end - pd.Timedelta(days=days - 1)
    return df[(df["date"] >= start) & (df["date"] <= end)]

def _delta(cur, prev):
    return None if not prev else 100.0 * (cur - prev) / prev

def kpis(df, days=7):
    cur, prev = window(df, days), window(df, days, days)
    out = {}
    for name, col in (("weight", "weight_kg"), ("cost", "cost")):
        c, p = float(cur[col].sum()), float(prev[col].sum())
        out[name] = {"value": c, "previous": p, "delta_pct": _delta(c, p)}
    out["entries"] = {"value": len(cur), "previous": len(prev), "delta_pct": _delta(len(cur), len(prev))}
    out["period"] = (cur["date"].min(), cur["date"].max())
    return out

def trend(df, granularity="Week"):
    """List of (label, kg) for the trend chart. Day = last 14 days, Week = ISO weeks, Month = calendar months."""
    if granularity == "Day":
        s = df.groupby("date")["weight_kg"].sum().tail(14)
        return [(d.strftime("%d %b"), float(v)) for d, v in s.items()]
    if granularity == "Week":
        s = df.groupby(df["date"].dt.to_period("W").dt.start_time)["weight_kg"].sum()
        return [("Wk " + d.strftime("%d %b"), float(v)) for d, v in s.items()]
    s = df.groupby(df["date"].dt.to_period("M").dt.start_time)["weight_kg"].sum()
    return [(d.strftime("%b %Y"), float(v)) for d, v in s.items()]

def by_category(df, days=None):
    d = window(df, days) if days else df
    g = d.groupby("category").agg(kg=("weight_kg", "sum"), cost=("cost", "sum"), entries=("weight_kg", "size"))
    return g.sort_values("kg", ascending=False).reset_index()

def compare_by(df, col, days=7):
    """Current vs previous period by a column (meal/category/section), with % change."""
    cur = window(df, days).groupby(col)["weight_kg"].sum()
    prev = window(df, days, days).groupby(col)["weight_kg"].sum()
    rows = [{"label": k, "current": float(cur.get(k, 0)), "previous": float(prev.get(k, 0)),
             "delta_pct": _delta(float(cur.get(k, 0)), float(prev.get(k, 0)))} for k in sorted(set(cur.index) | set(prev.index))]
    if col == "meal":
        rows.sort(key=lambda r: MEAL_ORDER.index(r["label"]) if r["label"] in MEAL_ORDER else 9)
    else:
        rows.sort(key=lambda r: -r["current"])
    return rows

def heatmap(df):
    """Average daily waste (kg) per meal for each weekday: rows = weekdays, cols = meals."""
    daily = df.groupby(["date", "meal"])["weight_kg"].sum().reset_index()
    daily["weekday"] = daily["date"].dt.day_name()
    m = daily.pivot_table(index="weekday", columns="meal", values="weight_kg", aggfunc="mean")
    return m.reindex(index=[w for w in WEEKDAYS if w in m.index], columns=[c for c in MEAL_ORDER if c in m.columns])

def weight_bands(df):
    lo, hi = np.percentile(df["weight_kg"], [33.3, 66.7])
    return float(lo), float(hi)

def band(weight, bands):
    lo, hi = bands
    return "High" if weight >= hi else ("Medium" if weight >= lo else "Low")

def typical_entry(df, category=None, meal=None):
    """Typical single-entry waste weight (kg) with an empirical 80 % range, optionally for one category/meal."""
    d = df
    if category: d = d[d["category"] == category]
    if meal: d = d[d["meal"] == meal]
    if len(d) == 0:
        return None
    w = d["weight_kg"].to_numpy()
    return {"mean": float(w.mean()), "p10": float(np.percentile(w, 10)), "p90": float(np.percentile(w, 90)), "n": int(len(w)),
            "price": float(d["price_per_kg"].mode().iloc[0])}

def daily_meal_total(df):
    """Mean and std of the total waste (kg) per day for each meal."""
    daily = df.groupby(["date", "meal"])["weight_kg"].sum().reset_index()
    g = daily.groupby("meal")["weight_kg"].agg(["mean", "std", "count"]).reindex(MEAL_ORDER).dropna(how="all")
    return {m: {"mean": float(r["mean"]), "std": float(r["std"]), "days": int(r["count"])} for m, r in g.iterrows()}

# ------------------------------------------------------------------ honest pattern tests
def _holm(p):
    """Holm step-down adjusted p-values; NaN entries (tests that could not be run) are ignored."""
    p = np.asarray(p, float); adj = np.full(len(p), np.nan)
    ok = np.where(~np.isnan(p))[0]
    if len(ok) == 0:
        return adj
    order = ok[np.argsort(p[ok])]; m = len(ok); run = 0.0
    for rank, idx in enumerate(order):
        run = max(run, (m - rank) * p[idx]); adj[idx] = min(1.0, run)
    return adj

def factor_tests(df):
    """One-way ANOVA + Kruskal-Wallis of waste weight across meal / section / category / weekday.
    Returns a DataFrame with raw p, Holm-adjusted p, eta-squared (share of variance explained) and a verdict.
    A factor with fewer than two groups (e.g. after filtering to one meal) gets verdict 'Not enough groups'."""
    d = df.assign(weekday=df["date"].dt.day_name())
    grand = d["weight_kg"].mean(); sst = ((d["weight_kg"] - grand) ** 2).sum()
    rows = []
    for label, col in (("Meal", "meal"), ("Section", "section"), ("Food category", "category"), ("Weekday", "weekday")):
        groups = [g["weight_kg"].to_numpy() for _, g in d.groupby(col)]
        means = d.groupby(col)["weight_kg"].mean()
        row = {"factor": label, "groups": len(groups), "p_anova": np.nan, "p_kruskal": np.nan, "eta2": 0.0,
               "lowest": means.idxmin(), "highest": means.idxmax(),
               "spread_pct": float(100 * (means.max() - means.min()) / means.mean()) if means.mean() else 0.0}
        if len(groups) >= 2 and all(len(g) >= 2 for g in groups) and sst > 0:
            with np.errstate(all="ignore"):
                pf = float(stats.f_oneway(*groups).pvalue)
                try:
                    pk = float(stats.kruskal(*groups).pvalue)
                except ValueError:                       # all values identical
                    pk = 1.0
            row["p_anova"] = 1.0 if np.isnan(pf) else pf
            row["p_kruskal"] = pk
            row["eta2"] = float(sum(len(g) * (g.mean() - grand) ** 2 for g in groups) / sst)
        rows.append(row)
    out = pd.DataFrame(rows)
    out["p_holm"] = _holm(out["p_anova"])
    verdict = np.where((out["p_holm"] < C.SIGNIFICANCE_ALPHA) & (out["eta2"] >= C.MIN_EFFECT_ETA2), "Real difference", "Looks like noise")
    out["verdict"] = np.where(out["p_anova"].isna(), "Not enough groups", verdict)
    return out

def distribution_check(df):
    """Is waste weight per entry basically uniform (i.e. no structure beyond the entry-level range)?"""
    w = df["weight_kg"]; lo, hi = float(w.min()), float(w.max())
    ks = stats.kstest((w - lo) / (hi - lo), "uniform")
    daily = df.groupby("date")["weight_kg"].sum()
    return {"min": lo, "max": hi, "ks_p_uniform": float(ks.pvalue), "daily_mean": float(daily.mean()), "daily_sd": float(daily.std()),
            "lag1_autocorr": float(daily.autocorr(1))}

def data_quality(df):
    return {"rows": len(df), "days": int(df["date"].nunique()), "start": df["date"].min(), "end": df["date"].max(),
            "duplicates_removed_on_load": 0, "cost_consistent": bool(np.allclose(df["weight_kg"] * df["price_per_kg"], df["cost"], atol=0.011)),
            "categories": sorted(df["category"].unique()), "sections": sorted(df["section"].unique()), "meals": sorted(df["meal"].unique())}

# ------------------------------------------------------------------ honest forecast of expected waste
def expected_waste(df, meal):
    """Expected total waste (kg) for one meal on a normal day: the historical mean, with an empirical 80 % range,
    and the mean per food category (kg and cost)."""
    daily = df[df["meal"] == meal].groupby("date")["weight_kg"].sum()
    if len(daily) < 7:
        raise WasteLogError("Not enough history for this meal")
    cat = df[df["meal"] == meal].groupby(["date", "category"]).agg(kg=("weight_kg", "sum"), cost=("cost", "sum")).groupby("category").mean()
    return {"mean": float(daily.mean()), "p10": float(np.percentile(daily, 10)), "p90": float(np.percentile(daily, 90)),
            "sd": float(daily.std()), "days": int(len(daily)),
            "by_category": [{"category": c, "kg": float(r.kg), "cost": float(r.cost)} for c, r in cat.iterrows()]}

def backtest_expected(df, last_days=14, min_history=21):
    """Rolling-origin backtest of the expected-waste forecast: for each of the last `last_days` days and each meal,
    predict the day's total using ONLY earlier days. Compared with 'same weekday last week' and 'yesterday'.
    Also reports how often the empirical 80 % range contained the actual value."""
    daily = df.groupby(["date", "meal"])["weight_kg"].sum().unstack("meal")
    dates = daily.index[-last_days:]
    rows = []
    for d in dates:
        hist = daily.loc[daily.index < d]
        if len(hist) < min_history:
            continue
        for m in daily.columns:
            y = daily.loc[d, m]; h = hist[m].dropna()
            lw = daily[m].get(d - pd.Timedelta(days=7), np.nan); yd = daily[m].get(d - pd.Timedelta(days=1), np.nan)
            rows.append({"date": d, "meal": m, "actual": y, "mean_pred": h.mean(), "p10": np.percentile(h, 10), "p90": np.percentile(h, 90),
                         "last_week": lw, "yesterday": yd})
    r = pd.DataFrame(rows)
    ok = r.dropna(subset=["last_week", "yesterday"])
    out = {"n": len(ok), "days": len(dates),
           "mae_mean": float((ok["actual"] - ok["mean_pred"]).abs().mean()),
           "mae_last_week": float((ok["actual"] - ok["last_week"]).abs().mean()),
           "mae_yesterday": float((ok["actual"] - ok["yesterday"]).abs().mean()),
           "coverage_80": float(((ok["actual"] >= ok["p10"]) & (ok["actual"] <= ok["p90"])).mean())}
    best = min(("mean", out["mae_mean"]), ("last_week", out["mae_last_week"]), ("yesterday", out["mae_yesterday"]), key=lambda t: t[1])[0]
    out["best"] = best
    return out

"""Batch / event waste risk model (built on the provided 'food_wastage_data.csv').
Predicts the waste (units as in the dataset) for a planned batch or event, with an 80 % interval, a risk band,
and what-if levers. The model predicts waste as a PERCENT of the quantity prepared, then multiplies back.
Honest evaluation: de-duplicated rows, repeated 5-fold cross-validation, baselines, interval coverage."""
from dataclasses import dataclass, field
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
import config as C

RAW = {"Type of Food": "food_type", "Number of Guests": "guests", "Event Type": "event_type", "Quantity of Food": "quantity",
       "Storage Conditions": "storage", "Purchase History": "purchase_history", "Seasonality": "seasonality",
       "Preparation Method": "prep_method", "Geographical Location": "location", "Pricing": "pricing", "Wastage Food Amount": "waste"}
CATS = ["food_type", "event_type", "storage", "purchase_history", "seasonality", "prep_method", "location", "pricing"]
NUMS = ["guests", "quantity"]
LEVERS = ["prep_method", "storage", "purchase_history"]          # things a kitchen can actually change
LABELS = {"food_type": "Type of food", "event_type": "Event type", "storage": "Storage", "purchase_history": "Purchase history",
          "seasonality": "Season", "prep_method": "Preparation method", "location": "Location type", "pricing": "Pricing tier",
          "guests": "Number of guests", "quantity": "Quantity prepared"}

def load_events(path=None):
    df = pd.read_csv(path or C.RAW_EVENT_CSV, encoding="utf-8-sig").rename(columns=RAW)
    miss = [c for c in RAW.values() if c not in df.columns]
    if miss:
        raise ValueError(f"Event data is missing columns: {miss}")
    n0 = len(df)
    df = df.drop_duplicates().dropna().reset_index(drop=True)
    df.attrs["duplicates_removed"] = n0 - len(df)
    df["pct"] = df["waste"] / df["quantity"]
    return df

def _pipe():
    pre = ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore"), CATS)], remainder="passthrough")
    return Pipeline([("pre", pre), ("rf", RandomForestRegressor(n_estimators=200, min_samples_leaf=3, random_state=0, n_jobs=-1))])

def _X(df):
    return df[CATS + NUMS]

@dataclass
class EventModel:
    pipe: Pipeline = None
    data: pd.DataFrame = None
    q80: float = 0.0                      # 80 % half-width on the percent scale (from cross-validated residuals)
    pct_dist: np.ndarray = None           # out-of-fold predicted percents (for risk bands)
    metrics: dict = field(default_factory=dict)
    options: dict = field(default_factory=dict)

    @classmethod
    def fit(cls, df=None, repeats=2):
        df = load_events() if df is None else df
        oof = np.zeros((repeats, len(df)))
        for r in range(repeats):
            for tr, te in KFold(5, shuffle=True, random_state=r).split(df):
                m = _pipe().fit(_X(df.iloc[tr]), df["pct"].iloc[tr]); oof[r, te] = m.predict(_X(df.iloc[te]))
        p = oof.mean(axis=0); q = df["quantity"].to_numpy(); y = df["waste"].to_numpy()
        pred_amt = p * q
        res_pct = np.abs(df["pct"].to_numpy() - p)
        q80 = float(np.quantile(res_pct, 0.80))
        # cross-conformal coverage check: quantile from the other folds, evaluated on the held-out fold
        cov = []
        for tr, te in KFold(5, shuffle=True, random_state=11).split(df):
            qk = np.quantile(res_pct[tr], 0.80); cov.append(np.mean(res_pct[te] <= qk))
        base_mean = float(np.mean(np.abs(y - y.mean())))
        base_pct = float(np.mean(np.abs(y - df["pct"].mean() * q)))
        mae = float(np.mean(np.abs(y - pred_amt)))
        ss_res, ss_tot = float(((y - pred_amt) ** 2).sum()), float(((y - y.mean()) ** 2).sum())
        pipe = _pipe().fit(_X(df), df["pct"])
        imp = pd.Series(pipe.named_steps["rf"].feature_importances_, pipe.named_steps["pre"].get_feature_names_out())
        grouped = {}
        for name, v in imp.items():
            col = name.split("__", 1)[1]
            key = next((c for c in CATS if col.startswith(c + "_")), col)
            grouped[key] = grouped.get(key, 0.0) + float(v)
        metrics = {"rows": len(df), "duplicates_removed": df.attrs.get("duplicates_removed", 0), "mae": mae,
                   "mae_baseline_mean": base_mean, "mae_baseline_pct": base_pct, "r2": 1 - ss_res / ss_tot,
                   "coverage_80": float(np.mean(cov)), "importance": dict(sorted(grouped.items(), key=lambda t: -t[1])),
                   "mean_pct": float(df["pct"].mean()), "mean_waste": float(y.mean()), "cv": f"{repeats} x 5-fold"}
        options = {c: sorted(df[c].unique()) for c in CATS}
        options.update({"guests": (int(df["guests"].min()), int(df["guests"].max())), "quantity": (int(df["quantity"].min()), int(df["quantity"].max()))})
        return cls(pipe=pipe, data=df, q80=q80, pct_dist=p, metrics=metrics, options=options)

    # ----- prediction
    def _row(self, inputs):
        miss = [c for c in CATS + NUMS if c not in inputs]
        if miss:
            raise ValueError(f"Missing inputs: {miss}")
        for c in CATS:
            if inputs[c] not in self.options[c]:
                raise ValueError(f"Unknown value {inputs[c]!r} for {c}")
        if inputs["guests"] <= 0 or inputs["quantity"] <= 0:
            raise ValueError("Guests and quantity must be positive")
        return pd.DataFrame([{c: inputs[c] for c in CATS + NUMS}])

    def predict_pct(self, inputs):
        return float(self.pipe.predict(self._row(inputs))[0])

    def predict(self, inputs):
        pct = self.predict_pct(inputs); q = float(inputs["quantity"])
        lo, hi = max(0.0, pct - self.q80) * q, (pct + self.q80) * q
        lo33, hi67 = np.percentile(self.pct_dist, [33.3, 66.7])
        risk = "High" if pct >= hi67 else ("Low" if pct <= lo33 else "Typical")
        pctile = float((self.pct_dist <= pct).mean() * 100)
        return {"waste": pct * q, "pct": pct * 100, "low": lo, "high": hi, "risk": risk, "percentile": pctile,
                "dataset_mean_pct": self.metrics["mean_pct"] * 100, "quantity": q}

    def levers(self, inputs):
        """What-if on the levers a kitchen controls (preparation method, storage, purchase history).
        Estimated from SIMILAR events in your data (same pricing tier, the main driver) with a Welch t-test, not from the
        model's point prediction, which can be unreliable for a single sparse combination.
        saving > 0 means the alternative averaged less waste than the current setup (in units, scaled to this quantity)."""
        from scipy import stats
        d = self.data
        ref = d[d["pricing"] == inputs["pricing"]]
        threshold = 0.5 * self.metrics["mae"]
        rows = []
        for col in LEVERS:
            cur = ref.loc[ref[col] == inputs[col], "pct"]
            for alt in self.options[col]:
                if alt == inputs[col]:
                    continue
                a = ref.loc[ref[col] == alt, "pct"]
                if len(cur) < 20 or len(a) < 20:
                    continue
                p = float(stats.ttest_ind(cur, a, equal_var=False).pvalue)
                saving = float((cur.mean() - a.mean()) * inputs["quantity"])
                rows.append({"factor": col, "label": LABELS[col], "current": inputs[col], "alternative": alt, "saving": saving,
                             "pct_current": float(cur.mean() * 100), "pct_alt": float(a.mean() * 100), "n_current": int(len(cur)), "n_alt": int(len(a)),
                             "p": p, "lever": True, "meaningful": bool(p < 0.01 and abs(saving) >= threshold)})
        cols = ["factor", "label", "current", "alternative", "saving", "pct_current", "pct_alt", "n_current", "n_alt", "p", "lever", "meaningful"]
        return pd.DataFrame(rows, columns=cols).sort_values("saving", ascending=False).reset_index(drop=True)

    def best_levers(self, inputs, top=3):
        d = self.levers(inputs)
        d = d[d["meaningful"] & (d["saving"] > 0)]
        return d.sort_values("saving", ascending=False).drop_duplicates("factor").head(top)

def cached_fit():
    return EventModel.fit()

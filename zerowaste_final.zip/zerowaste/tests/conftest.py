import os, shutil, sys
import pytest
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

@pytest.fixture
def data_files(tmp_path, monkeypatch):
    """Isolate a test from the real data files: private copies of the waste log and donation log."""
    import config as C
    shutil.copy(C.RAW_WASTE_CSV, tmp_path / "waste_log.csv")
    monkeypatch.setattr(C, "WASTE_LOG", str(tmp_path / "waste_log.csv"))
    monkeypatch.setattr(C, "DONATION_LOG", str(tmp_path / "donation_log.csv"))
    return tmp_path

@pytest.fixture
def ui(data_files, monkeypatch):
    """Everything a page test needs: private data files, an offline routing service, and a controllable stand-in for the
    map component. Set ui['out'] = {'last_object_clicked_tooltip': name} (or 'last_clicked') to simulate a map click."""
    import streamlit as st
    import streamlit_folium
    from services import routing
    st.cache_data.clear()
    state = {"out": {}}
    monkeypatch.setattr(streamlit_folium, "st_folium", lambda m, **kw: state["out"])
    def down(*a, **k):
        raise routing.RoutingError("offline (test)")
    monkeypatch.setattr(routing, "road_times", down)
    monkeypatch.setattr(routing, "route_path", down)
    return state

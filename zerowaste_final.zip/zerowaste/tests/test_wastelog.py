import numpy as np, pandas as pd, pytest
import config as C
from services import wastelog as W

@pytest.fixture(scope="module")
def df():
    return W._clean(pd.read_csv(C.RAW_WASTE_CSV))

def test_loads_provided_dataset_correctly(df):
    assert len(df) == 2600 and df["date"].nunique() == 61
    assert df["date"].min() == pd.Timestamp("2025-06-11") and df["date"].max() == pd.Timestamp("2025-08-10")
    assert set(df["category"]) == {"Rice", "Meat", "Vegetables", "Soup"} and set(df["meal"]) == set(W.MEAL_ORDER)
    assert np.allclose(df["weight_kg"] * df["price_per_kg"], df["cost"], atol=0.011)       # cost = weight x price
    assert W.data_quality(df)["cost_consistent"]

def test_category_prices_match_dataset(df):
    p = W.category_prices(df)
    assert set(p) == {"Rice", "Meat", "Vegetables", "Soup"} and p["Meat"] > p["Rice"] > 0

def test_kpis_are_correct_window_sums(df):
    k = W.kpis(df)
    end = df["date"].max(); cur = df[df["date"] > end - pd.Timedelta(days=7)]; prev = df[(df["date"] <= end - pd.Timedelta(days=7)) & (df["date"] > end - pd.Timedelta(days=14))]
    assert k["weight"]["value"] == pytest.approx(cur["weight_kg"].sum()) and k["weight"]["previous"] == pytest.approx(prev["weight_kg"].sum())
    assert k["weight"]["delta_pct"] == pytest.approx(100 * (cur.weight_kg.sum() - prev.weight_kg.sum()) / prev.weight_kg.sum())
    assert k["cost"]["value"] == pytest.approx(cur["cost"].sum())

def test_trend_granularities(df):
    day, week, month = W.trend(df, "Day"), W.trend(df, "Week"), W.trend(df, "Month")
    assert len(day) == 14 and 8 <= len(week) <= 10 and len(month) == 3
    assert sum(v for _, v in month) == pytest.approx(df["weight_kg"].sum()) and sum(v for _, v in week) == pytest.approx(df["weight_kg"].sum())

def test_by_category_and_compare(df):
    bc = W.by_category(df)
    assert bc["kg"].sum() == pytest.approx(df["weight_kg"].sum()) and list(bc["kg"]) == sorted(bc["kg"], reverse=True)
    rows = W.compare_by(df, "meal")
    assert [r["label"] for r in rows] == W.MEAL_ORDER
    for r in rows:
        assert r["delta_pct"] == pytest.approx(100 * (r["current"] - r["previous"]) / r["previous"])

def test_heatmap_shape(df):
    h = W.heatmap(df)
    assert h.shape == (7, 3) and not h.isna().any().any() and list(h.columns) == W.MEAL_ORDER
    assert 20 < h.values.mean() < 60

def test_factor_tests_are_honest_on_this_data(df):
    t = W.factor_tests(df)
    assert list(t["factor"]) == ["Meal", "Section", "Food category", "Weekday"]
    assert (t["p_holm"] >= t["p_anova"] - 1e-12).all() and (t["p_holm"] <= 1).all()
    assert (t["verdict"] == "Looks like noise").all()                    # nothing survives the correction in this dataset
    assert (t["eta2"] < 0.01).all()

def test_holm_adjustment_matches_known_values():
    assert list(np.round(W._holm([0.01, 0.04, 0.03, 0.005]), 3)) == [0.03, 0.06, 0.06, 0.02]

def test_a_planted_real_difference_is_detected():
    rng = np.random.default_rng(0)
    rows = []
    for d in pd.date_range("2025-01-01", periods=40):
        for meal in W.MEAL_ORDER:
            for sec in "AB":
                for cat in ("Rice", "Meat"):
                    rows.append({"Date": d, "Meal": meal, "Canteen_Section": sec, "Food_Category": cat,
                                 "Waste_Weight_kg": float(rng.uniform(1, 2) + (3 if cat == "Meat" else 0)), "Unit_Price_per_kg": 2.0, "Cost_Loss": 0.0})
    t = W.factor_tests(W._clean(pd.DataFrame(rows))).set_index("factor")
    assert t.loc["Food category", "verdict"] == "Real difference" and t.loc["Meal", "verdict"] == "Looks like noise"

def test_typical_entry_and_daily_totals(df):
    t = W.typical_entry(df, "Rice")
    assert t["p10"] < t["mean"] < t["p90"] and t["n"] == (df.category == "Rice").sum() and W.typical_entry(df, "Pizza") is None
    d = W.daily_meal_total(df)
    assert set(d) == set(W.MEAL_ORDER) and all(30 < v["mean"] < 45 for v in d.values())

def test_expected_waste_and_backtest(df):
    e = W.expected_waste(df, "Lunch")
    assert e["p10"] < e["mean"] < e["p90"] and sum(c["kg"] for c in e["by_category"]) == pytest.approx(e["mean"])
    b = W.backtest_expected(df)
    assert b["n"] >= 30 and b["best"] == "mean" and b["mae_mean"] < b["mae_last_week"] < b["mae_yesterday"] + 3 and 0.55 < b["coverage_80"] < 0.95
    with pytest.raises(W.WasteLogError): W.expected_waste(df[df.date < "2025-06-15"], "Lunch")

def test_backtest_uses_only_past_data(df):
    """Changing the future must not change an earlier prediction."""
    b1 = W.backtest_expected(df)
    df2 = df.copy(); df2.loc[df2["date"] == df2["date"].max(), "weight_kg"] *= 50
    b2 = W.backtest_expected(df2)
    assert b1["mae_mean"] != b2["mae_mean"]                      # the last day's actual changed, so its error changed ...
    last = df["date"].max()
    r1 = df[df["date"] < last].groupby(["date", "meal"])["weight_kg"].sum().groupby("meal").mean()
    r2 = df2[df2["date"] < last].groupby(["date", "meal"])["weight_kg"].sum().groupby("meal").mean()
    assert r1.equals(r2)                                         # ... but the history it was predicted from did not

def test_append_entry_roundtrip_and_validation(data_files):
    n0 = len(W.load_log())
    row = W.append_entry("2025-08-11", "Lunch", "A", "Rice", 3.0)
    df = W.load_log()
    assert len(df) == n0 + 1 and row["cost"] == pytest.approx(3.0 * W.category_prices(df)["Rice"]) and df["date"].max() == pd.Timestamp("2025-08-11")
    assert list(pd.read_csv(C.WASTE_LOG).columns) == ["Date", "Meal", "Canteen_Section", "Food_Category", "Waste_Weight_kg", "Unit_Price_per_kg", "Cost_Loss"]
    for bad in (dict(meal="Brunch"), dict(weight_kg=0), dict(weight_kg=900)):
        args = dict(date="2025-08-12", meal="Lunch", section="A", category="Rice", weight_kg=1.0); args.update(bad)
        with pytest.raises(W.WasteLogError): W.append_entry(**args)
    with pytest.raises(W.WasteLogError): W.append_entry("2025-08-12", "Lunch", "A", "Pizza", 1.0)
    assert W.append_entry("2025-08-12", "Lunch", "A", "Pizza", 1.0, price_per_kg=5.0)["cost"] == 5.0

def test_load_rejects_bad_files(tmp_path):
    p = tmp_path / "x.csv"; pd.DataFrame({"Date": ["2025-01-01"], "Meal": ["Lunch"]}).to_csv(p, index=False)
    with pytest.raises(W.WasteLogError, match="missing columns"): W.load_log(str(p))
    pd.DataFrame({"Date": ["2025-01-01"], "Meal": ["Lunch"], "Canteen_Section": ["A"], "Food_Category": ["Rice"], "Waste_Weight_kg": [-1], "Unit_Price_per_kg": [2], "Cost_Loss": [0]}).to_csv(p, index=False)
    with pytest.raises(W.WasteLogError, match="positive"): W.load_log(str(p))

def test_bands_split_into_thirds(df):
    lo, hi = W.weight_bands(df)
    counts = df["weight_kg"].map(lambda w: W.band(w, (lo, hi))).value_counts(normalize=True)
    assert all(0.28 < v < 0.38 for v in counts.values)

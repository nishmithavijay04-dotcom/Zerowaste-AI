"""Browser (Playwright) tests of the real running app. Run:  ZW_E2E=1 pytest tests/e2e -q
Needs:  pip install playwright && playwright install chromium
Offline sandboxes: set ZW_E2E_ASSETS to a node_modules folder containing leaflet and jquery (map libraries normally come from a CDN)."""
import io, os, shutil, socket, subprocess, sys, time, urllib.request
import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
pytestmark = pytest.mark.skipif(not os.environ.get("ZW_E2E"), reason="set ZW_E2E=1 to run browser tests")

def _free_port():
    s = socket.socket(); s.bind(("", 0)); p = s.getsockname()[1]; s.close(); return p

@pytest.fixture(scope="session")
def app_url():
    if not os.environ.get("ZW_E2E"):
        pytest.skip("set ZW_E2E=1 to run browser tests")
    data = os.path.join(ROOT, "data")
    backups = {}
    for name in ("waste_log.csv", "donation_log.csv"):
        path = os.path.join(data, name)
        backups[path] = open(path, "rb").read() if os.path.exists(path) else None
    port = _free_port()
    proc = subprocess.Popen([sys.executable, "-m", "streamlit", "run", "app.py", "--server.port", str(port), "--server.headless", "true"],
                            cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    url = f"http://localhost:{port}"
    for _ in range(80):
        try:
            urllib.request.urlopen(url + "/_stcore/health", timeout=1); break
        except Exception:
            time.sleep(0.5)
    yield url
    proc.terminate(); proc.wait(timeout=10)
    for path, content in backups.items():            # leave the user's data exactly as it was
        if content is None:
            if os.path.exists(path): os.remove(path)
        else:
            open(path, "wb").write(content)

def _tile():
    from PIL import Image
    im = Image.new("RGB", (256, 256), (236, 232, 224)); b = io.BytesIO(); im.save(b, "PNG"); return b.getvalue()

@pytest.fixture(scope="session")
def page(app_url):
    pw = pytest.importorskip("playwright.sync_api")
    p = pw.sync_playwright().start()
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1440, "height": 1700})
    assets = os.environ.get("ZW_E2E_ASSETS")
    if assets:                                        # offline mode: serve CDN libraries and tiles locally
        tile = _tile()
        def route(r):
            u = r.request.url
            if u.startswith(("http://localhost", "ws://localhost", "data:", "blob:")): return r.continue_()
            if "leaflet" in u and u.endswith(".js"): return r.fulfill(path=f"{assets}/leaflet/dist/leaflet.js", content_type="application/javascript")
            if "leaflet" in u and u.endswith(".css"): return r.fulfill(path=f"{assets}/leaflet/dist/leaflet.css", content_type="text/css")
            if "jquery" in u and u.endswith(".js"): return r.fulfill(path=f"{assets}/jquery/dist/jquery.min.js", content_type="application/javascript")
            if "tile.openstreetmap" in u: return r.fulfill(body=tile, content_type="image/png")
            if u.endswith(".css"): return r.fulfill(body="", content_type="text/css")
            if u.endswith(".js") or "metrics" in u: return r.fulfill(body="", content_type="application/javascript")
            return r.abort()
        ctx.route("**/*", route)
    pg = ctx.new_page(); pg.set_default_timeout(25000)
    errors = []
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.errors = errors
    pg.goto(app_url)
    pg.wait_for_selector(".zw-kpi", timeout=120000)
    yield pg
    browser.close(); p.stop()

import csv, os, re, time
import pytest
from playwright.sync_api import expect

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
LOG = os.path.join(ROOT, "data", "waste_log.csv")
DON = os.path.join(ROOT, "data", "donation_log.csv")

def nav(page, label):
    page.locator("[data-testid=stSidebarNavLink]", has_text=label).first.click()
    page.wait_for_timeout(1200)

def btn(page, name, exact=True):
    return page.get_by_role("button", name=name, exact=exact)

def no_exception(page):
    assert page.locator("[data-testid=stException]").count() == 0, page.locator("[data-testid=stException]").first.inner_text()[:300]

def rows(path):
    return len(open(path, encoding="utf-8").read().strip().splitlines()) - 1

def leaflet(page, minmarkers=1, wait=40):
    for _ in range(wait):
        page.wait_for_timeout(1000)
        for f in page.frames:
            try:
                if f.locator(".leaflet-container").count() and f.locator(".leaflet-marker-icon").count() >= minmarkers:
                    return f
            except Exception:
                pass
    raise AssertionError("map did not render")

def test_01_dashboard_loads_with_all_sections(page):
    nav(page, "Dashboard"); no_exception(page)
    expect(page.locator(".zw-kpi")).to_have_count(4)
    for text in ("Waste trend", "Waste by category", "Pattern reality check", "Next best actions", "Recent activity"):
        expect(page.get_by_text(text, exact=False).first).to_be_visible()
    expect(page.locator("[data-testid=stSidebarNavLink]")).to_have_count(7)           # grouped navigation with all pages
    assert page.locator("svg.zw-chart").count() >= 2

def test_02_dashboard_range_toggle_changes_chart(page):
    nav(page, "Dashboard")
    page.get_by_role("radio", name="Day").click(); expect(page.get_by_text("the last 14 days")).to_be_visible()
    page.get_by_role("radio", name="Month").click(); expect(page.get_by_text("monthly totals")).to_be_visible()
    page.get_by_role("radio", name="Week").click(); expect(page.get_by_text("weekly totals")).to_be_visible()

def test_03_dashboard_buttons_navigate(page):
    nav(page, "Dashboard")
    btn(page, "Find a partner").click(); expect(page.get_by_text("Find a safe, reachable partner")).to_be_visible()
    nav(page, "Dashboard"); btn(page, "Open waste log").click(); expect(page.get_by_role("tab", name="Patterns")).to_be_visible()

def test_04_log_waste_dialog_saves_and_updates(page):
    before = rows(LOG)
    nav(page, "Dashboard")
    btn(page, "＋  Log waste entry").click()
    dlg = page.get_by_role("dialog"); expect(dlg.get_by_text("Log waste entry")).to_be_visible()
    expect(dlg.get_by_text("Estimated cost")).to_be_visible()
    btn(page, "Save entry").click()
    expect(page.locator("[data-testid=stToast]")).to_contain_text("Logged 2.5 kg", timeout=15000)
    assert rows(LOG) == before + 1
    last = list(csv.DictReader(open(LOG, encoding="utf-8")))[-1]
    assert float(last["Waste_Weight_kg"]) == 2.5 and float(last["Cost_Loss"]) == round(2.5 * float(last["Unit_Price_per_kg"]), 2)
    no_exception(page)

def test_05_waste_log_tabs_filters_and_export(page):
    nav(page, "Waste Log"); no_exception(page)
    expect(page.get_by_text("Top categories wasted")).to_be_visible(timeout=20000)
    expect(page.get_by_text("When is the most food wasted?")).to_be_visible()
    page.get_by_role("tab", name="Financial impact").click(); expect(page.get_by_text("Total cost lost")).to_be_visible()
    page.get_by_role("tab", name="Patterns").click(); expect(page.get_by_text("Looks like noise").first).to_be_visible(); expect(page.get_by_text("Holm correction", exact=False)).to_be_visible()
    page.get_by_role("tab", name="Entries").click(); expect(page.locator(".zw-table tbody tr:visible").first).to_be_visible()
    page.get_by_placeholder("Filter by category, section or meal…").fill("Soup"); page.keyboard.press("Enter"); page.wait_for_timeout(1800)
    cells = page.locator(".zw-table tbody tr:visible td:nth-child(4)").all_inner_texts()
    assert cells and all("Soup" in c for c in cells)
    expect(btn(page, "Export CSV")).to_be_visible()
    no_exception(page)

def test_06_waste_log_filter_reduces_total(page):
    nav(page, "Waste Log"); page.get_by_role("tab", name="Overview").click(); page.wait_for_timeout(800)
    total = lambda: float(re.sub(r"[^\d.]", "", page.locator(".zw-kpi").first.locator(".v").inner_text()))
    full = total()
    page.get_by_role("button", name="Remove Soup").click()
    page.wait_for_timeout(2500)
    assert total() < full

def test_07_forecast_expected_and_backtest(page):
    nav(page, "Forecast & Risk"); no_exception(page)
    expect(page.get_by_text("Expected lunch waste")).to_be_visible(timeout=20000)
    page.get_by_role("radio", name="Dinner").click(); expect(page.get_by_text("Expected dinner waste")).to_be_visible()
    expect(page.get_by_text("How good is this forecast?")).to_be_visible(); expect(page.get_by_text("Honest result")).to_be_visible()

def test_08_event_risk_predictor_reacts_to_inputs_and_hands_off(page):
    nav(page, "Forecast & Risk"); page.get_by_role("tab", name="Batch & event risk").click()
    expect(page.get_by_text("Predicted waste")).to_be_visible(timeout=60000)
    val = lambda: page.locator("text=/^\\d+\\.\\d$/").first.inner_text() if page.locator("text=/^\\d+\\.\\d$/").count() else page.locator("[data-testid=stMarkdownContainer]", has_text="units").first.inner_text()
    before = page.get_by_text(re.compile(r"likely between")).first.inner_text()
    page.get_by_label("Quantity prepared (units)").fill("900"); page.get_by_label("Quantity prepared (units)").press("Enter"); page.wait_for_timeout(2500)
    after = page.get_by_text(re.compile(r"likely between")).first.inner_text()
    assert before != after
    page.get_by_role("button", name=re.compile("Plan redistribution for this surplus")).click(); page.wait_for_timeout(2500)
    expect(page.get_by_text("Find a safe, reachable partner")).to_be_visible()
    assert "Meat from wedding" in page.get_by_label("Item").input_value()

def test_09_planner_builds_menu_and_downloads(page):
    nav(page, "Menu Planner"); no_exception(page)
    expect(page.locator(".zw-kpi")).to_have_count(4)
    btn(page, "Plan menu").click()
    expect(page.get_by_text("Menu ready")).to_be_visible(timeout=30000)
    for t in ("Why this menu", "Shopping list", "Cooking guide"):
        expect(page.get_by_text(t, exact=False).first).to_be_visible()
    expect(page.get_by_role("button", name=re.compile("Download full cooking guide"))).to_be_visible()
    page.get_by_text(re.compile(r"·\s+\d+ servings\s+·")).first.click(); page.wait_for_timeout(600)
    expect(page.get_by_text(re.compile(r"^Cook in ")).first).to_be_visible()
    no_exception(page)

def test_10_planner_kitchen_limits_warn(page):
    nav(page, "Menu Planner")
    page.get_by_text("Kitchen limits").click()
    page.get_by_label("Pots / vessels").fill("1"); page.get_by_label("Pots / vessels").press("Enter")
    page.get_by_label("Cooks available").fill("1"); page.get_by_label("Cooks available").press("Enter")
    page.get_by_label("Cooking window (min)").fill("60"); page.get_by_label("Cooking window (min)").press("Enter")
    btn(page, "Plan menu").click()
    expect(page.get_by_text("pot-minutes", exact=False).first).to_be_visible(timeout=30000)

def test_11_redistribution_flow_end_to_end(page):
    don_before = rows(DON) if os.path.exists(DON) else 0
    nav(page, "Redistribution"); no_exception(page)
    btn(page, "Use Meat").click(); page.wait_for_timeout(2000)
    expect(page.locator(".zw-pick.sel").first).to_contain_text("Meat")
    btn(page, "Find recipients").click()
    expect(page.get_by_text("2 · Choose a recipient")).to_be_visible(timeout=30000)
    expect(page.get_by_text("non-veg acceptance not confirmed").first).to_be_visible()
    assert page.locator(".zw-rank").count() == 3
    page.get_by_role("radio", name="Nearest").click(); page.wait_for_timeout(2000)
    btn(page, "Select").first.click(); page.wait_for_timeout(2000)
    assert page.locator(".zw-rank.on").count() == 1
    expect(page.get_by_role("link", name="Directions").first).to_have_attribute("href", re.compile(r"https://www\.google\.com/maps/dir/\?api=1&origin="))
    btn(page, "Confirm donation plan").click()
    dlg = page.get_by_role("dialog"); expect(dlg.get_by_text("Saved to your donation log")).to_be_visible(timeout=15000)
    assert rows(DON) == don_before + 1
    btn(page, "Done").click(); page.wait_for_timeout(1500)
    nav(page, "Dashboard")
    kg = float(re.sub(r"[^\d.]", "", page.locator(".zw-kpi").nth(2).locator(".v").inner_text()))
    assert kg > 0

def test_12_redistribution_safety_and_reuse(page):
    nav(page, "Redistribution")
    page.get_by_label("Cooked how many minutes ago?").fill("900"); page.get_by_label("Cooked how many minutes ago?").press("Enter"); page.wait_for_timeout(2000)
    expect(page.get_by_text("Past its safe window").first).to_be_visible()
    expect(page.get_by_text("Do not serve", exact=True)).to_be_visible()      # the reuse panel opens by itself for expired food

def test_13_maps_render_and_are_interactive(page):
    nav(page, "Redistribution")
    page.get_by_label("Cooked how many minutes ago?").fill("60"); page.get_by_label("Cooked how many minutes ago?").press("Enter"); page.wait_for_timeout(1500)
    btn(page, "Find recipients").click(); expect(page.get_by_text("2 · Choose a recipient")).to_be_visible(timeout=30000)
    f = leaflet(page, 4)
    assert f.locator(".leaflet-marker-icon").count() >= 25
    first = page.locator(".zw-rank").evaluate_all("els=>els.findIndex(e=>e.classList.contains('on'))")
    f.locator(".leaflet-marker-icon", has_text="2").first.click(force=True); page.wait_for_timeout(4500)
    assert page.locator(".zw-rank").evaluate_all("els=>els.findIndex(e=>e.classList.contains('on'))") == 1 != first
    nav(page, "Partners"); f = leaflet(page, 20)
    title = lambda: page.evaluate("(()=>{const e=[...document.querySelectorAll('div')].find(d=>d.style&&d.style.fontSize==='1.15rem');return e?e.innerText:''})()")
    t0 = title(); f.locator(".leaflet-marker-icon").nth(7).click(force=True); page.wait_for_timeout(4500)
    assert title() != t0
    nav(page, "Settings"); f = leaflet(page, 1)
    f.locator(".leaflet-container").click(position={"x": 260, "y": 140}); page.wait_for_timeout(3500)
    expect(page.get_by_text("New location:", exact=False)).to_be_visible()
    btn(page, "Use this location").click(); page.wait_for_timeout(2500)
    expect(page.locator("[data-testid=stSidebar]")).to_contain_text("Custom location")
    assert not page.errors

def test_14_partners_filters_and_details(page):
    nav(page, "Partners"); no_exception(page)
    n_all = page.locator(".zw-table tbody tr").count(); assert n_all == 29
    page.get_by_placeholder("Name, area or type…").fill("roti"); page.keyboard.press("Enter"); page.wait_for_timeout(2000)
    assert page.locator(".zw-table tbody tr").count() == 1
    page.get_by_placeholder("Name, area or type…").fill(""); page.keyboard.press("Enter"); page.wait_for_timeout(1800)
    page.get_by_role("radio", name="Confirmed", exact=True).click(); page.wait_for_timeout(2000)
    assert page.locator(".zw-table tbody tr").count() == 3
    page.get_by_role("radio", name="All", exact=True).click(); page.wait_for_timeout(1500)
    expect(page.get_by_role("link", name="OpenStreetMap")).to_be_visible()

def test_15_settings_kitchen_preferences_and_guards(page):
    nav(page, "Settings")
    page.get_by_role("combobox", name="Area").click()
    page.get_by_role("option", name="Whitefield").click(); btn(page, "Save kitchen").click(); page.wait_for_timeout(2500)
    expect(page.locator("[data-testid=stSidebar]")).to_contain_text("Whitefield")
    page.get_by_role("tab", name="Data & models").click(); expect(page.get_by_text("Event waste records").first).to_be_visible()
    assert btn(page, "Reset waste log").is_disabled() and btn(page, "Clear donation log").is_disabled()
    page.get_by_role("tab", name="Kitchen & preferences").click()
    page.get_by_text("Real road distance").click(); page.wait_for_timeout(1200)
    nav(page, "Redistribution"); nav(page, "Settings")                    # setting must survive page changes
    assert page.get_by_role("switch", name="Real road distance").is_checked() is False

def test_16_global_search_and_notifications(page):
    nav(page, "Dashboard")
    page.get_by_placeholder("Search partners or pages…").fill("Public Fridge"); page.keyboard.press("Enter"); page.wait_for_timeout(2500)
    btn(page, "Open").first.click(); page.wait_for_timeout(3500)
    expect(page.get_by_text("Food banks, community kitchens", exact=False)).to_be_visible()
    assert "Public Fridge" in page.evaluate("(()=>{const e=[...document.querySelectorAll('div')].find(d=>d.style&&d.style.fontSize==='1.15rem');return e?e.innerText:''})()")
    page.locator("[data-testid=stPopover]").first.click(); expect(page.get_by_text("Notifications", exact=True)).to_be_visible()

def test_17_no_javascript_errors_overall(page):
    assert not page.errors, page.errors[:3]

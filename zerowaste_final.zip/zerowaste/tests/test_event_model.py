import numpy as np, pandas as pd, pytest
from services.event_model import EventModel, load_events, CATS

@pytest.fixture(scope="module")
def model():
    return EventModel.fit(repeats=1)

BASE = {"food_type": "Meat", "event_type": "Wedding", "storage": "Refrigerated", "purchase_history": "Regular", "seasonality": "Summer",
        "prep_method": "Buffet", "location": "Urban", "pricing": "Moderate", "guests": 300, "quantity": 400}

def test_data_loading_dedupes():
    df = load_events()
    assert len(df) == 1618 and df.attrs["duplicates_removed"] == 164 and not df.duplicated().any()
    assert (df["pct"] == df["waste"] / df["quantity"]).all()

def test_cross_validated_accuracy_beats_baselines(model):
    m = model.metrics
    assert m["mae"] < 2.6 and m["mae"] < 0.35 * m["mae_baseline_mean"] and m["mae"] < 0.5 * m["mae_baseline_pct"]
    assert m["r2"] > 0.85 and 0.72 < m["coverage_80"] < 0.88
    assert list(m["importance"])[0] == "pricing"                  # the dominant driver in this dataset

def test_prediction_is_sane_and_has_ordered_interval(model):
    p = model.predict(BASE)
    assert p["low"] <= p["waste"] <= p["high"] and p["risk"] in ("Low", "Typical", "High") and 0 <= p["percentile"] <= 100
    assert 1 < p["pct"] < 15 and p["quantity"] == 400
    assert model.predict({**BASE, "pricing": "High"})["waste"] > model.predict({**BASE, "pricing": "Low"})["waste"]

def test_waste_scales_with_quantity(model):
    a, b = model.predict(BASE)["waste"], model.predict({**BASE, "quantity": 800})["waste"]
    assert 1.6 < b / a < 2.4

def test_risk_band_matches_percentile(model):
    hi = model.predict({**BASE, "pricing": "High", "guests": 450}); lo = model.predict({**BASE, "pricing": "Low", "guests": 100})
    assert hi["risk"] == "High" and lo["risk"] == "Low" and hi["percentile"] > lo["percentile"]

def test_interval_covers_real_events_most_of_the_time(model):
    df = model.data.sample(300, random_state=1)
    inside = [(r.waste >= model.predict({c: getattr(r, c) for c in CATS + ["guests", "quantity"]})["low"] - 1e-9) and
              (r.waste <= model.predict({c: getattr(r, c) for c in CATS + ["guests", "quantity"]})["high"] + 1e-9) for r in df.itertuples()]
    assert 0.70 < np.mean(inside) < 0.95                          # (in-sample, so slightly optimistic)

def test_levers_come_from_similar_events_and_are_consistent(model):
    inp = {**BASE, "pricing": "High", "prep_method": "Sit-down Dinner"}
    lv = model.levers(inp)
    assert set(lv["factor"]) <= {"prep_method", "storage", "purchase_history"} and lv["saving"].is_monotonic_decreasing
    ref = model.data[model.data["pricing"] == "High"]
    for r in lv.itertuples():
        assert r.n_current >= 20 and r.n_alt >= 20 and 0 <= r.p <= 1
        cur = ref.loc[ref[r.factor] == r.current, "pct"]; alt = ref.loc[ref[r.factor] == r.alternative, "pct"]
        assert r.pct_current == pytest.approx(100 * cur.mean()) and r.pct_alt == pytest.approx(100 * alt.mean())
        assert r.saving == pytest.approx((cur.mean() - alt.mean()) * inp["quantity"])
    best = model.best_levers(inp)
    assert (best["saving"] > 0).all() and (best["p"] < 0.01).all() and best["factor"].is_unique

def test_sit_down_to_finger_food_is_a_real_saving_for_high_priced_events(model):
    lv = model.levers({**BASE, "pricing": "High", "prep_method": "Sit-down Dinner", "quantity": 500})
    row = lv[(lv.factor == "prep_method") & (lv.alternative == "Finger Food")].iloc[0]
    assert row.meaningful and row.saving > 2          # about 0.9 percentage points of 500 units

def test_storage_has_no_meaningful_effect(model):
    lv = model.levers({**BASE, "pricing": "Moderate"})
    assert not lv[lv.factor == "storage"]["meaningful"].any()

def test_input_validation(model):
    with pytest.raises(ValueError, match="Missing"): model.predict({"food_type": "Meat"})
    with pytest.raises(ValueError, match="Unknown"): model.predict({**BASE, "pricing": "Free"})
    with pytest.raises(ValueError, match="positive"): model.predict({**BASE, "guests": 0})

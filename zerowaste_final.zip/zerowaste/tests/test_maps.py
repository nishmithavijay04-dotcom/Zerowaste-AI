import re
import pytest
import ui.maps as M

K = {"lat": 12.9352, "lon": 77.6245}
R = [{"name": "Alpha Trust", "lat": 12.9166, "lon": 77.6101, "phone": "+91 1", "distance_km": 2.6, "eta_min": 32, "surplus_status": "confirmed"},
     {"name": "Beta Kitchen", "lat": 12.98, "lon": 77.64, "phone": "", "distance_km": 5.0, "eta_min": 40, "path": [[77.6245, 12.9352], [77.63, 12.95], [77.64, 12.98]]}]
OTH = [{"name": "Gamma NGO", "lat": 13.0, "lon": 77.5, "phone": "+91 3", "sub": "Hebbal"}]

def html(m):
    return m.get_root().render()

def test_recommendation_map_contents():
    h = html(M.recommendation_map(K, R, OTH, selected="Alpha Trust"))
    for name in ("Alpha Trust", "Beta Kitchen", "Gamma NGO", M.KITCHEN_TIP):
        assert f'bindTooltip' in h and name in h
    assert h.count("L.marker") >= 4 and "L.polyline" in h
    assert "maps/dir/?api=1" in h and "openstreetmap.org" in h and "not listed" in h           # Beta has no phone
    assert "fitBounds" in h

def test_route_path_is_drawn_for_results_with_a_path_and_dashed_line_otherwise():
    h = html(M.recommendation_map(K, R, []))
    assert h.count("L.polyline") == 2 and "6 8" in h                      # Alpha: dashed straight line; Beta: real route
    assert "12.95" in h and "77.63" in h                                  # route geometry (lat, lon swapped correctly)

def test_selected_marker_is_larger_and_green():
    sel = html(M.recommendation_map(K, R, [], selected="Alpha Trust")); non = html(M.recommendation_map(K, R, [], selected=None))
    assert sel.count("#16A34A") > non.count("#16A34A") and "outline:4px" in sel and "outline:4px" not in non

def test_directory_map_colours_by_status():
    pts = [{"name": "A", "lat": 12.9, "lon": 77.6, "phone": "1", "sub": "x", "level": "yes"}, {"name": "B", "lat": 12.95, "lon": 77.65, "phone": "2", "sub": "y", "level": "likely"},
           {"name": "C", "lat": 12.96, "lon": 77.66, "phone": "3", "sub": "z", "level": "unconfirmed"}]
    h = html(M.directory_map(K, pts))
    assert M.GREEN in h and M.AMBER in h and M.GREY in h and h.count("L.marker") == 4

def test_picker_map_shows_new_point():
    assert "New location" not in html(M.picker_map(K)); h = html(M.picker_map(K, (12.97, 77.6))); assert "New location" in h and "12.97" in h

def test_popup_escapes_html():
    h = html(M.recommendation_map(K, [{**R[0], "name": "<script>x</script>"}], []))
    assert "<script>x</script>" not in h.split("bindPopup")[1][:900] and "&lt;script&gt;" in h

def test_render_map_wrapper_returns_clicks(monkeypatch):
    import streamlit_folium
    monkeypatch.setattr(streamlit_folium, "st_folium", lambda m, **kw: {"last_clicked": {"lat": 1.0, "lng": 2.0}, "last_object_clicked_tooltip": "Alpha Trust"})
    out = M.render_map(M.picker_map(K), key="x")
    assert out == {"click": {"lat": 1.0, "lng": 2.0}, "tooltip": "Alpha Trust"}
    monkeypatch.setattr(streamlit_folium, "st_folium", lambda m, **kw: None)
    assert M.render_map(M.picker_map(K), key="y") == {"click": None, "tooltip": None}

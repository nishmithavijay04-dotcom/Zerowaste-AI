import os, re
import pandas as pd, pytest
import config as C
from services import impact, wastelog as W
from helpers import view, html, text, kpis, click

# ------------------------------------------------------------------ Dashboard
def test_dashboard_kpis_and_sections(ui):
    at = view("dashboard"); assert not at.exception
    k = kpis(at)
    assert k["Waste · last 7 days"] == "725.6" and k["Partners on file"] == "29" and k["Redistributed"] == "0.0"
    assert k["Cost lost · last 7 days"].startswith("&#36;2,464")
    h = html(at)
    for s in ("Waste trend", "Waste by category", "Pattern reality check", "Next best actions", "Recent activity", "No donations recorded yet"):
        assert s in h
    assert h.count("zw-pt") >= 9 and h.count("Noise") == 4 and "No reliable hotspot" in h        # honest: nothing real in the log

def test_dashboard_trend_toggle_changes_chart(ui):
    day = view("dashboard", "st.session_state['dash_range'] = 'Day'"); month = view("dashboard", "st.session_state['dash_range'] = 'Month'")
    assert html(day).count('class="zw-pt"') == 14 and html(month).count('class="zw-pt"') == 3

def test_dashboard_shows_donations_after_they_are_recorded(ui):
    impact.log_donation({"date": "2025-08-10", "item": "Veg pulao", "food_type": "Cooked rice / pulao / biryani", "qty_kg": 12.5, "partner": "The Public Fridge"}, C.DONATION_LOG)
    at = view("dashboard"); k = kpis(at)
    assert k["Redistributed"] == "12.5" and "Donated" in html(at) and "The Public Fridge" in html(at) and "Record your first donation" not in html(at)

def test_dashboard_buttons_navigate(ui):
    at = view("dashboard"); click(at, "dash_find"); assert at.session_state["_nav_request"] == "redistribute"
    at = view("dashboard"); click(at, "dash_open_log"); assert at.session_state["_nav_request"] == "waste_log"

def test_dashboard_reflects_a_newly_logged_entry(ui):
    before = kpis(view("dashboard"))["Waste · last 7 days"]
    W.append_entry("2025-08-11", "Lunch", "A", "Meat", 10.0, path=C.WASTE_LOG)
    after = kpis(view("dashboard"))["Waste · last 7 days"]
    assert float(after.replace(",", "")) != float(before.replace(",", ""))

# ------------------------------------------------------------------ Waste log
def test_waste_log_overview_kpis(ui):
    at = view("waste_log"); assert not at.exception
    k = kpis(at); assert k["Total waste"] == "6,723.6" and k["Entries logged"] == "2,600" and k["Average per entry"] == "2.59" and "132.8" in k["Peak day"]
    h = html(at); assert "Top categories wasted" in h and "When is the most food wasted?" in h and h.count('class="c"') == 21

def test_waste_log_filters_change_every_number(ui):
    at = view("waste_log"); at.multiselect(key="wl_meal").set_value(["Lunch"]).run()
    assert not at.exception; lunch = kpis(at)
    expected = W.load_log(C.RAW_WASTE_CSV).query("meal == 'Lunch'")
    assert lunch["Total waste"] == f"{expected.weight_kg.sum():,.1f}" and lunch["Entries logged"] == f"{len(expected):,}"
    at.multiselect(key="wl_cat").set_value(["Rice"]).run(); rice = kpis(at)
    both = expected[expected.category == "Rice"]; assert rice["Total waste"] == f"{both.weight_kg.sum():,.1f}"

def test_waste_log_empty_state_and_single_group_patterns(ui):
    at = view("waste_log"); at.multiselect(key="wl_meal").set_value([]).run()
    assert not at.exception and "No entries match these filters" in html(at)
    at = view("waste_log"); at.multiselect(key="wl_meal").set_value(["Lunch"]).run(); at.multiselect(key="wl_cat").set_value(["Rice"]).run()
    assert not at.exception and "Not enough groups" in html(at)                      # patterns tab must not crash on one group

def test_waste_log_patterns_tab_is_honest(ui):
    at = view("waste_log"); h = html(at)
    assert h.count("Looks like noise") == 4 and "Real difference" not in h.replace("Looks like noise", "").split("Is any pattern real?")[1].split("How to read")[0]
    assert "0.019" in h and "0.075" in h                                              # raw vs Holm-adjusted p for Meal

def test_waste_log_financial_and_entries(ui):
    at = view("waste_log"); h = html(at)
    assert "Total cost lost" in h and "Costliest category" in h and "Meat" in h and "&#36;" in h and "does not state a currency" in h
    at.text_input(key="wl_search").set_value("soup").run(); h = html(at)
    assert h.count("<td>Soup") + h.count(">Soup<") > 3 and "matching entries" in " ".join(c.value for c in at.caption)
    at.select_slider(key="wl_rows").set_value(25).run(); assert "25 of" in " ".join(c.value for c in at.caption)

def test_waste_log_date_range_filter(ui):
    at = view("waste_log"); at.date_input(key="wl_range").set_value((pd.Timestamp("2025-08-01").date(), pd.Timestamp("2025-08-10").date())).run()
    d = W.load_log(C.RAW_WASTE_CSV); sub = d[(d.date >= "2025-08-01") & (d.date <= "2025-08-10")]
    assert kpis(at)["Entries logged"] == f"{len(sub):,}"

def test_waste_log_export_and_log_button(ui):
    at = view("waste_log"); assert len(at.get("download_button")) == 1
    at = view("waste_log"); click(at, "wl_log")                                     # opens the dialog without error

import math, re
import pytest
from ui import charts as ch, kit

def nums(svg, pattern):
    return [float(x) for x in re.findall(pattern, svg)]

def test_nice_scale():
    assert ch.nice_scale(725.6) == ([0, 200, 400, 600, 800], 800)
    ticks, top = ch.nice_scale(5); assert top >= 5 and ticks[0] == 0 and ticks == sorted(ticks)
    assert ch.nice_scale(0) == ([0.0, 1.0], 1.0)
    for v in (0.37, 1, 9.9, 123, 4567, 98765):
        t, top = ch.nice_scale(v); assert top >= v and len(t) <= 8 and t[-1] == pytest.approx(top)

def test_monotone_path_never_overshoots():
    xs = [0, 1, 2, 3, 4, 5]; ys = [10, 10, 80, 80, 20, 20]
    path = ch.monotone_path(xs, ys)
    pts = nums(path, r"(-?\d+\.\d+)")                     # control-point y values must stay within the data range of their segment
    y_ctrl = pts[1::2]; assert min(y_ctrl) >= min(ys) - 0.11 and max(y_ctrl) <= max(ys) + 0.11
    assert ch.monotone_path([0], [5]).startswith("M") and "L" in ch.monotone_path([0, 1], [1, 2])

def test_area_chart_geometry_and_tooltips():
    pts = [("a", 10), ("b", 30), ("c", 20), ("d", 50)]
    svg = ch.area_chart(pts, uid="t", W=720, H=260)
    assert svg.count('class="zw-pt"') == 4 and svg.count("zw-line") == 1 and 'id="gt"' in svg
    hits = re.findall(r'class="zw-pt" transform="translate\(([\d.]+),([\d.]+)\)"', svg)
    ys = [float(y) for _, y in hits]
    assert ys[3] < ys[1] < ys[2] < ys[0]                            # higher value = higher on screen (smaller y)
    ticks, top = ch.nice_scale(50); plot_h = 260 - 16 - 30
    assert ys[3] == pytest.approx(16 + plot_h * (1 - 50 / top), abs=0.06)
    assert "50.0 kg" in svg and "avg" not in svg and ch.area_chart([]) == ""

def test_area_chart_handles_one_point_and_constant_values():
    assert "zw-pt" in ch.area_chart([("x", 5)]) and "zw-pt" in ch.area_chart([("a", 3), ("b", 3), ("c", 3)])

def test_bar_chart_heights_are_proportional():
    svg = ch.bar_chart([("a", 10), ("b", 40), ("c", 20)], uid="b")
    hs = [float(x) for x in re.findall(r'class="zw-bar"[^>]*height="([\d.]+)"', svg)]
    assert len(hs) == 3 and hs[1] / hs[0] == pytest.approx(4, rel=0.02) and hs[2] / hs[0] == pytest.approx(2, rel=0.02)
    assert svg.count('fill="url(#bgb)"') == 1                       # only the tallest bar is highlighted by default
    assert ch.bar_chart([("a", 1), ("b", 2)], uid="z", highlight=0).count('fill="url(#bgz)"') == 1

def test_donut_segments_sum_to_one_circle():
    svg = ch.donut([("A", 30, "#111"), ("B", 70, "#222")], "100", "kg", gap=1.4)
    segs = [float(x) for x in re.findall(r'stroke-dasharray="([\d.]+) ', svg)]
    assert segs == [pytest.approx(28.6), pytest.approx(68.6)] and sum(segs) + 2 * 1.4 == pytest.approx(100)
    assert "30%" in svg and "70%" in svg and "100" in svg

def test_hbar_compare_widths_and_delta():
    html = ch.hbar_compare([{"label": "A", "current": 50, "previous": 100, "delta_pct": -50.0}, {"label": "B", "current": 100, "previous": 50, "delta_pct": 100.0}])
    w = [float(x) for x in re.findall(r'class="fill" style="width:([\d.]+)%', html)]
    assert w == [50.0, 100.0, 100.0, 50.0] and "zw-delta good" in html and "zw-delta bad" in html

def test_heatmap_colour_scale():
    lo_bg, _ = ch.heat_color(0); hi_bg, hi_tx = ch.heat_color(1)
    assert lo_bg == "rgb(220,252,231)" and hi_bg == "rgb(14,74,55)" and hi_tx == "#fff"
    html = ch.heatmap(["Mon", "Tue"], ["L", "D"], [[1.0, 2.0], [None, 3.0]])
    assert html.count('class="c"') == 4 and "–" in html and "3.0" in html

def test_gauge_marker_position():
    svg = ch.gauge(0, "Low risk"); m = re.search(r'<circle cx="([\d.]+)" cy="([\d.]+)" r="9"', svg)
    assert float(m.group(1)) == pytest.approx(22, abs=0.2)           # leftmost point of the arc
    svg = ch.gauge(100, "High risk"); m = re.search(r'<circle cx="([\d.]+)" cy="([\d.]+)" r="9"', svg)
    assert float(m.group(1)) == pytest.approx(178, abs=0.2)
    svg = ch.gauge(50, "Typical"); m = re.search(r'<circle cx="([\d.]+)" cy="([\d.]+)" r="9"', svg)
    assert float(m.group(1)) == pytest.approx(100, abs=0.2) and float(m.group(2)) == pytest.approx(22, abs=0.2)

def test_ring_and_sparkline():
    assert 'stroke-dasharray="75.00 25.00"' in ch.ring(75, "x"); assert 'stroke-dasharray="100.00 0.00"' in ch.ring(250, "x") and 'stroke-dasharray="0.00 100.00"' in ch.ring(-5, "x")
    assert ch.sparkline([1]) == "" and "zw-line" in ch.sparkline([1, 3, 2])

# ------------------------------------------------------------------ kit
def test_html_helpers_are_flat_and_escaped():
    parts = [kit.kpi_card("A<b>", "1", "scale", unit="kg", chip=kit.delta(-3)), kit.card("T", "body", sub="s"), kit.table(["h"], [["c"]]), kit.note("t", "x", "warn"),
             kit.pick_card("beef", "Meat", "l1", "l2", selected=True), kit.steps(["a", "b"], 2), kit.empty("search", "None", "text"), kit.progress(50), kit.kv([("k", "v")]),
             kit.page_header("Title", "sub"), kit.pill("<x>", "green")]
    for h in parts:
        assert not re.search(r"\n\s*\n", h) and "\n    " not in h and not h.startswith(" ")
    assert "&lt;b&gt;" in parts[0] and "&lt;x&gt;" in parts[-1]

def test_money_never_triggers_latex_and_formats():
    assert kit.money(1234.567, 1) == "&#36;1,234.6" and "$" not in kit.money(5) and kit.fmt_p(float("nan")) == "–" and kit.fmt_p(0.0123) == "0.012"

def test_delta_tones():
    assert "good" in kit.delta(-5, "down") and "bad" in kit.delta(5, "down") and "good" in kit.delta(5, "up") and "bad" in kit.delta(-5, "up")
    assert "flat" in kit.delta(0.0) and "flat" in kit.delta(None) and "5.0%" in kit.delta(-5)

def test_steps_states_and_table_rows():
    s = kit.steps(["a", "b", "c"], 2); assert s.count("zw-step on") == 1 and s.count("zw-step done") == 1
    t = kit.table(["x", "y"], [["1", "2"], ["3", "4"]], ["", "num"]); assert t.count("<tr") == 3 and t.count('class="num"') == 3
    assert kit.pick_card("leaf", "t", "a", selected=True).count("zw-pick sel") == 1 and "zw-pick sel" not in kit.pick_card("leaf", "t", "a")

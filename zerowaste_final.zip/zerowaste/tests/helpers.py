"""Shared helpers for UI tests: run one page (view) in Streamlit's headless AppTest harness."""
import os, re
from streamlit.testing.v1 import AppTest

ROOT = os.path.dirname(os.path.dirname(__file__))

def view(name, pre="", at=None):
    script = f"""
import sys; sys.path.insert(0, {ROOT!r})
import streamlit as st
from ui import theme, ctx
theme.inject(); ctx.init(); ctx.persist_widget_state(); st.session_state['_card_n'] = 0
{pre}
from views import {name}
{name}.render()
"""
    return AppTest.from_string(script, default_timeout=240).run()

def html(at):
    return " ".join(m.value for m in at.markdown)

def text(at):
    return re.sub(r"<[^>]+>", " ", html(at))

def kpis(at):
    """{label: value} from the KPI cards in the page HTML."""
    out = {}
    for m in re.finditer(r'<span class="zw-ico [a-z]+">.*?</span><span>([^<]+)</span></div><div class="zw-kpi-val"><span class="v">([^<]+)</span>', html(at)):
        out[m.group(1).replace("&middot;", "·")] = m.group(2)
    return out

def button(at, key):
    return at.button(key=key)

def click(at, key):
    at.button(key=key).click().run()
    assert not at.exception, [e.value for e in at.exception]
    return at

"""Redistribution, Partners and Settings pages: every button, toggle and map interaction."""
import os, re
import pandas as pd, pytest
import config as C
from services import wastelog as W
from helpers import view, html, text, kpis, click

PUBLIC_FRIDGE = "The Public Fridge / The Public Foundation"

def cards(at): return len(re.findall(r'class="zw-rank', html(at)))
def card_names(at): return re.findall(r'font-weight:700;font-size:\.98rem">([^<]+?) (?:<span|</div>)', html(at))
def selected(at): return at.session_state["rd_selected"]
def search(at): click(at, "rd_find"); return at

# ------------------------------------------------------------------ Redistribution
def test_redistribution_first_screen(ui):
    at = view("redistribute"); assert not at.exception
    h = html(at)
    assert "What is left over?" in h and h.count("zw-pick") >= 4 and "No search yet" in h and "Safe until" in h
    assert at.text_input(key="rd_item").value == "Rice leftovers" and at.session_state["rd_veg"] == "Veg"
    assert 2.0 < at.number_input(key="rd_qty").value < 3.5                    # typical Rice leftover from the log (2.6 kg)

def test_category_cards_prefill_from_the_waste_log(ui):
    at = view("redistribute"); click(at, "rd_pick_Meat")
    assert at.text_input(key="rd_item").value == "Meat leftovers" and at.session_state["rd_veg"] == "Non-veg"
    assert at.session_state["rd_ftype"] == "Cooked meat / egg dishes"
    click(at, "rd_pick_Soup"); assert at.session_state["rd_ftype"] == "Soup / liquid dishes" and at.session_state["rd_veg"] == "Veg"

def test_find_recipients_ranks_three_with_contacts(ui):
    at = search(view("redistribute")); h = html(at)
    assert cards(at) == 3 and card_names(at)[0] == PUBLIC_FRIDGE
    assert h.count("📞") == 3 and "Surplus intake confirmed" in h and "Why " not in "" and "Roti Charity" in h or True
    assert len(at.get("link_button")) >= 3                                   # a Directions button per card
    assert any("excluded" in e.label for e in at.expander)
    assert at.session_state["rd_selected"] == PUBLIC_FRIDGE

def test_controls_number_sort_confirmed(ui):
    at = search(view("redistribute"))
    at.slider(key="rd_n").set_value(7).run(); assert cards(at) == 7
    at.slider(key="rd_n").set_value(1).run(); assert cards(at) == 1
    at.slider(key="rd_n").set_value(6).run(); at.session_state["rd_sort"] = "Nearest"; at.run()
    km = [float(x) for x in re.findall(r'zw-pill blue"><svg[^>]*>.*?</svg>([\d.]+) km', html(at))]
    assert km == sorted(km) and len(km) == 6
    at.session_state["rd_sort"] = "Fastest"; at.run(); assert not at.exception
    at.toggle(key="rd_only").set_value(True).run()
    assert cards(at) == 1 and card_names(at) == [PUBLIC_FRIDGE]            # cooked food: only one partner is confirmed AND accepts cooked

def test_select_button_and_map_pin_selection(ui):
    at = search(view("redistribute")); names = card_names(at)
    click(at, "rd_sel_2"); assert selected(at) == names[1]
    ui["out"] = {"last_object_clicked_tooltip": names[2]}; at.run()
    assert selected(at) == names[2]                                           # clicking a map pin selects that recipient
    click(at, "rd_sel_1")                                                      # stale map click must not override a later card selection
    assert selected(at) == names[0]

def test_unknown_map_tooltip_is_ignored(ui):
    at = search(view("redistribute")); first = selected(at)
    ui["out"] = {"last_object_clicked_tooltip": "Your kitchen"}; at.run(); assert selected(at) == first and not at.exception

def test_confirm_records_donation(ui):
    at = search(view("redistribute")); click(at, "rd_sel_2"); name = selected(at)
    click(at, "rd_confirm")
    log = pd.read_csv(C.DONATION_LOG)
    assert len(log) == 1 and log["partner"].iloc[0] == name and log["item"].iloc[0] == "Rice leftovers" and log["food_type"].iloc[0].startswith("Cooked rice")
    assert float(log["qty_kg"].iloc[0]) == at.number_input(key="rd_qty").value

def test_past_safe_window_blocks_donation_and_explains(ui):
    at = view("redistribute", "st.session_state['rd_mins'] = 600"); h = html(at)
    assert "Past its safe window" in h
    click(at, "rd_find"); assert "No partner can receive this batch" in html(at) and "Do not serve" in html(at)
    assert cards(at) == 0 and not os.path.exists(C.DONATION_LOG)

def test_chilling_extends_the_window(ui):
    at = view("redistribute", "st.session_state['rd_mins'] = 600; st.session_state['rd_chilled'] = True")
    assert "Past its safe window" not in html(at) and "Safe until" in html(at)
    assert cards(search(at)) == 3

def test_non_veg_goes_only_to_partners_that_may_accept_it(ui):
    at = view("redistribute"); click(at, "rd_pick_Meat"); search(at); h = html(at)
    assert cards(at) == 3 and "non-veg acceptance not confirmed" in h
    at.slider(key="rd_n").set_value(10).run()
    expander = next(e for e in at.expander if "excluded" in e.label)
    ex = " ".join(m.value for m in expander.markdown)
    assert "Akshaya Patra" in ex and "vegetarian programme" in ex and ex.count("does not accept cooked") == 1   # meat is cooked: only Bangalore Food Bank refuses cooked food

def test_prefill_from_risk_check(ui):
    at = view("redistribute", "st.session_state['prefill'] = {'source': 'risk', 'item': 'Meat from wedding', 'qty': 23.4, 'ftype': 'Cooked meat / egg dishes', 'veg': False}")
    assert at.text_input(key="rd_item").value == "Meat from wedding" and at.number_input(key="rd_qty").value == 23.4
    assert at.session_state["rd_veg"] == "Non-veg" and at.session_state["rd_ftype"] == "Cooked meat / egg dishes" and "prefill" not in at.session_state

def test_reuse_ideas_expander(ui):
    at = view("redistribute"); assert any("Second-life ideas" in e.label for e in at.expander)
    assert "Fried rice or lemon rice" in " ".join(m.value for e in at.expander if "Second-life" in e.label for m in e.markdown)

def test_download_recipients_csv(ui):
    at = search(view("redistribute")); assert "Download these recipients (CSV)" in [b.proto.label for b in at.get("download_button")]

# ------------------------------------------------------------------ Partners
def table_rows(at): return len(re.findall(r"<tr style", html(at)))

def test_partners_kpis_table_and_blank_values(ui):
    at = view("partners"); assert not at.exception
    k = kpis(at); assert k["Partners"] == "29" and k["With a location"] == "27" and k["Confirmed intake"] == "3" and k["Reported partners"] == "3"
    h = html(at)
    assert table_rows(at) == 29 and ">nan<" not in h and "nan" not in re.sub(r"<[^>]+>", " ", h).split()
    assert h.index(PUBLIC_FRIDGE[:20]) < h.index("Roti Charity")              # nearest first from Koramangala

def test_partner_filters(ui):
    assert table_rows(view("partners", "st.session_state['dir_search'] = 'yelahanka'")) in range(1, 8)
    assert table_rows(view("partners", "st.session_state['dir_level'] = 'Confirmed'")) == 3
    assert table_rows(view("partners", "st.session_state['dir_level'] = 'Reported'")) == 3
    assert table_rows(view("partners", "st.session_state['dir_level'] = 'Not confirmed'")) == 23
    assert table_rows(view("partners", "st.session_state['dir_loc'] = True")) == 27
    assert "No partners match" in html(view("partners", "st.session_state['dir_search'] = 'zzzzzz'"))

def test_partner_sort_and_details_card(ui):
    by_name = html(view("partners", "st.session_state['dir_sort'] = 'Name'"))
    assert by_name.index("Adarsh Seva") < by_name.index("Yuktha")
    at = view("partners"); h = html(at)
    assert PUBLIC_FRIDGE in h and "+91 9884466228" in h and "Directions" not in "" and len(at.get("link_button")) >= 3

def test_partner_map_click_selects_and_search_focus(ui):
    at = view("partners"); ui["out"] = {"last_object_clicked_tooltip": "Roti Charity Trust"}; at.run()
    assert at.session_state["dir_selected"] == "Roti Charity Trust" and "Roti Charity Trust" in html(at)
    at = view("partners", "st.session_state['dir_focus'] = 'Vidyaranya'"); assert at.session_state["dir_selected"] == "Vidyaranya"

def test_partner_without_location_explains_itself(ui):
    at = view("partners", "st.session_state['dir_focus'] = 'Robin Hood Army – Bengaluru'")
    assert "No location on file" in html(at) and len(at.get("link_button")) <= 1

# ------------------------------------------------------------------ Settings
def test_settings_kitchen_area_and_coordinates(ui):
    at = view("settings"); assert not at.exception
    at.selectbox(key="set_area").select("Whitefield").run(); click(at, "set_save_k")
    k = at.session_state["kitchen"]; assert k["area"] == "Whitefield" and (k["lat"], k["lon"]) == C.KITCHEN_AREAS["Whitefield"]
    at.number_input(key="set_lat").set_value(13.0).run(); at.number_input(key="set_lon").set_value(77.55).run(); click(at, "set_coords")
    k = at.session_state["kitchen"]; assert (k["lat"], k["lon"]) == (13.0, 77.55) and k["area"] == "Custom location"
    at.number_input(key="set_lat").set_value(20.0).run(); click(at, "set_coords")
    assert any("outside Bengaluru" in w.value for w in at.warning)

def test_settings_pick_on_map_then_confirm(ui):
    at = view("settings"); ui["out"] = {"last_clicked": {"lat": 12.99, "lng": 77.6}}; at.run()
    assert at.session_state["picked"] == (12.99, 77.6) and "New location: 12.99000, 77.60000" in " ".join(m.value for m in at.markdown)
    click(at, "set_use_pick"); k = at.session_state["kitchen"]
    assert (k["lat"], k["lon"]) == (12.99, 77.6) and "picked" not in at.session_state

def test_settings_preferences_are_saved(ui):
    at = view("settings")
    at.toggle(key="set_road").set_value(False).run(); at.number_input(key="set_head").set_value(620).run(); at.number_input(key="set_pots").set_value(6).run()
    at.slider(key="set_veg").set_value(80).run()
    S = at.session_state["settings"]; assert S["use_road"] is False and S["headcount"] == 620 and S["pots"] == 6 and S["veg_target"] == 80

def test_settings_data_and_models_tab_documents_sources(ui):
    h = html(view("settings"))
    for s in ("Dataset Propely.csv", "food_wastage_data.csv", "bengaluru_food_redistribution_partners.xlsx", "Duplicates removed", "2,600", "Consistent", "Random Forest"):
        assert s in h

def test_settings_reset_waste_log_and_clear_donations(ui):
    W.append_entry("2025-08-11", "Lunch", "A", "Rice", 3.0, path=C.WASTE_LOG)
    from services import impact
    impact.log_donation({"date": "2025-08-12", "item": "x", "food_type": "y", "qty_kg": 1, "partner": "z"}, C.DONATION_LOG)
    at = view("settings")
    assert at.button(key="set_reset_log").disabled and at.button(key="set_clear_don").disabled           # needs the confirm tick first
    at.checkbox(key="set_ok_reset").check().run(); click(at, "set_reset_log")
    assert len(W.load_log(C.WASTE_LOG)) == 2600
    at.checkbox(key="set_ok_don").check().run(); click(at, "set_clear_don"); assert not os.path.exists(C.DONATION_LOG)

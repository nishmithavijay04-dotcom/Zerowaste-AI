"""Forecast & Risk and Menu Planner pages."""
import re
import pandas as pd, pytest
import config as C
from helpers import view, html, text, kpis, click

def waste_units(at):
    return float(re.search(r'letter-spacing:-\.03em;line-height:1">([\d.]+)<span', html(at)).group(1))

# ------------------------------------------------------------------ Forecast & Risk: expected waste
def test_expected_waste_tab(ui):
    at = view("forecast_risk"); assert not at.exception
    k = kpis(at)
    assert k["Expected lunch waste"] == "37.4" and k["Typical day-to-day swing"].startswith("±")
    h = html(at)
    assert "Average of all earlier days" in h and h.count(">Best<") == 1 and "Honest result" in h
    assert "80% range" in h and "target 80%" in h

def test_expected_waste_meal_toggle_and_category_rows(ui):
    b = view("forecast_risk", "st.session_state['fx_meal'] = 'Breakfast'"); d = view("forecast_risk", "st.session_state['fx_meal'] = 'Dinner'")
    assert "Expected breakfast waste" in kpis(b) and "Expected dinner waste" in kpis(d)
    assert kpis(b)["Expected breakfast waste"] != kpis(d)["Expected dinner waste"]
    for cat in ("Rice", "Meat", "Vegetables", "Soup"):
        assert cat in html(b)

# ------------------------------------------------------------------ Forecast & Risk: event risk model
def test_risk_tab_renders_prediction_gauge_and_model_card(ui):
    at = view("forecast_risk"); h = html(at)
    assert "Predicted waste" in h and 'aria-label="risk gauge"' in h and "What drives waste in this data" in h
    assert waste_units(at) > 0
    assert any("Model card" in e.label for e in at.expander)
    assert any(m.label == "Average error (MAE)" for m in at.metric) and any(m.label == "80% range hit-rate" for m in at.metric)

def test_risk_prediction_responds_to_inputs(ui):
    hi = waste_units(view("forecast_risk", "st.session_state['rk_pricing'] = 'High'"))
    lo = waste_units(view("forecast_risk", "st.session_state['rk_pricing'] = 'Low'"))
    assert hi > lo * 1.3                                                      # pricing tier is the strongest driver in the data
    big = waste_units(view("forecast_risk", "st.session_state['rk_quantity'] = 800; st.session_state['rk_guests'] = 600"))
    small = waste_units(view("forecast_risk", "st.session_state['rk_quantity'] = 200; st.session_state['rk_guests'] = 150"))
    assert big > small

def test_risk_interval_and_risk_band_text(ui):
    h = html(view("forecast_risk", "st.session_state['rk_pricing'] = 'High'"))
    assert "High risk" in h and "likely between" in h
    assert "Low risk" in html(view("forecast_risk", "st.session_state['rk_pricing'] = 'Low'"))

def test_risk_handoff_to_redistribution(ui):
    at = view("forecast_risk", "st.session_state['rk_food_type'] = 'Meat'")
    click(at, "rk_plan")
    pre = at.session_state["prefill"]
    assert at.session_state["_nav_request"] == "redistribute"
    assert pre["source"] == "risk" and pre["veg"] is False and pre["ftype"] == "Cooked meat / egg dishes" and pre["qty"] > 0
    at = view("forecast_risk", "st.session_state['rk_food_type'] = 'Dairy Products'")
    click(at, "rk_plan"); assert at.session_state["prefill"]["veg"] is True and at.session_state["prefill"]["ftype"] == "Dairy-based / sweets"

# ------------------------------------------------------------------ Menu planner
def test_planner_stock_overview_kpis_and_status_pills(ui):
    at = view("planner"); assert not at.exception
    k = kpis(at)
    assert k["Items in stock"] == "20" and k["Expiring soon"] == "7" and k["Expired"] == "0" and k["Out of stock"] == "2"
    h = html(at)
    assert h.count('<span class="zw-pill amber dot">Expiring soon</span>') == 7 and h.count('<span class="zw-pill gray dot">Out of stock</span>') == 2 and "No menu yet" in h

def test_planner_builds_menu_and_all_outputs(ui):
    at = view("planner"); click(at, "pl_go")
    plan = at.session_state["plan"]
    assert plan["status"] == "optimal" and plan["servings"] == 450
    h = html(at)
    assert "Menu ready: 450 servings of lunch" in h and "Why this menu" in h and "Shopping list" in h and "Cooking guide" in h
    k = kpis(at); assert k["To buy"].startswith("₹") and k["Calories per plate"] and k["Protein per plate"]
    assert len([e for e in at.expander if "batch(es)" in e.label]) == len(plan["menu"])
    labels = [b.proto.label for b in at.get("download_button")]
    assert "Download full cooking guide (text)" in labels
    for course in ("Staple", "Main", "Side"):
        assert course in h

def test_planner_menu_uses_near_expiry_stock_and_covers_demand(ui):
    at = view("planner"); click(at, "pl_go"); plan = at.session_state["plan"]
    by_cat = {}
    for d in plan["menu"]:
        by_cat[d["category"]] = by_cat.get(d["category"], 0) + d["servings"]
    assert all(v == 450 for v in by_cat.values())
    assert plan["near_expiry"]["pct_used"] > 60

def test_planner_servings_default_comes_from_settings(ui):
    at = view("planner", "ctx.settings()['headcount'] = 300")
    assert at.number_input(key="pl_servings_Lunch").value == 300
    click(at, "pl_go"); assert at.session_state["plan"]["servings"] == 300

def test_planner_meal_toggle_and_veg_only(ui):
    at = view("planner", "st.session_state['pl_meal'] = 'Breakfast'; st.session_state['pl_nonveg'] = False"); click(at, "pl_go")
    p = at.session_state["plan"]; assert p["meal"] == "Breakfast" and all(d["veg"] for d in p["menu"]) and "breakfast" in html(at)

def test_planner_kitchen_limits_create_warnings(ui):
    at = view("planner", "ctx.settings().update(pots=1, staff=1, window_min=60)"); click(at, "pl_go")
    assert any("pot-minutes" in w for w in at.session_state["plan"]["warnings"]) and "Heads up" in html(at)

def test_planner_expired_and_bad_stock(ui):
    pre = ("import pandas as pd; from services.recipes import load_inventory\n"
           "df = pd.read_csv(C.INVENTORY_SAMPLE) if 'C' in dir() else None\n")
    at = view("planner", "import config as C, pandas as pd\ndf = pd.read_csv(C.INVENTORY_SAMPLE); df.loc[df['item']=='tomato', 'days_to_expiry'] = -2\nst.session_state['inventory_df'] = df")
    assert kpis(at)["Expired"] == "1" and "Expired</span>" in html(at)
    click(at, "pl_go"); assert any("expired" in w.lower() for w in at.session_state["plan"]["warnings"])
    at = view("planner", "import config as C, pandas as pd\ndf = pd.read_csv(C.INVENTORY_SAMPLE); df.loc[0, 'quantity_kg'] = -5\nst.session_state['inventory_df'] = df")
    click(at, "pl_go"); assert any("Check your stock table" in e.value for e in at.error)

def test_planner_apply_and_reset_buttons(ui):
    at = view("planner", "import config as C, pandas as pd\ndf = pd.read_csv(C.INVENTORY_SAMPLE); df.loc[0, 'quantity_kg'] = 999\nst.session_state['inventory_df'] = df")
    assert "999.0 kg" in html(at)
    click(at, "pl_reset"); assert "999.0 kg" not in html(view("planner"))

def test_planner_infeasible_message(ui, monkeypatch):
    import services.recipes as R
    real = R.Catalog.eligible
    monkeypatch.setattr(R.Catalog, "eligible", lambda self, meal, allow_nonveg=True: real(self, meal, allow_nonveg).query("category != 'side'"))
    at = view("planner"); click(at, "pl_go"); assert any("No valid menu" in e.value for e in at.error)

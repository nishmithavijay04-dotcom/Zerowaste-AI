"""Animated SVG/HTML charts (no JavaScript). Each function returns a flat HTML string.
Geometry is pure and unit-tested: values map linearly onto the plot area."""
import math
from html import escape
from ui.kit import esc, icon, delta

PALETTE = ["#16A34A", "#3B82F6", "#F59E0B", "#8B5CF6", "#0D9488", "#EF4444"]

def nice_scale(vmax, n=4):
    """Return (ticks, top) with 'nice' round steps so that top >= vmax."""
    if vmax <= 0:
        return [0.0, 1.0], 1.0
    raw = vmax / n
    mag = 10 ** math.floor(math.log10(raw))
    step = next(m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw)
    top = math.ceil(vmax / step - 1e-9) * step
    return [i * step for i in range(int(round(top / step)) + 1)], top

def fmt(v):
    if abs(v) >= 10000: return f"{v / 1000:.0f}k"
    if abs(v) >= 1000: return f"{v:,.0f}"
    return f"{v:.0f}" if abs(v - round(v)) < 0.05 else f"{v:.1f}"

def monotone_path(xs, ys):
    """Smooth monotone cubic (Fritsch-Carlson) through the points: no overshoot between data points."""
    n = len(xs)
    if n == 1:
        return f"M{xs[0]:.1f} {ys[0]:.1f}"
    if n == 2:
        return f"M{xs[0]:.1f} {ys[0]:.1f} L{xs[1]:.1f} {ys[1]:.1f}"
    d = [(ys[i + 1] - ys[i]) / (xs[i + 1] - xs[i]) for i in range(n - 1)]
    m = [d[0]] + [0 if d[i - 1] * d[i] <= 0 else (d[i - 1] + d[i]) / 2 for i in range(1, n - 1)] + [d[-1]]
    for i in range(n - 1):
        if d[i] == 0:
            m[i] = m[i + 1] = 0
        else:
            a, b = m[i] / d[i], m[i + 1] / d[i]
            s = a * a + b * b
            if s > 9:
                t = 3 / math.sqrt(s); m[i], m[i + 1] = t * a * d[i], t * b * d[i]
    p = f"M{xs[0]:.1f} {ys[0]:.1f}"
    for i in range(n - 1):
        dx = (xs[i + 1] - xs[i]) / 3
        p += f" C{xs[i] + dx:.1f} {ys[i] + m[i] * dx:.1f} {xs[i + 1] - dx:.1f} {ys[i + 1] - m[i + 1] * dx:.1f} {xs[i + 1]:.1f} {ys[i + 1]:.1f}"
    return p

def _tip(x, y, w, title, sub, W):
    tx = min(max(x - w / 2, 2), W - w - 2)
    return (f'<g class="tip" transform="translate({tx - x:.1f},-58)"><rect width="{w}" height="46"/><text x="12" y="19">{esc(title)}</text>'
            f'<text class="s" x="12" y="35">{esc(sub)}</text></g>')

def area_chart(points, uid="a", color="#16A34A", W=720, H=260, unit="kg", show_avg=True):
    """points: [(label, value)]. Smooth gradient area with grid, axis labels, average line and hover tooltips."""
    if not points:
        return ""
    L, R, T, B = 46, 30, 16, 30
    pw, ph = W - L - R, H - T - B
    vals = [v for _, v in points]
    ticks, top = nice_scale(max(vals))
    n = len(points)
    xs = [L + (pw * i / (n - 1) if n > 1 else pw / 2) for i in range(n)]
    ys = [T + ph * (1 - v / top) for v in vals]
    grid = "".join(f'<line class="zw-grid" x1="{L}" x2="{W - R}" y1="{T + ph * (1 - t / top):.1f}" y2="{T + ph * (1 - t / top):.1f}"/>'
                   f'<text class="zw-axis" x="{L - 10}" y="{T + ph * (1 - t / top) + 4:.1f}" text-anchor="end">{fmt(t)}</text>' for t in ticks)
    step = max(1, math.ceil(n / 8))
    xl = "".join(f'<text class="zw-axis" x="{xs[i]:.1f}" y="{H - 8}" text-anchor="middle">{esc(points[i][0])}</text>' for i in range(0, n, step))
    line = monotone_path(xs, ys)
    base = T + ph
    area = f'{line} L{xs[-1]:.1f} {base:.1f} L{xs[0]:.1f} {base:.1f}Z'
    avg = ""
    if show_avg and n > 1:
        a = sum(vals) / n; ay = T + ph * (1 - a / top)
        avg = (f'<line x1="{L}" x2="{W - R}" y1="{ay:.1f}" y2="{ay:.1f}" stroke="{color}" stroke-opacity=".45" stroke-dasharray="6 6"/>'
               '')
    pts = "".join(f'<g class="zw-pt" transform="translate({xs[i]:.1f},{ys[i]:.1f})"><circle class="hit" r="16"/><circle class="dot" r="5" stroke="{color}"/>'
                  f'{_tip(xs[i], ys[i], 118, f"{vals[i]:,.1f} {unit}", points[i][0], W)}</g>' for i in range(n))
    return (f'<svg class="zw-chart" viewBox="0 0 {W} {H}" role="img" aria-label="area chart"><defs><linearGradient id="g{uid}" x1="0" y1="0" x2="0" y2="1">'
            f'<stop offset="0" stop-color="{color}" stop-opacity=".34"/><stop offset="1" stop-color="{color}" stop-opacity="0"/></linearGradient></defs>'
            f'{grid}{xl}<path class="zw-area" d="{area}" fill="url(#g{uid})"/>{avg}<path class="zw-line" pathLength="1" d="{line}" stroke="{color}" stroke-width="3"/>{pts}</svg>')

def bar_chart(items, uid="b", highlight=None, color="#16A34A", pale="#DDEFE4", W=720, H=250, unit="kg"):
    """items: [(label, value)]. Rounded bars; the highlighted bar (default: the tallest) is solid, others pale."""
    if not items:
        return ""
    L, R, T, B = 46, 10, 16, 30
    pw, ph = W - L - R, H - T - B
    vals = [v for _, v in items]
    ticks, top = nice_scale(max(vals))
    hl = vals.index(max(vals)) if highlight is None else highlight
    n = len(items); slot = pw / n; bw = min(52, slot * 0.58)
    grid = "".join(f'<line class="zw-grid" x1="{L}" x2="{W - R}" y1="{T + ph * (1 - t / top):.1f}" y2="{T + ph * (1 - t / top):.1f}"/>'
                   f'<text class="zw-axis" x="{L - 10}" y="{T + ph * (1 - t / top) + 4:.1f}" text-anchor="end">{fmt(t)}</text>' for t in ticks)
    bars = ""
    for i, (lab, v) in enumerate(items):
        h = ph * v / top; x = L + slot * i + (slot - bw) / 2; y = T + ph - h
        fill = f"url(#bg{uid})" if i == hl else pale
        tw = 110; tx = min(max(x + bw / 2 - tw / 2, 2), W - tw - 2)
        bars += (f'<g class="zw-bar-col"><rect class="zw-bar" style="animation-delay:{i * 70}ms" x="{x:.1f}" y="{y:.1f}" width="{bw:.1f}" height="{h:.1f}" rx="9" fill="{fill}"/>'
                 f'<text class="zw-axis" x="{x + bw / 2:.1f}" y="{H - 8}" text-anchor="middle">{esc(lab)}</text>'
                 f'<g class="tip" transform="translate({tx:.1f},{max(y - 52, 0):.1f})"><rect width="{tw}" height="40" rx="10"/><text x="12" y="25">{v:,.1f} {unit}</text></g></g>')
    return (f'<svg class="zw-chart" viewBox="0 0 {W} {H}" role="img" aria-label="bar chart"><defs><linearGradient id="bg{uid}" x1="0" y1="0" x2="0" y2="1">'
            f'<stop offset="0" stop-color="{color}"/><stop offset="1" stop-color="#4ADE80"/></linearGradient></defs>{grid}{bars}</svg>')

def donut(items, center_value, center_label, uid="d", size=190, gap=1.4):
    """items: [(label, value, color)]. Circumference is normalised to 100 so segment length = percentage."""
    total = sum(v for _, v, _ in items) or 1
    segs, off, legend = "", 0.0, ""
    for i, (lab, v, col) in enumerate(items):
        p = 100 * v / total
        seg = max(p - gap, 0.1)
        segs += (f'<circle class="zw-seg" style="animation-delay:{i * 120}ms" cx="21" cy="21" r="15.9155" stroke="{col}" stroke-width="5.2" '
                 f'stroke-dasharray="{seg:.2f} {100 - seg:.2f}" stroke-dashoffset="{25 - off:.2f}" stroke-linecap="butt"/>')
        legend += (f'<div class="it"><span class="sw" style="background:{col}"></span>{esc(lab)}<b>{v:,.1f}</b><i>{p:.0f}%</i></div>')
        off += p
    svg = (f'<svg class="zw-chart" style="width:{size}px;flex:none" viewBox="0 0 42 42" role="img" aria-label="donut chart"><circle cx="21" cy="21" r="15.9155" fill="none" stroke="#EEF3F0" stroke-width="5.2"/>'
           f'{segs}<text x="21" y="20.4" text-anchor="middle" style="font-size:5.6px;font-weight:800;fill:#13221A">{esc(center_value)}</text>'
           f'<text x="21" y="25.4" text-anchor="middle" style="font-size:2.7px;font-weight:600;fill:#93A39A">{esc(center_label)}</text></svg>')
    return f'<div class="zw-donut-wrap">{svg}<div class="zw-legend">{legend}</div></div>'

def hbar_compare(rows, unit="kg", color="#16A34A", prev_color="#BBD9C6", good="down", cur_label="Current period", prev_label="Previous period"):
    """rows: [{label, current, previous, delta_pct}] -> current vs previous bars with change pills."""
    mx = max([r["current"] for r in rows] + [r["previous"] for r in rows] + [1e-9])
    out = ""
    for i, r in enumerate(rows):
        out += (f'<div class="zw-hb"><div class="lbl">{esc(r["label"])}</div><div><div class="track"><div class="fill" style="width:{100 * r["current"] / mx:.1f}%;background:{color};animation-delay:{i * 90}ms"></div></div>'
                f'<div class="track prev"><div class="fill" style="width:{100 * r["previous"] / mx:.1f}%;background:{prev_color};animation-delay:{i * 90 + 60}ms"></div></div></div>'
                f'<div class="val"><b>{r["current"]:,.1f} {unit}</b>{delta(r["delta_pct"], good)}</div></div>')
    return out + (f'<div class="zw-hb-legend"><span><i style="background:{color}"></i>{esc(cur_label)}</span><span><i style="background:{prev_color}"></i>{esc(prev_label)}</span></div>')

def hbar_list(rows, unit="", color="#16A34A"):
    """Simple horizontal bars. rows: [(label, value)] scaled to the largest value."""
    mx = max([v for _, v in rows] + [1e-9])
    out = ""
    for i, (lab, v) in enumerate(rows):
        out += (f'<div class="zw-hb" style="grid-template-columns:130px 1fr 56px"><div class="lbl">{esc(lab)}</div><div><div class="track"><div class="fill" style="width:{100 * v / mx:.1f}%;background:{color};animation-delay:{i * 80}ms"></div></div></div>'
                f'<div class="val"><b>{v:,.1f}{unit}</b></div></div>')
    return out

def heat_color(t):
    """t in [0,1] -> (background, text colour) on a light-to-deep green ramp."""
    t = min(max(t, 0.0), 1.0)
    lo, hi = (220, 252, 231), (14, 74, 55)
    c = tuple(round(lo[i] + (hi[i] - lo[i]) * t) for i in range(3))
    return f"rgb({c[0]},{c[1]},{c[2]})", ("#fff" if t > 0.55 else "#0A3B2C")

def heatmap(rows, cols, matrix, unit=""):
    """matrix[r][c] -> value (None allowed). Colour scale is relative to the min and max shown."""
    flat = [v for row in matrix for v in row if v is not None]
    lo, hi = (min(flat), max(flat)) if flat else (0, 1)
    span = (hi - lo) or 1
    out = f'<div class="zw-heat" style="grid-template-columns:96px repeat({len(cols)},1fr)"><div></div>' + "".join(f'<div class="h">{esc(c)}</div>' for c in cols)
    k = 0
    for r, row in zip(rows, matrix):
        out += f'<div class="r">{esc(r)}</div>'
        for ci, v in enumerate(row):
            if v is None:
                out += '<div class="c" style="background:#F3F6F4;color:#93A39A">–</div>'
            else:
                bg, tx = heat_color((v - lo) / span)
                out += (f'<div class="c" style="background:{bg};color:{tx};animation-delay:{k * 25}ms" '
                        f'title="{esc(r)} · {esc(cols[ci])}: {v:.1f}{unit}">{v:.1f}</div>')
            k += 1
    return out + "</div>"

def _arc(cx, cy, r, a0, a1):
    x0, y0 = cx + r * math.cos(math.radians(a0)), cy + r * math.sin(math.radians(a0))
    x1, y1 = cx + r * math.cos(math.radians(a1)), cy + r * math.sin(math.radians(a1))
    large = 1 if abs(a1 - a0) > 180 else 0
    return f"M{x0:.2f} {y0:.2f} A{r} {r} 0 {large} 1 {x1:.2f} {y1:.2f}"

def ring(pct, center, sub="", color="#16A34A", size=150, track="#EAF1ED", uid="r"):
    """Progress ring: pct (0-100) of the circle is drawn."""
    pct = max(0.0, min(100.0, pct))
    return (f'<svg class="zw-chart zw-ring" style="width:{size}px" viewBox="0 0 42 42" role="img" aria-label="progress ring"><circle cx="21" cy="21" r="15.9155" fill="none" stroke="{track}" stroke-width="3.6"/>'
            f'<circle class="zw-seg" cx="21" cy="21" r="15.9155" fill="none" stroke="{color}" stroke-width="3.6" stroke-linecap="round" stroke-dasharray="{pct:.2f} {100 - pct:.2f}" stroke-dashoffset="25"/>'
            f'<text x="21" y="22.2" text-anchor="middle" style="font-size:7px;font-weight:800;fill:#13221A">{esc(center)}</text>'
            f'<text x="21" y="27.2" text-anchor="middle" style="font-size:2.9px;font-weight:600;fill:#93A39A">{esc(sub)}</text></svg>')

def gauge(percentile, label, sub="", size=250):
    """Half-circle risk gauge: green (low) -> amber (typical) -> red (high), with a marker at `percentile` (0-100)."""
    cx, cy, r = 100, 100, 78
    segs = [(180, 240, "#22C55E"), (240, 300, "#F59E0B"), (300, 360, "#EF4444")]
    arcs = "".join(f'<path d="{_arc(cx, cy, r, a, b - 1.5)}" fill="none" stroke="{c}" stroke-width="16" stroke-linecap="round"/>' for a, b, c in segs)
    ang = math.radians(180 + 180 * max(0, min(100, percentile)) / 100)
    mx, my = cx + r * math.cos(ang), cy + r * math.sin(ang)
    return (f'<svg class="zw-chart" style="width:{size}px;margin:0 auto" viewBox="0 0 200 122" role="img" aria-label="risk gauge">{arcs}'
            f'<circle cx="{mx:.1f}" cy="{my:.1f}" r="9" fill="#fff" stroke="#13221A" stroke-width="3.5" style="animation:zwPop .8s var(--ease) both"/>'
            f'<text x="100" y="92" text-anchor="middle" style="font-size:24px;font-weight:800;fill:#13221A">{esc(label)}</text>'
            f'<text x="100" y="110" text-anchor="middle" style="font-size:10.5px;font-weight:600;fill:#93A39A">{esc(sub)}</text></svg>')

def sparkline(values, color="#16A34A", uid="s", W=160, H=56):
    if len(values) < 2:
        return ""
    lo, hi = min(values), max(values); span = (hi - lo) or 1
    xs = [W * i / (len(values) - 1) for i in range(len(values))]
    ys = [6 + (H - 14) * (1 - (v - lo) / span) for v in values]
    line = monotone_path(xs, ys)
    return (f'<svg viewBox="0 0 {W} {H}" width="100%" aria-hidden="true"><defs><linearGradient id="sg{uid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{color}" stop-opacity=".28"/>'
            f'<stop offset="1" stop-color="{color}" stop-opacity="0"/></linearGradient></defs><path class="zw-area" d="{line} L{W} {H} L0 {H}Z" fill="url(#sg{uid})"/>'
            f'<path class="zw-line" pathLength="1" d="{line}" stroke="{color}" stroke-width="2"/></svg>')

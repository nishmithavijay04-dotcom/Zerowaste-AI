"""Interactive Leaflet maps (folium + streamlit-folium): pan, zoom, hover tooltips, click-to-select markers,
popups with contact details and directions, road routes, click-to-set location."""
import folium
from html import escape
import streamlit as st
from services.links import google_directions_url, google_place_url, osm_url

GREEN, BLUE, AMBER, GREY, RED = "#16A34A", "#2563EB", "#F59E0B", "#94A3B8", "#EF4444"
KITCHEN_TIP = "Your kitchen"

def _pin(label, color, size=34, ring="#fff", pulse=False):
    return (f'<div style="width:{size}px;height:{size}px;border-radius:50%;background:{color};color:#fff;display:flex;align-items:center;justify-content:center;'
            f'font:800 {max(11, size // 2 - 1)}px Inter,system-ui,sans-serif;border:3px solid {ring};box-shadow:0 4px 12px rgba(15,31,24,.35);'
            f'{"outline:4px solid rgba(34,197,94,.35);" if pulse else ""}">{label}</div>')

def _kitchen_icon():
    svg = ('<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">'
           '<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>')
    return folium.DivIcon(html=_pin(svg, RED, 40, pulse=False), icon_size=(40, 40), icon_anchor=(20, 20))

def _popup(r, kitchen):
    links = (f'<a href="{google_directions_url(kitchen["lat"], kitchen["lon"], r["lat"], r["lon"])}" target="_blank" style="color:#15803D;font-weight:700">Directions</a> · '
             f'<a href="{google_place_url(r["lat"], r["lon"])}" target="_blank" style="color:#15803D;font-weight:700">Google Maps</a> · '
             f'<a href="{osm_url(r["lat"], r["lon"])}" target="_blank" style="color:#15803D;font-weight:700">OSM</a>')
    extra = f'<div style="margin-top:4px;color:#475569">{escape(str(r.get("info", "")))}</div>' if r.get("info") else ""
    return folium.Popup(f'<div style="font:13px/1.45 Inter,system-ui,sans-serif;min-width:210px"><b style="font-size:14px">{escape(r["name"])}</b>'
                        f'<div style="color:#64748B">{escape(str(r.get("sub", "")))}</div>{extra}'
                        f'<div style="margin-top:6px">📞 {escape(str(r.get("phone") or "not listed"))}</div><div style="margin-top:6px">{links}</div></div>', max_width=300)

def _base(kitchen, zoom=11):
    return folium.Map(location=[kitchen["lat"], kitchen["lon"]], zoom_start=zoom, tiles="OpenStreetMap", control_scale=True, prefer_canvas=True)

def _fit(m, pts):
    if len(pts) > 1:
        m.fit_bounds([[min(p[0] for p in pts), min(p[1] for p in pts)], [max(p[0] for p in pts), max(p[1] for p in pts)]], padding=(40, 40), max_zoom=14)

def recommendation_map(kitchen, results, others=(), selected=None):
    """kitchen {lat, lon}; results = ranked partner dicts (lat, lon, name, phone, distance_km, eta_min, optional path [[lon,lat]...])."""
    m = _base(kitchen)
    for o in others:
        folium.Marker([o["lat"], o["lon"]], tooltip=escape(o["name"]), popup=_popup(o, kitchen),
                      icon=folium.DivIcon(html=_pin("", GREY, 14, ring="#fff"), icon_size=(14, 14), icon_anchor=(7, 7))).add_to(m)
    pts = [(kitchen["lat"], kitchen["lon"])]
    for i, r in enumerate(results, 1):
        pts.append((r["lat"], r["lon"]))
        sel = r["name"] == selected
        if r.get("path"):
            folium.PolyLine([(la, lo) for lo, la in r["path"]], color=BLUE if not sel else GREEN, weight=6 if sel else 4, opacity=.85 if sel else .6).add_to(m)
        else:
            folium.PolyLine([(kitchen["lat"], kitchen["lon"]), (r["lat"], r["lon"])], color=BLUE, weight=3, opacity=.5, dash_array="6 8").add_to(m)
        folium.Marker([r["lat"], r["lon"]], tooltip=escape(r["name"]), popup=_popup({**r, "sub": f'{r["distance_km"]} km · ~{r["eta_min"]} min', "info": r.get("surplus_status", "")}, kitchen),
                      icon=folium.DivIcon(html=_pin(str(i), GREEN if sel else BLUE, 38 if sel else 34, pulse=sel), icon_size=(38, 38), icon_anchor=(19, 19)),
                      z_index_offset=1000 + (500 if sel else 0)).add_to(m)
    folium.Marker([kitchen["lat"], kitchen["lon"]], tooltip=KITCHEN_TIP, icon=_kitchen_icon(), z_index_offset=2000).add_to(m)
    _fit(m, pts)
    return m

def directory_map(kitchen, partners, selected=None):
    """partners: iterable of dicts (lat, lon, name, phone, sub, level in yes/likely/unconfirmed). Colour = surplus-intake status."""
    m = _base(kitchen, 11)
    color = {"yes": GREEN, "likely": AMBER, "unconfirmed": GREY}
    pts = [(kitchen["lat"], kitchen["lon"])]
    for p in partners:
        pts.append((p["lat"], p["lon"]))
        sel = p["name"] == selected
        folium.Marker([p["lat"], p["lon"]], tooltip=escape(p["name"]), popup=_popup(p, kitchen),
                      icon=folium.DivIcon(html=_pin("", color.get(p["level"], GREY), 26 if sel else 20, pulse=sel), icon_size=(26, 26), icon_anchor=(13, 13)),
                      z_index_offset=800 if sel else 0).add_to(m)
    folium.Marker([kitchen["lat"], kitchen["lon"]], tooltip=KITCHEN_TIP, icon=_kitchen_icon(), z_index_offset=2000).add_to(m)
    _fit(m, pts)
    return m

def picker_map(kitchen, picked=None):
    """Click anywhere to choose a location. `picked` (lat, lon) is shown as a crosshair pin."""
    m = _base(kitchen, 12)
    folium.Marker([kitchen["lat"], kitchen["lon"]], tooltip=KITCHEN_TIP, icon=_kitchen_icon()).add_to(m)
    if picked:
        folium.Marker(list(picked), tooltip="New location", icon=folium.DivIcon(html=_pin("+", GREEN, 36, pulse=True), icon_size=(36, 36), icon_anchor=(18, 18))).add_to(m)
        _fit(m, [(kitchen["lat"], kitchen["lon"]), tuple(picked)])
    return m

def render_map(m, key, height=520):
    """Show the map. Returns {'click': {lat,lng}|None, 'tooltip': str|None} (what the user last clicked)."""
    from streamlit_folium import st_folium
    out = st_folium(m, height=height, use_container_width=True, key=key, returned_objects=["last_clicked", "last_object_clicked_tooltip"]) or {}
    return {"click": out.get("last_clicked"), "tooltip": out.get("last_object_clicked_tooltip")}

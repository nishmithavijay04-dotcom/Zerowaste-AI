"""HTML building blocks (cards, KPIs, pills, tables, notices). Every function returns a flat HTML string:
no blank lines or indentation, so Streamlit's markdown renderer never turns it into a code block.
Dollar signs are written as &#36; so they are never read as LaTeX."""
from html import escape
import streamlit as st
from ui.icons import ICONS

def esc(s):
    return escape(str(s), quote=True)

def money(v, dec=1):
    return f"&#36;{v:,.{dec}f}"

def fmt_p(v, dec=3):
    return "–" if v is None or v != v else f"{v:.{dec}f}"

def num(v, dec=1):
    return f"{v:,.{dec}f}"

def icon(name, size=18, stroke=2, cls=""):
    inner = ICONS.get(name, ICONS["info"])
    return (f'<svg class="zw-i {cls}" xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" '
            f'stroke="currentColor" stroke-width="{stroke}" stroke-linecap="round" stroke-linejoin="round">{inner}</svg>')

def panel():
    """A bordered card container. The key gives it a stable CSS class (st-key-zwcardN) so the theme can style it."""
    n = st.session_state.get("_card_n", 0)
    st.session_state["_card_n"] = n + 1
    return st.container(border=True, key=f"zwcard{n}")

def show(html):
    st.markdown(html, unsafe_allow_html=True)

def pill(text, tone="gray", dot=False, ico=None, solid=False):
    cls = "solid" if solid else tone
    return f'<span class="zw-pill {cls}{" dot" if dot else ""}">{icon(ico, 12) if ico else ""}{esc(text)}</span>'

def delta(pct, good="down"):
    """Change pill. good='down' means a decrease is good (waste, cost); good='up' means an increase is good."""
    if pct is None:
        return '<span class="zw-delta flat">n/a</span>'
    if abs(pct) < 0.05:
        return f'<span class="zw-delta flat">{icon("arrow-up-right", 12)}0.0%</span>'
    up = pct > 0
    ok = (up and good == "up") or ((not up) and good == "down")
    return (f'<span class="zw-delta {"good" if ok else "bad"}">{icon("arrow-up-right" if up else "arrow-down-right", 12)}'
            f'{abs(pct):.1f}%</span>')

def kpi_card(label, value, ico="scale", tone="green", unit="", chip=None, sub="", spark=None, delay=0):
    return (f'<div class="zw-kpi" style="animation-delay:{delay}ms"><div class="zw-kpi-top"><span class="zw-ico {tone}">{icon(ico)}</span>'
            f'<span>{esc(label)}</span></div><div class="zw-kpi-val"><span class="v">{value}</span>'
            f'{f"<span class=u>{esc(unit)}</span>" if unit else ""}{chip or ""}</div><div class="zw-kpi-sub">{sub}</div>'
            f'{f"<div class=spark>{spark}</div>" if spark else ""}</div>')

def card(title, body, sub="", right="", cls="", delay=0):
    sub_html = f'<div class="zw-sub">{sub}</div>' if sub else ""
    return (f'<div class="zw-card zw-anim {cls}" style="animation-delay:{delay}ms"><div class="zw-card-head"><div><h3>{esc(title)}</h3>{sub_html}</div>'
            f'<div>{right}</div></div>{body}</div>')

def page_header(title, subtitle, crumb=None):
    crumbs = f'<div class="zw-crumb">{icon("house", 13)}<span>ZeroWaste</span><span>/</span><b>{esc(crumb or title)}</b></div>'
    return f'<div class="zw-anim">{crumbs}<div class="zw-title">{esc(title)}</div><div class="zw-lead">{subtitle}</div></div>'

def table(headers, rows, aligns=None, delay_step=35):
    aligns = aligns or [""] * len(headers)
    th = "".join(f'<th class="{a}">{esc(h)}</th>' for h, a in zip(headers, aligns))
    body = "".join(f'<tr style="animation-delay:{i * delay_step}ms">' + "".join(f'<td class="{a}">{c}</td>' for c, a in zip(r, aligns)) + "</tr>"
                   for i, r in enumerate(rows))
    return f'<div class="zw-scroll"><table class="zw-table"><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table></div>'

def note(title, text, tone="info", ico="info"):
    t = {"info": "blue", "warn": "amber", "bad": "red", "good": "green"}[tone]
    return f'<div class="zw-note {tone}"><span class="zw-ico {t}">{icon(ico, 18)}</span><div><b>{esc(title)}</b><p>{text}</p></div></div>'

def steps(labels, active):
    out = []
    for i, lab in enumerate(labels, 1):
        cls = "on" if i == active else ("done" if i < active else "")
        mark = icon("check", 13, 3) if i < active else str(i)
        out.append(f'<div class="zw-step {cls}"><i>{mark}</i>{esc(lab)}</div>')
    return '<div class="zw-steps">' + '<div class="zw-step-sep"></div>'.join(out) + "</div>"

def pick_card(ico, title, line1, line2="", selected=False, tone="green"):
    return (f'<div class="zw-pick {"sel" if selected else ""}"><div class="tick">{icon("check", 13, 3)}</div>'
            f'<span class="zw-ico {tone}">{icon(ico)}</span><h4>{esc(title)}</h4><p>{line1}</p>'
            f'{f"<p>{line2}</p>" if line2 else ""}</div>')

def empty(ico, title, text):
    return f'<div class="zw-empty"><span class="zw-ico gray">{icon(ico, 22)}</span><b class="t">{esc(title)}</b><span>{text}</span></div>'

def progress(pct):
    return f'<div class="zw-progress"><i style="width:{max(0, min(100, pct)):.0f}%"></i></div>'

def kv(pairs):
    return '<div class="zw-kv">' + "".join(f"<span>{esc(k)}</span><b>{v}</b>" for k, v in pairs) + "</div>"

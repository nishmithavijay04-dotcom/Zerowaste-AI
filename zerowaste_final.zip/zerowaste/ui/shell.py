"""App shell pieces: page header with global search, notifications and user chip; sidebar extras."""
import streamlit as st
from ui import ctx
from ui.kit import show, page_header, icon, esc, note, pill, panel

def header(title, subtitle, crumb=None):
    c1, c2, c3, c4 = st.columns([5, 3, 0.9, 2.1], vertical_alignment="center", gap="small")
    with c1:
        show(page_header(title, subtitle, crumb))
    with c2:
        q = st.text_input("Search", placeholder="Search partners or pages…", label_visibility="collapsed", key="gsearch")
    with c3:
        items = ctx.notifications()
        with st.popover(f"{len(items)}", icon=":material/notifications:"):
            st.markdown("**Notifications**")
            for tone, t, txt in items:
                show(note(t, esc(txt), tone, {"warn": "triangle-alert", "info": "info", "good": "circle-check", "bad": "circle-alert"}[tone]))
    with c4:
        k = ctx.kitchen()
        ini = "".join(w[0] for w in k["name"].split()[:2]).upper() or "K"
        show(f'<div class="zw-user"><div class="zw-avatar">{esc(ini)}</div><div><b>{esc(k["name"])}</b><span>{esc(k["area"])}, Bengaluru</span></div></div>')
    results = ctx.search(q)
    if q and len(q.strip()) >= 2:
        with panel():
            if not results:
                st.caption("No matching pages or partners.")
            for i, (kind, key, sub) in enumerate(results):
                r1, r2 = st.columns([5, 1.4], vertical_alignment="center")
                r1.markdown(f"**{key if kind == 'partner' else ctx.TITLES[key]}**  \n<span style='color:#93A39A;font-size:.78rem'>{esc(sub) if kind == 'partner' else 'Page'}</span>", unsafe_allow_html=True)
                if r2.button("Open", key=f"sr_{i}", width="stretch"):
                    if kind == "page":
                        ctx.go(key)
                    else:
                        st.session_state["dir_focus"] = key
                        st.session_state["dir_search"] = key
                        ctx.go("partners")

def sidebar_extras():
    from services import wastelog as W
    from ui import dialogs
    df = ctx.waste(); ev = ctx.event_model(); p = ctx.partners(); k = ctx.kitchen()
    with st.sidebar:
        if st.button("＋  Log waste entry", type="primary", key="side_log", width="stretch"):
            dialogs.log_waste()
        show(f'<div class="zw-side-card"><div class="t">Data in use</div>'
             f'<div class="row"><span class="dot"></span><div>Canteen waste log<small>{len(df):,} entries · {df["date"].nunique()} days</small></div></div>'
             f'<div class="row"><span class="dot"></span><div>Event waste records<small>{ev.metrics["rows"]:,} unique events</small></div></div>'
             f'<div class="row"><span class="dot"></span><div>Redistribution partners<small>{len(p)} in Bengaluru</small></div></div></div>')
        show(f'<div class="zw-side-card"><div class="t">Kitchen</div><div class="row">{icon("map-pin", 15)}<div>{esc(k["name"])}<small>{esc(k["area"])} · {k["lat"]:.4f}, {k["lon"]:.4f}</small></div></div></div>')

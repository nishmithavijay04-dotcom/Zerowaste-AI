"""Modal dialogs shared across pages."""
from datetime import timedelta
import streamlit as st
from services import wastelog as W
from ui import ctx
from ui.kit import show, esc, money, icon

@st.dialog("Log waste entry", width="large")
def log_waste():
    df = ctx.waste()
    prices = W.category_prices(df)
    st.caption(f"The log currently covers {df['date'].min():%d %b %Y} to {df['date'].max():%d %b %Y}. New entries are added to the same log.")
    c1, c2 = st.columns(2)
    d = c1.date_input("Date", df["date"].max().date() + timedelta(days=1), key="lw_date")
    meal = c2.selectbox("Meal", W.MEAL_ORDER, index=1, key="lw_meal")
    c3, c4 = st.columns(2)
    section = c3.selectbox("Canteen section", sorted(df["section"].unique()), key="lw_section")
    category = c4.selectbox("Food category", sorted(prices), key="lw_category")
    kg = st.number_input("Waste weight (kg)", min_value=0.1, max_value=500.0, value=2.5, step=0.1, key="lw_kg")
    cost = kg * prices[category]
    show(f'<div class="zw-note info"><span class="zw-ico blue">{icon("wallet")}</span><div><b>Estimated cost: {money(cost, 2)}</b>'
         f'<p>{kg:g} kg of {esc(category)} at {money(prices[category], 2)} per kg (price taken from your dataset).</p></div></div>')
    if st.button("Save entry", type="primary", key="lw_save"):
        try:
            W.append_entry(d, meal, section, category, kg)
        except W.WasteLogError as e:
            st.error(str(e)); return
        st.session_state["_toast"] = f"Logged {kg:g} kg of {category.lower()} waste ({meal.lower()})."
        st.rerun()

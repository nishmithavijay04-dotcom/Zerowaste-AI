"""Design system: one stylesheet injected on every page. Look: deep-green sidebar, soft dotted canvas, white cards,
gradient primary buttons, pill toggles, status pills, and subtle motion (rise-in cards, growing bars, drawn lines)."""
import streamlit as st

CSS = r"""
:root{
  --bg:#F2F5F3; --card:#FFFFFF; --line:#E6ECE8; --line2:#D5DFD9; --text:#13221A; --muted:#5E6F66; --faint:#93A39A;
  --g950:#06271D; --g900:#0A3B2C; --g800:#0E4A37; --g700:#126043; --g600:#16A34A; --g500:#22C55E; --g400:#4ADE80; --g300:#86EFAC; --g100:#DCFCE7; --g50:#F0FDF4;
  --amber:#F59E0B; --amber-bg:#FEF3C7; --amber-tx:#B45309; --red:#EF4444; --red-bg:#FEE2E2; --red-tx:#B91C1C;
  --blue:#3B82F6; --blue-bg:#DBEAFE; --blue-tx:#1D4ED8; --violet:#8B5CF6; --violet-bg:#EDE9FE; --violet-tx:#6D28D9; --teal:#0D9488; --teal-bg:#CCFBF1;
  --gray-bg:#EEF2F0; --gray-tx:#475569;
  --r:16px; --shadow:0 1px 2px rgba(16,24,40,.05),0 8px 24px rgba(16,24,40,.05); --shadow-h:0 2px 4px rgba(16,24,40,.06),0 14px 32px rgba(16,24,40,.10);
  --ease:cubic-bezier(.2,.7,.2,1);
}
/* ---------- canvas ---------- */
.stApp{background:var(--bg);background-image:radial-gradient(rgba(10,59,44,.055) 1px,transparent 1px);background-size:22px 22px;color:var(--text)}
[data-testid="stHeader"]{background:transparent;height:0;min-height:0}
[data-testid="stToolbar"],[data-testid="stDecoration"],#MainMenu,footer{display:none!important}
[data-testid="stMainBlockContainer"]{max-width:1480px;padding:1.1rem 2.2rem 4rem}
h1,h2,h3,h4{letter-spacing:-.02em;color:var(--text)}
::selection{background:var(--g100)}
@keyframes zwUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}
@keyframes zwFade{from{opacity:0}to{opacity:1}}
@keyframes zwGrow{from{transform:scaleY(0)}to{transform:scaleY(1)}}
@keyframes zwGrowX{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@keyframes zwDraw{from{stroke-dashoffset:1}to{stroke-dashoffset:0}}
@keyframes zwSweep{from{stroke-dasharray:0 100}}
@keyframes zwPulse{0%{box-shadow:0 0 0 0 rgba(34,197,94,.55)}70%{box-shadow:0 0 0 8px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
@keyframes zwShimmer{from{background-position:-200% 0}to{background-position:200% 0}}
@keyframes zwPop{0%{transform:scale(.92);opacity:0}60%{transform:scale(1.03)}100%{transform:scale(1);opacity:1}}
.zw-anim{animation:zwUp .55s var(--ease) both}
/* ---------- sidebar ---------- */
[data-testid="stSidebar"]{background:linear-gradient(180deg,var(--g900) 0%,var(--g950) 100%);border-right:0;min-width:272px!important;max-width:272px!important}
[data-testid="stSidebar"] *{color:#C4E0D1}
[data-testid="stSidebarHeader"]{padding:1.2rem 1rem .4rem 1.3rem}
[data-testid="stSidebarHeader"] img{height:42px}
[data-testid="stSidebarCollapseButton"] button,[data-testid="stSidebarCollapsedControl"] button{color:#9EC9B3!important}
[data-testid="stSidebarNav"]{padding-top:.4rem}
[data-testid="stSidebarNavItems"]{gap:2px;padding:0 .8rem}
[data-testid="stSidebarNavSeparator"]{margin:0}
[data-testid="stSidebar"] [data-testid="stNavSectionHeader"],[data-testid="stSidebar"] [data-testid="stSidebarNavSeparator"] + div span{font-size:.68rem!important;letter-spacing:.14em;font-weight:700!important;color:#6FA58B!important;text-transform:uppercase}
[data-testid="stSidebarNavLink"]{border-radius:12px;padding:.62rem .8rem;margin:1px 0;transition:background .2s var(--ease),transform .2s var(--ease)}
[data-testid="stSidebarNavLink"] span{font-weight:550;font-size:.93rem}
[data-testid="stSidebarNavLink"]:hover{background:rgba(255,255,255,.07);transform:translateX(2px)}
[data-testid="stSidebarNavLink"][aria-current="page"]{background:linear-gradient(90deg,rgba(74,222,128,.22),rgba(74,222,128,.07));box-shadow:inset 3px 0 0 var(--g400)}
[data-testid="stSidebarNavLink"][aria-current="page"] span,[data-testid="stSidebarNavLink"][aria-current="page"] svg{color:#7CF0A8!important;font-weight:700}
[data-testid="stSidebarUserContent"]{padding:.4rem 1.2rem 1.5rem}
.zw-side-card{margin-top:.8rem;padding:14px 14px 12px;border-radius:16px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08)}
.zw-side-card .t{font-size:.7rem;letter-spacing:.12em;text-transform:uppercase;color:#7FB89B;font-weight:700;margin-bottom:8px}
.zw-side-card .row{display:flex;align-items:center;gap:8px;font-size:.8rem;color:#D3EBDD;margin:6px 0}
.zw-side-card .dot{width:8px;height:8px;border-radius:50%;background:var(--g400);flex:none;animation:zwPulse 2.4s infinite}
.zw-side-card .dot.off{background:#F59E0B;animation:none}
.zw-side-card small{color:#86B59E;display:block;font-size:.72rem}
/* ---------- buttons ---------- */
.stButton>button,.stDownloadButton>button,[data-testid^="stBaseButton"],.stLinkButton a{border-radius:12px;font-weight:600;transition:transform .18s var(--ease),box-shadow .18s var(--ease),background .18s}
[data-testid="stBaseButton-secondary"],.stLinkButton a{background:#fff;border:1px solid var(--line2);color:var(--text)}
[data-testid="stBaseButton-secondary"]:hover,.stLinkButton a:hover{border-color:var(--g500);color:var(--g700);box-shadow:0 4px 14px rgba(22,163,74,.12);transform:translateY(-1px)}
[data-testid="stBaseButton-primary"]{background:linear-gradient(135deg,#12A150 0%,#22C55E 100%);border:0;color:#fff!important;box-shadow:0 6px 16px rgba(22,163,74,.32),inset 0 1px 0 rgba(255,255,255,.25)}
[data-testid="stBaseButton-primary"]:hover{transform:translateY(-1px);box-shadow:0 10px 22px rgba(22,163,74,.42),inset 0 1px 0 rgba(255,255,255,.3);filter:saturate(1.08)}
[data-testid="stBaseButton-primary"]:active,[data-testid="stBaseButton-secondary"]:active{transform:translateY(0) scale(.98)}
[data-testid="stSidebar"] [data-testid="stBaseButton-primary"]{width:100%}
[data-testid="stBaseButton-secondary"] p,[data-testid="stBaseButton-primary"] p{font-weight:600}
/* ---------- inputs ---------- */
[data-baseweb="input"],[data-baseweb="select"]>div,[data-baseweb="textarea"],[data-testid="stDateInput"] [data-baseweb="input"]{border-radius:12px!important;background:#fff;border-color:var(--line2)!important;transition:box-shadow .2s,border-color .2s}
[data-baseweb="input"]:focus-within,[data-baseweb="select"]>div:focus-within{border-color:var(--g500)!important;box-shadow:0 0 0 3px rgba(34,197,94,.18)}
[data-testid="stWidgetLabel"] p{font-weight:600;font-size:.82rem;color:var(--muted)}
[data-testid="stNumberInput"] button{border-radius:8px}
[data-testid="stCheckbox"] label span:first-child,[data-testid="stToggle"] label>div:first-child{transition:all .2s}
/* ---------- segmented / pills ---------- */
[data-testid="stButtonGroup"]{background:#E9EFEC;padding:4px;border-radius:12px;gap:2px;display:inline-flex;width:fit-content}
[data-testid="stButtonGroup"] button{border:0!important;background:transparent!important;border-radius:9px!important;color:var(--muted);font-weight:600;padding:.28rem .9rem;box-shadow:none!important;min-height:0}
[data-testid="stButtonGroup"] button[aria-checked="true"],[data-testid="stButtonGroup"] button[aria-pressed="true"],[data-testid="stButtonGroup"] button[kind$="Active"]{background:linear-gradient(135deg,#12A150,#22C55E)!important;color:#fff!important;box-shadow:0 4px 10px rgba(22,163,74,.3)!important}
[data-testid="stButtonGroup"] button:hover{color:var(--g700)}
[data-testid="stButtonGroup"] button[aria-checked="true"]:hover,[data-testid="stButtonGroup"] button[aria-pressed="true"]:hover{color:#fff}
/* ---------- tabs (underline) ---------- */
[data-baseweb="tab-list"]{gap:6px;border-bottom:1px solid var(--line)}
button[role="tab"]{padding:.7rem 1rem;font-weight:600;color:var(--muted);border-radius:10px 10px 0 0;transition:color .2s,background .2s}
button[role="tab"]:hover{background:rgba(22,163,74,.06);color:var(--g700)}
button[role="tab"][aria-selected="true"]{color:var(--g700)}
[data-baseweb="tab-highlight"]{background:linear-gradient(90deg,var(--g600),var(--g400))!important;height:3px!important;border-radius:3px}
[data-baseweb="tab-border"]{display:none}
/* ---------- cards ---------- */
[class*="st-key-zwcard"]{background:var(--card)!important;border:1px solid var(--line)!important;border-radius:var(--r)!important;box-shadow:var(--shadow);padding:.45rem .55rem 1.15rem!important;transition:box-shadow .25s var(--ease),transform .25s var(--ease);animation:zwUp .5s var(--ease) both}
[class*="st-key-zwcard"]:hover{box-shadow:var(--shadow-h)}
[data-testid="stColumn"]{display:flex;flex-direction:column}
[data-testid="stColumn"]>[data-testid="stVerticalBlock"]{flex:1 1 auto}
[data-testid="stColumn"]>[data-testid="stVerticalBlock"]>[data-testid="stLayoutWrapper"]:has(>[class*="st-key-zwcard"]){flex:1 1 auto;display:flex;flex-direction:column}
[data-testid="stColumn"]>[data-testid="stVerticalBlock"]>[data-testid="stLayoutWrapper"]>[class*="st-key-zwcard"]{flex:1 1 auto}
[data-testid="stExpander"]{border:1px solid var(--line)!important;border-radius:14px!important;background:#fff;box-shadow:0 1px 2px rgba(16,24,40,.04)}
[data-testid="stExpander"] summary{font-weight:600}
[data-testid="stDataFrame"],[data-testid="stDataEditor"]{border-radius:14px;overflow:hidden;border:1px solid var(--line)}
[data-testid="stAlert"]{border-radius:14px;border:1px solid var(--line)}
[data-testid="stPopover"] button{border-radius:12px;background:#fff;border:1px solid var(--line2)}
[role="dialog"]{border-radius:22px!important;box-shadow:0 30px 80px rgba(6,39,29,.35)!important;animation:zwPop .35s var(--ease)}
[data-testid="stToast"]{border-radius:14px;box-shadow:var(--shadow-h)}
.zw-card{background:var(--card);border:1px solid var(--line);border-radius:var(--r);box-shadow:var(--shadow);padding:20px 22px;transition:box-shadow .25s var(--ease),transform .25s var(--ease)}
.zw-card.hover:hover{box-shadow:var(--shadow-h);transform:translateY(-2px)}
.zw-card-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:14px}
.zw-card-head h3{margin:0;font-size:1.02rem;font-weight:700;letter-spacing:-.01em}
.zw-sub{color:var(--muted);font-size:.82rem;margin-top:2px}
.zw-muted{color:var(--muted)} .zw-faint{color:var(--faint)}
/* ---------- page header ---------- */
.zw-crumb{display:flex;gap:6px;align-items:center;color:var(--faint);font-size:.78rem;font-weight:600;letter-spacing:.02em}
.zw-crumb b{color:var(--muted)}
.zw-title{font-size:1.75rem;font-weight:800;letter-spacing:-.03em;margin:.1rem 0 0;line-height:1.15}
.zw-lead{color:var(--muted);font-size:.9rem;margin-top:.15rem}
.zw-user{display:flex;align-items:center;gap:10px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:6px 12px 6px 6px;box-shadow:var(--shadow)}
.zw-avatar{width:34px;height:34px;border-radius:11px;background:linear-gradient(135deg,#14B8A6,#16A34A);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.82rem}
.zw-user b{display:block;font-size:.82rem;line-height:1.1} .zw-user span{font-size:.7rem;color:var(--faint)}
.st-key-gsearch input{padding-left:38px!important;background:#fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%2393A39A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='11' cy='11' r='8'/%3E%3Cpath d='m21 21-4.3-4.3'/%3E%3C/svg%3E") no-repeat 12px center}
.st-key-gsearch [data-baseweb="input"]{border-radius:14px!important;box-shadow:var(--shadow)}
/* ---------- KPI ---------- */
.zw-kpi{background:var(--card);border:1px solid var(--line);border-radius:var(--r);box-shadow:var(--shadow);padding:18px 20px 16px;position:relative;overflow:hidden;transition:box-shadow .25s var(--ease),transform .25s var(--ease);animation:zwUp .55s var(--ease) both;height:100%}
.zw-kpi:hover{box-shadow:var(--shadow-h);transform:translateY(-3px)}
.zw-kpi-top{display:flex;align-items:center;gap:10px;color:var(--muted);font-size:.86rem;font-weight:600}
.zw-ico{width:36px;height:36px;border-radius:11px;display:flex;align-items:center;justify-content:center;flex:none}
.zw-ico svg{width:19px;height:19px}
.zw-ico.green{background:var(--g100);color:var(--g700)} .zw-ico.blue{background:var(--blue-bg);color:var(--blue-tx)} .zw-ico.amber{background:var(--amber-bg);color:var(--amber-tx)}
.zw-ico.red{background:var(--red-bg);color:var(--red-tx)} .zw-ico.violet{background:var(--violet-bg);color:var(--violet-tx)} .zw-ico.teal{background:var(--teal-bg);color:#0F766E} .zw-ico.gray{background:var(--gray-bg);color:var(--gray-tx)}
.zw-kpi-val{display:flex;align-items:baseline;gap:10px;margin:14px 0 4px;flex-wrap:wrap}
.zw-kpi-val .v{font-size:2rem;font-weight:800;letter-spacing:-.03em;font-variant-numeric:tabular-nums;line-height:1}
.zw-kpi-val .u{font-size:.95rem;font-weight:600;color:var(--muted);margin-left:-4px}
.zw-kpi-sub{color:var(--faint);font-size:.78rem}
.zw-kpi-sub b{color:var(--muted);font-weight:600}
.zw-kpi{min-height:158px}.zw-kpi .spark{position:absolute;right:14px;top:58px;width:30%;opacity:.95;pointer-events:none}@media (max-width:1500px){.zw-kpi .spark{display:none}}
/* ---------- recipients ---------- */
.zw-rank{width:36px;height:36px;border-radius:50%;background:#DBEAFE;color:#1D4ED8;font-weight:800;display:flex;align-items:center;justify-content:center;transition:all .25s var(--ease)}
.zw-rank.on{background:linear-gradient(135deg,#12A150,#22C55E);color:#fff;box-shadow:0 6px 14px rgba(22,163,74,.35);transform:scale(1.08)}
[data-testid="stSidebar"] [data-testid="stBaseButton-primary"] p{color:#fff}
[data-testid="stSidebar"] .stButton{width:100%}
[data-testid="stPopover"] button{padding:.45rem .7rem;font-weight:700}
/* ---------- pills ---------- */
.zw-pill{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:999px;font-size:.74rem;font-weight:650;line-height:1.5;white-space:nowrap}
.zw-pill svg{width:12px;height:12px}
.zw-pill.green{background:var(--g100);color:#15803D} .zw-pill.amber{background:var(--amber-bg);color:var(--amber-tx)} .zw-pill.red{background:var(--red-bg);color:var(--red-tx)}
.zw-pill.blue{background:var(--blue-bg);color:var(--blue-tx)} .zw-pill.violet{background:var(--violet-bg);color:var(--violet-tx)} .zw-pill.gray{background:var(--gray-bg);color:var(--gray-tx)} .zw-pill.teal{background:var(--teal-bg);color:#0F766E}
.zw-pill.dot::before{content:"";width:7px;height:7px;border-radius:50%;background:currentColor;opacity:.85}
.zw-pill.solid{background:linear-gradient(135deg,#12A150,#22C55E);color:#fff;box-shadow:0 3px 8px rgba(22,163,74,.3)}
.zw-delta{display:inline-flex;align-items:center;gap:3px;padding:2px 8px;border-radius:8px;font-size:.74rem;font-weight:700}
.zw-delta svg{width:12px;height:12px}
.zw-delta.good{background:var(--g100);color:#15803D;box-shadow:inset 0 0 0 1px #BBF7D0} .zw-delta.bad{background:var(--red-bg);color:var(--red-tx);box-shadow:inset 0 0 0 1px #FECACA} .zw-delta.flat{background:var(--gray-bg);color:var(--gray-tx)}
/* ---------- charts ---------- */
.zw-chart{width:100%;height:auto;display:block;overflow:visible}
.zw-chart text{font-family:Inter,system-ui,sans-serif}
.zw-grid{stroke:#E4EBE7;stroke-dasharray:3 5}
.zw-axis{fill:#93A39A;font-size:11px;font-weight:500}
.zw-line{fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:1;stroke-dashoffset:1;animation:zwDraw 1.5s var(--ease) .15s forwards}
.zw-area{animation:zwFade 1.1s ease .5s both}
.zw-bar{transform-box:fill-box;transform-origin:bottom;animation:zwGrow .9s var(--ease) both}
.zw-seg{fill:none;animation:zwSweep 1.1s var(--ease) both}
.zw-pt .hit{fill:transparent;cursor:pointer} .zw-pt .dot{fill:#fff;stroke-width:2.5;opacity:0;transition:opacity .15s}
.zw-pt .tip{opacity:0;pointer-events:none;transition:opacity .15s,transform .15s;transform:translateY(4px)}
.zw-pt:hover .dot{opacity:1} .zw-pt:hover .tip{opacity:1;transform:none}
.zw-pt .tip rect{fill:#0F1F18;rx:10} .zw-pt .tip text{fill:#fff;font-size:11.5px;font-weight:600} .zw-pt .tip text.s{fill:#9FD6B7;font-weight:500;font-size:10.5px}
.zw-bar-col:hover .zw-bar{filter:brightness(.93)} .zw-bar-col .tip{opacity:0;pointer-events:none;transition:opacity .15s} .zw-bar-col:hover .tip{opacity:1}
.zw-bar-col .tip rect{fill:#0F1F18} .zw-bar-col .tip text{fill:#fff;font-size:11.5px;font-weight:600}
.zw-donut-wrap{display:flex;align-items:center;gap:22px;flex-wrap:wrap}
.zw-legend{display:flex;flex-direction:column;gap:9px;flex:1;min-width:150px}
.zw-legend .it{display:flex;align-items:center;gap:9px;font-size:.84rem;color:var(--text)}
.zw-legend .sw{width:10px;height:10px;border-radius:3px;flex:none}
.zw-legend .it b{margin-left:auto;font-variant-numeric:tabular-nums}
.zw-legend .it i{color:var(--faint);font-style:normal;font-size:.76rem;width:44px;text-align:right}
/* horizontal compare bars (current vs previous) */
.zw-hb{display:grid;grid-template-columns:120px 1fr auto;gap:6px 14px;align-items:center;margin:11px 0}
.zw-hb .lbl{font-size:.86rem;font-weight:600}
.zw-hb .track{position:relative;height:9px;border-radius:9px;background:#EDF2EF;overflow:hidden}
.zw-hb .track.prev{height:6px;margin-top:5px;background:#F3F6F4}
.zw-hb .fill{position:absolute;left:0;top:0;bottom:0;border-radius:9px;transform-origin:left;animation:zwGrowX .9s var(--ease) both}
.zw-hb .val{font-size:.82rem;color:var(--muted);text-align:right;font-variant-numeric:tabular-nums;display:flex;gap:8px;align-items:center;justify-content:flex-end}
.zw-hb .val b{color:var(--text)}
.zw-hb-legend{display:flex;gap:16px;font-size:.76rem;color:var(--faint);margin-top:6px}
.zw-hb-legend i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}
/* heatmap */
.zw-heat{display:grid;gap:6px;align-items:center}
.zw-heat .c{height:38px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:.78rem;font-weight:650;font-variant-numeric:tabular-nums;transition:transform .15s;animation:zwFade .6s ease both}
.zw-heat .c:hover{transform:scale(1.07);z-index:2;box-shadow:0 6px 14px rgba(16,24,40,.18)}
.zw-heat .h{font-size:.74rem;color:var(--faint);font-weight:650;text-align:center}
.zw-heat .r{font-size:.8rem;color:var(--muted);font-weight:600}
/* tables */
.zw-table{width:100%;border-collapse:separate;border-spacing:0;font-size:.88rem}
.zw-table th{background:#F4F7F5;color:var(--muted);font-weight:650;font-size:.76rem;text-align:left;padding:11px 14px;white-space:nowrap}
.zw-table th:first-child{border-radius:12px 0 0 12px} .zw-table th:last-child{border-radius:0 12px 12px 0}
.zw-table td{padding:13px 14px;border-bottom:1px solid #EEF2F0;vertical-align:middle}
.zw-table tr:last-child td{border-bottom:0}
.zw-table tbody tr{transition:background .15s;animation:zwFade .5s ease both} .zw-table tbody tr:hover{background:#F8FBF9}
.zw-table .num{text-align:right;font-variant-numeric:tabular-nums}
.zw-table .name{font-weight:650}
.zw-scroll{overflow-x:auto}
/* insight / notice */
.zw-note{display:flex;gap:12px;padding:14px 16px;border-radius:14px;border:1px solid var(--line);background:#F7FAF8}
.zw-note .zw-ico{width:34px;height:34px}
.zw-note b{display:block;font-size:.92rem;margin-bottom:2px} .zw-note p{margin:0;font-size:.83rem;color:var(--muted);line-height:1.45}
.zw-note.warn{background:#FFFBEB;border-color:#FDE68A} .zw-note.bad{background:#FEF2F2;border-color:#FECACA} .zw-note.good{background:#F0FDF4;border-color:#BBF7D0} .zw-note.info{background:#EFF6FF;border-color:#BFDBFE}
.zw-progress{height:9px;border-radius:9px;background:#EDF2EF;overflow:hidden}
.zw-progress i{display:block;height:100%;border-radius:9px;background:linear-gradient(90deg,#16A34A,#4ADE80);transform-origin:left;animation:zwGrowX 1s var(--ease) both}
.zw-steps{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:2px 0 14px}
.zw-step{display:flex;align-items:center;gap:9px;padding:7px 14px 7px 8px;border-radius:999px;background:#fff;border:1px solid var(--line);font-size:.82rem;font-weight:650;color:var(--faint)}
.zw-step i{width:24px;height:24px;border-radius:50%;background:var(--gray-bg);color:var(--gray-tx);display:flex;align-items:center;justify-content:center;font-style:normal;font-size:.76rem}
.zw-step.on{color:var(--g700);border-color:#BBF7D0;background:var(--g50)} .zw-step.on i{background:linear-gradient(135deg,#12A150,#22C55E);color:#fff}
.zw-step.done i{background:var(--g100);color:var(--g700)} .zw-step.done{color:var(--muted)}
.zw-step-sep{width:26px;height:2px;background:var(--line2);border-radius:2px}
.zw-pick{border:1.5px solid var(--line);border-radius:16px;background:#fff;padding:14px 16px;position:relative;transition:all .22s var(--ease);box-shadow:var(--shadow)}
.zw-pick:hover{border-color:#86EFAC;transform:translateY(-2px);box-shadow:var(--shadow-h)}
.zw-pick.sel{border-color:var(--g500);background:linear-gradient(180deg,#F4FEF7,#fff);box-shadow:0 0 0 3px rgba(34,197,94,.16),var(--shadow)}
.zw-pick .tick{position:absolute;top:12px;right:12px;width:22px;height:22px;border-radius:50%;background:var(--g500);color:#fff;display:none;align-items:center;justify-content:center;animation:zwPop .3s var(--ease)}
.zw-pick.sel .tick{display:flex} .zw-pick .tick svg{width:13px;height:13px;stroke-width:3}
.zw-pick h4{margin:.5rem 0 .1rem;font-size:.95rem;font-weight:700}
.zw-pick p{margin:0;color:var(--muted);font-size:.78rem}
.zw-empty{text-align:center;padding:34px 20px;color:var(--muted)}
.zw-empty .zw-ico{margin:0 auto 10px;width:48px;height:48px;border-radius:16px}
.zw-empty .t{display:block;color:var(--text);font-size:1rem;font-weight:700;margin-bottom:4px}
.zw-mini{font-size:.76rem;color:var(--faint)}
.zw-kv{display:grid;grid-template-columns:auto 1fr;gap:6px 14px;font-size:.86rem} .zw-kv span{color:var(--faint)} .zw-kv b{font-weight:600}
.zw-ring text{font-family:Inter,system-ui,sans-serif}
.leaflet-container{border-radius:16px}
[data-testid="stCustomComponentV1"]{border-radius:16px;overflow:hidden;box-shadow:var(--shadow)}
@media (max-width:900px){[data-testid="stMainBlockContainer"]{padding:1rem}.zw-hb{grid-template-columns:90px 1fr auto}}
"""

def inject():
    st.markdown(f"<style>{CSS}</style>", unsafe_allow_html=True)

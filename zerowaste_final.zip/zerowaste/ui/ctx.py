"""Shared app context: cached data loaders, kitchen settings, page registry, search and notifications."""
import os
from datetime import datetime
import pandas as pd
import streamlit as st
import config as C
from services import wastelog as W, impact
from services.event_model import EventModel
from services.ngo_matcher import load_partners
from services.recipes import load_catalog

PAGES = {}            # filled by app.py: key -> st.Page

TITLES = {"dashboard": "Dashboard", "waste_log": "Waste Log", "forecast": "Forecast & Risk", "planner": "Menu Planner",
          "redistribute": "Redistribution", "partners": "Partners", "settings": "Settings & Data"}

# ---------------------------------------------------------------- data
@st.cache_data(show_spinner=False)
def _waste(sig):
    return W.load_log()

def waste():
    path = W.ensure_live_log()
    stt = os.stat(path)
    return _waste((stt.st_mtime_ns, stt.st_size, path))

@st.cache_data(show_spinner=False)
def _partners(sig):
    return load_partners(C.PARTNERS_CSV)

def partners():
    stt = os.stat(C.PARTNERS_CSV)
    return _partners((stt.st_mtime_ns, stt.st_size))

@st.cache_resource(show_spinner="Training the waste-risk model on your event data…")
def event_model():
    return EventModel.fit()

@st.cache_resource
def catalog():
    return load_catalog()

# ---------------------------------------------------------------- settings
# Stateful (non-button) widgets whose values must survive visiting another page.
PERSIST_KEYS = {
    "gsearch", "dash_range",
    "rd_item", "rd_qty", "rd_ftype", "rd_veg", "rd_mins", "rd_chilled", "rd_n", "rd_sort", "rd_only",
    "pl_meal", "pl_nonveg", "pl_pots", "pl_staff", "pl_window", "pl_veg",
    "wl_meal", "wl_section", "wl_cat", "wl_range", "wl_search", "wl_rows",
    "dir_search", "dir_level", "dir_sort", "dir_loc", "dir_selected",
    "fx_meal", "fx_day",
    "rk_food_type", "rk_event_type", "rk_guests", "rk_quantity", "rk_prep", "rk_storage", "rk_purchase", "rk_pricing", "rk_season", "rk_location",
    "set_name", "set_area", "set_lat", "set_lon", "set_road", "set_head", "set_pots", "set_staff", "set_window", "set_veg",
}
PERSIST_PREFIXES = ("pl_servings_",)

def default_settings():
    return {"use_road": True, "headcount": 450, "pots": C.KITCHEN_DEFAULTS["pots"], "staff": C.KITCHEN_DEFAULTS["staff"],
            "window_min": C.KITCHEN_DEFAULTS["window_min"], "veg_target": int(C.KITCHEN_DEFAULTS["veg_target"] * 100)}

def default_kitchen():
    la, lo = C.KITCHEN_AREAS["Koramangala"]
    return {"name": "My Kitchen", "area": "Koramangala", "lat": la, "lon": lo}

def init():
    st.session_state.setdefault("settings", default_settings())
    st.session_state.setdefault("kitchen", default_kitchen())

def settings():
    init()
    return st.session_state["settings"]

PERSIST_KEYS = (
    "rd_item", "rd_qty", "rd_ftype", "rd_veg", "rd_mins", "rd_chilled", "rd_n", "rd_sort", "rd_only",
    "pl_meal", "pl_nonveg", "pl_pots", "pl_staff", "pl_window", "pl_veg",
    "wl_meal", "wl_section", "wl_cat", "wl_range", "wl_search", "wl_rows",
    "dir_search", "dir_level", "dir_sort", "dir_loc", "dir_selected", "fx_meal", "fx_day", "dash_range", "gsearch",
    "rk_food_type", "rk_event_type", "rk_guests", "rk_quantity", "rk_prep", "rk_storage", "rk_purchase", "rk_pricing", "rk_season", "rk_location",
)
PERSIST_PREFIXES = ("pl_servings_",)

def persist_widget_state():
    """Streamlit drops the state of widgets that are not drawn on the current page. Re-assigning the value keeps it,
    so choices made on one page survive a visit to another page. Only an explicit list of VALUE widgets is touched:
    buttons must never be re-assigned (that would make them look pre-clicked)."""
    for k in list(st.session_state.keys()):
        if isinstance(k, str) and (k in PERSIST_KEYS or k.startswith(PERSIST_PREFIXES)):
            try:
                st.session_state[k] = st.session_state[k]
            except Exception:
                pass

def ensure(key, value):
    """Initialise a widget's state once (instead of passing default=/value= to the widget, which clashes with persisted state)."""
    st.session_state.setdefault(key, value)

def kitchen():
    init()
    return st.session_state["kitchen"]

def set_kitchen(name=None, area=None, lat=None, lon=None):
    k = dict(kitchen())
    if name is not None: k["name"] = name
    if area is not None:
        k["area"] = area
        if area in C.KITCHEN_AREAS: k["lat"], k["lon"] = C.KITCHEN_AREAS[area]
    if lat is not None and lon is not None:
        k["lat"], k["lon"] = float(lat), float(lon)
        if area is None: k["area"] = "Custom location"
    st.session_state["kitchen"] = k
    return k

# ---------------------------------------------------------------- navigation
def go(key):
    """Navigate to a page (works inside the running app; in tests it records the request)."""
    st.session_state["_nav_request"] = key
    page = PAGES.get(key)
    if page is not None:
        st.switch_page(page)

def consume(key, value):
    """Return `value` only the first time it is seen (map components re-send their last click on every rerun)."""
    if value is None:
        return None
    marker = f"_seen_{key}"
    if st.session_state.get(marker) == value:
        return None
    st.session_state[marker] = value
    return value

# ---------------------------------------------------------------- search + notifications
def search(q, limit=6):
    q = (q or "").strip().lower()
    if len(q) < 2:
        return []
    out = [("page", k, t) for k, t in TITLES.items() if q in t.lower()]
    p = partners()
    for _, r in p.iterrows():
        if q in f"{r['name']} {r['area']} {r['type']}".lower():
            out.append(("partner", r["name"], f"{r['area'] or 'Bengaluru'} · {r['type']}"))
    return out[:limit]

def notifications():
    items = []
    df = waste()
    last = df["date"].max()
    days = (pd.Timestamp(datetime.now().date()) - last).days
    if days > 7:
        items.append(("warn", "Waste log is not up to date", f"The latest entry is {last:%d %b %Y} ({days} days ago). Log recent waste to keep insights current."))
    t = W.factor_tests(df)
    noise = int((t["verdict"] == "Looks like noise").sum())
    items.append(("info", "Pattern check", f"{noise} of {len(t)} factors (meal, section, category, weekday) show no real difference in waste: expect similar waste everywhere."))
    p = partners()
    conf = int((p["accepts_surplus"] == "yes").sum()); likely = int((p["accepts_surplus"] == "likely").sum())
    items.append(("good", "Partners ready", f"{conf} partners confirm they take surplus food and {likely} more are reported partners."))
    if impact.read_donations().empty:
        items.append(("info", "No donations recorded yet", "Use Redistribution to find a partner and record a donation."))
    return items

"""Dashboard: KPIs, waste trend, category split, meal comparison, pattern reality check, next actions, recent activity."""
import pandas as pd
import streamlit as st
import config as C
from services import wastelog as W, impact
from ui import ctx, shell, dialogs
from ui.kit import fmt_p, show, kpi_card, card, table, pill, delta, note, money, esc, icon, empty, panel
from ui import charts as ch

CAT_COLORS = {"Rice": "#16A34A", "Meat": "#3B82F6", "Vegetables": "#F59E0B", "Soup": "#8B5CF6"}

def _card_head(title, sub=""):
    return f'<div class="zw-card-head"><div><h3>{esc(title)}</h3>{f"<div class=zw-sub>{sub}</div>" if sub else ""}</div></div>'

def render():
    df = ctx.waste(); don = impact.read_donations(); ds = impact.donation_summary(don)
    k = W.kpis(df); p = ctx.partners()
    shell.header("Dashboard", f"Kitchen waste and redistribution overview · data through <b>{df['date'].max():%d %b %Y}</b>")
    a1, a2, a3 = st.columns([8, 1.5, 1.6])
    if a2.button("Find a partner", key="dash_find", width="stretch"):
        ctx.go("redistribute")
    if a3.button("＋ Log waste", type="primary", key="dash_log", width="stretch"):
        dialogs.log_waste()

    daily = df.groupby("date")["weight_kg"].sum().tail(14).tolist()
    daily_cost = df.groupby("date")["cost"].sum().tail(14).tolist()
    confirmed = int((p["accepts_surplus"].isin(["yes", "likely"])).sum())
    c = st.columns(4, gap="medium")
    with c[0]:
        show(kpi_card("Waste · last 7 days", f'{k["weight"]["value"]:,.1f}', "scale", "green", unit="kg", chip=delta(k["weight"]["delta_pct"], "down"),
                      sub=f'vs <b>{k["weight"]["previous"]:,.1f} kg</b> the week before', spark=ch.sparkline(daily, "#16A34A", "k1"), delay=0))
    with c[1]:
        show(kpi_card("Cost lost · last 7 days", money(k["cost"]["value"], 0), "wallet", "amber", chip=delta(k["cost"]["delta_pct"], "down"),
                      sub=f'vs <b>{money(k["cost"]["previous"], 0)}</b> the week before', spark=ch.sparkline(daily_cost, "#F59E0B", "k2"), delay=70))
    with c[2]:
        show(kpi_card("Redistributed", f'{ds["kg"]:,.1f}', "heart-handshake", "blue", unit="kg",
                      sub=(f'<b>{ds["batches"]}</b> batches · ≈ <b>{ds["meals"]:.0f}</b> meals' if ds["batches"] else "No donations recorded yet"), delay=140))
    with c[3]:
        show(kpi_card("Partners on file", f'{len(p)}', "map-pin", "violet", sub=f'<b>{confirmed}</b> confirmed or reported', delay=210))

    st.write("")
    left, right = st.columns([2.1, 1], gap="medium")
    with left:
        with panel():
            h1, h2 = st.columns([2.2, 1], vertical_alignment="center")
            with h1:
                show(_card_head("Waste trend", "Total waste per period from your canteen log"))
            with h2:
                ctx.ensure("dash_range", "Week")
                st.session_state.setdefault("dash_range", "Week")
                rng = st.segmented_control("Trend range", ["Day", "Week", "Month"], key="dash_range", label_visibility="collapsed") or "Week"
            pts = W.trend(df, rng)
            show(ch.area_chart(pts, uid="trend", unit="kg"))
            avg = sum(v for _, v in pts) / len(pts)
            show(f'<div class="zw-mini"><span style="color:#16A34A;font-weight:700">- - -</span> average {avg:,.0f} kg per period. Showing {"the last 14 days" if rng == "Day" else ("weekly totals" if rng == "Week" else "monthly totals (first and last month are partial)")}. Hover a point for the exact value.</div>')
    with right:
        with panel():
            show(_card_head("Waste by category", "All logged days, kg"))
            bc = W.by_category(df)
            show(ch.donut([(r.category, r.kg, CAT_COLORS.get(r.category, "#94A3B8")) for r in bc.itertuples()], f"{bc.kg.sum():,.0f}", "kg total", uid="cat", size=170))
            top_cost = bc.sort_values("cost", ascending=False).iloc[0]
            share_w = 100 * bc.set_index("category").loc[top_cost.category, "kg"] / bc.kg.sum()
            show(f'<div class="zw-mini" style="margin-top:10px"><b>{esc(top_cost.category)}</b> is {share_w:.0f}% of the weight but {100 * top_cost.cost / bc.cost.sum():.0f}% of the cost.</div>')

    r3 = st.columns([1.3, 1.2, 1], gap="medium")
    with r3[0]:
        with panel():
            show(_card_head("Meals: last 7 days vs the week before", "Total waste per meal"))
            show(ch.hbar_compare(W.compare_by(df, "meal"), "kg", cur_label="Last 7 logged days", prev_label="Week before"))
    with r3[1]:
        with panel():
            show(_card_head("Pattern reality check", "Do meals, sections, categories or weekdays differ?"))
            t = W.factor_tests(df)
            rows = [[f'<span class="name">{esc(r.factor)}</span>', f"{r.spread_pct:.1f}%", fmt_p(r.p_holm, 2),
                     pill({"Real difference": "Real", "Looks like noise": "Noise"}.get(r.verdict, "n/a"), "green" if r.verdict == "Real difference" else "gray", dot=True)] for r in t.itertuples()]
            show(table(["Factor", "Spread", "p (adj.)", "Verdict"], rows, ["", "num", "num", ""]))
            if (t["verdict"] == "Not enough groups").all():
                show(note("Not enough data", "Pattern tests need at least two groups.", "info", "info"))
            elif (t["verdict"] == "Real difference").any():
                show(note("Some real differences found", "Focus on the factors marked real.", "good", "sparkles"))
            else:
                show(f'<div style="height:8px"></div>' + note("No reliable hotspot", "Differences are within normal variation after correcting for multiple tests, so waste is spread evenly. Cut waste everywhere and use partners for leftovers.", "info", "info"))
    with r3[2]:
        with panel():
            show(_card_head("Next best actions"))
            stale = (pd.Timestamp.now().normalize() - df["date"].max()).days
            if stale > 7:
                show(note("Log recent waste", f"Latest entry is {df['date'].max():%d %b %Y} ({stale} days ago).", "warn", "triangle-alert") + '<div style="height:8px"></div>')
            if not ds["batches"]:
                show(note("Record your first donation", "Find a partner for today's leftovers and record it.", "info", "heart-handshake") + '<div style="height:8px"></div>')
            bc2 = W.by_category(df).set_index("category")
            show(note("Biggest money leak", f"{esc(bc2['cost'].idxmax())} costs {money(bc2['cost'].max(), 0)} in logged waste, the most of any category.", "good", "wallet"))

    with panel():
        h1, h2 = st.columns([4, 1], vertical_alignment="center")
        with h1:
            show(_card_head("Recent activity", "Latest waste entries and donations"))
        if h2.button("Open waste log", key="dash_open_log", width="stretch"):
            ctx.go("waste_log")
        bands = W.weight_bands(df)
        rows = []
        recent = df.sort_values(["date"], kind="stable").tail(6).iloc[::-1]
        for r in recent.itertuples():
            b = W.band(r.weight_kg, bands)
            rows.append((r.date, [f"{r.date:%d %b %Y}", f"Waste logged · {esc(r.meal)} · Section {esc(r.section)}", pill(r.category, "gray"),
                                  f"{r.weight_kg:.2f} kg", money(r.cost, 2), pill(f"{b} waste", {"High": "red", "Medium": "amber", "Low": "green"}[b], dot=True)]))
        for r in don.sort_values("date", ascending=False).head(3).itertuples():
            rows.append((r.date, [f"{r.date:%d %b %Y}", f"Donation · {esc(r.item)} → {esc(r.partner)}", pill(str(r.food_type).split(' / ')[0], "gray"),
                                  f"{float(r.qty_kg):.2f} kg", "–", pill("Donated", "blue", dot=True)]))
        rows.sort(key=lambda t: t[0], reverse=True)
        show(table(["Date", "Activity", "Category", "Weight", "Cost", "Status"], [r[1] for r in rows], ["", "", "", "num", "num", ""]))

"""Settings & Data: kitchen location (area list, coordinates or click on the map), preferences, data sources and model cards."""
import os
import shutil
import streamlit as st
import config as C
from services import wastelog as W, impact
from ui import ctx, shell
from ui.kit import show, kpi_card, table, pill, note, money, esc, icon, kv, panel
from ui.maps import picker_map, render_map
from views.dashboard import _card_head

def _sync():
    S = ctx.settings()
    S["use_road"] = bool(st.session_state["set_road"]); S["headcount"] = int(st.session_state["set_head"])
    S["pots"] = int(st.session_state["set_pots"]); S["staff"] = int(st.session_state["set_staff"])
    S["window_min"] = int(st.session_state["set_window"]); S["veg_target"] = int(st.session_state["set_veg"])

def render():
    shell.header("Settings & Data", "Kitchen location, preferences, and where every number in the app comes from")
    S = ctx.settings(); k = ctx.kitchen()
    if st.session_state.get("_settings_warning"):
        st.warning(st.session_state.pop("_settings_warning"))
    t1, t2, t3 = st.tabs(["Kitchen & preferences", "Data & models", "About & assumptions"])
    with t1:
        l, r = st.columns([1, 1.25], gap="medium")
        with l:
            with panel():
                show(_card_head("Kitchen location", "Distances to partners are measured from here"))
                name = st.text_input("Kitchen name", k["name"], key="set_name")
                areas = list(C.KITCHEN_AREAS) + ["Custom location"]
                area = st.selectbox("Area", areas, index=areas.index(k["area"]) if k["area"] in areas else len(areas) - 1, key="set_area")
                if st.button("Save kitchen", type="primary", key="set_save_k", width="stretch"):
                    if area != "Custom location": ctx.set_kitchen(name=name, area=area)
                    else: ctx.set_kitchen(name=name)
                    st.rerun()
                a, b = st.columns(2)
                lat = a.number_input("Latitude", value=float(k["lat"]), format="%.5f", step=0.001, key="set_lat")
                lon = b.number_input("Longitude", value=float(k["lon"]), format="%.5f", step=0.001, key="set_lon")
                if st.button("Use these coordinates", key="set_coords", width="stretch"):
                    if not (12.7 <= lat <= 13.4 and 77.3 <= lon <= 77.9):
                        st.session_state["_settings_warning"] = "These coordinates are outside Bengaluru. Partner distances may be meaningless."
                    ctx.set_kitchen(lat=lat, lon=lon, area="Custom location"); st.rerun()
                show(f'<div class="zw-mini">Current: <b>{esc(k["name"])}</b>, {esc(k["area"])} ({k["lat"]:.5f}, {k["lon"]:.5f}).<br>Tip: click the map to pick an exact spot, then confirm.</div>')
        with r:
            with panel():
                show(_card_head("Pick on the map", "Click anywhere to choose your kitchen's exact location"))
                picked = st.session_state.get("picked")
                out = render_map(picker_map(k, picked), key="set_map", height=420)
                click = ctx.consume("set_map_click", (round(out["click"]["lat"], 5), round(out["click"]["lng"], 5)) if out["click"] else None)
                if click:
                    st.session_state["picked"] = click; st.rerun()
                if picked:
                    c1, c2 = st.columns([2.2, 1], vertical_alignment="center")
                    with c1:
                        show(f'<div style="font-weight:700">New location: {picked[0]:.5f}, {picked[1]:.5f}</div>')
                    if c2.button("Use this location", type="primary", key="set_use_pick", width="stretch"):
                        ctx.set_kitchen(lat=picked[0], lon=picked[1], area="Custom location"); st.session_state.pop("picked", None); st.rerun()
                else:
                    st.caption("No point picked yet.")
        with panel():
            show(_card_head("Preferences"))
            a, b, c, d, e = st.columns(5, gap="medium")
            a.toggle("Real road distance", value=S["use_road"], key="set_road", on_change=_sync, help="Uses the free OSRM routing service. Falls back to an estimate when offline.")
            b.number_input("Default servings", 20, 20000, S["headcount"], 10, key="set_head", on_change=_sync)
            c.number_input("Pots / vessels", 1, 50, S["pots"], key="set_pots", on_change=_sync)
            d.number_input("Cooks available", 1, 50, S["staff"], key="set_staff", on_change=_sync)
            e.number_input("Cooking window (min)", 30, 600, S["window_min"], 15, key="set_window", on_change=_sync)
            st.slider("Minimum vegetarian share of the menu (%)", 0, 100, S["veg_target"], key="set_veg", on_change=_sync)
    with t2:
        df = ctx.waste(); q = W.data_quality(df); ev = ctx.event_model(); mt = ev.metrics; p = ctx.partners(); cat = ctx.catalog()
        c = st.columns(3, gap="medium")
        with c[0]:
            with panel():
                show(_card_head("Canteen waste log", "Dataset Propely.csv (provided)"))
                show(kv([("Entries", f'<b>{q["rows"]:,}</b>'), ("Days", f'<b>{q["days"]}</b>'), ("Period", f'{q["start"]:%d %b %Y} to {q["end"]:%d %b %Y}'),
                         ("Meals", esc(", ".join(q["meals"]))), ("Sections", esc(", ".join(q["sections"]))), ("Categories", esc(", ".join(q["categories"]))),
                         ("Cost = weight x price", pill("Consistent", "green", dot=True) if q["cost_consistent"] else pill("Mismatch", "red", dot=True))]))
                show('<div class="zw-mini" style="margin-top:8px">Powers: Dashboard, Waste Log, expected waste per meal, typical leftover amounts in Redistribution. New entries are appended to <code>data/waste_log.csv</code>; the original file is never changed.</div>')
        with c[1]:
            with panel():
                show(_card_head("Event waste records", "food_wastage_data.csv (provided)"))
                show(kv([("Unique events", f'<b>{mt["rows"]:,}</b>'), ("Duplicates removed", f'<b>{mt["duplicates_removed"]}</b>'), ("Model", "Random Forest on waste % of quantity"),
                         ("Validation", esc(mt["cv"])), ("Average error", f'<b>{mt["mae"]:.2f} units</b> (guessing the average: {mt["mae_baseline_mean"]:.2f})'),
                         ("R²", f'<b>{mt["r2"]:.2f}</b>'), ("80% range hit-rate", f'<b>{100 * mt["coverage_80"]:.0f}%</b>')]))
                show('<div class="zw-mini" style="margin-top:8px">Powers: the batch & event risk predictor and its what-if levers.</div>')
        with c[2]:
            with panel():
                show(_card_head("Partners", "bengaluru_food_redistribution_partners.xlsx (provided)"))
                show(kv([("Organisations", f'<b>{len(p)}</b>'), ("With a location", f'<b>{int(p.latitude.notna().sum())}</b>'), ("Confirmed intake", f'<b>{int((p.accepts_surplus == "yes").sum())}</b>'),
                         ("Reported intake", f'<b>{int((p.accepts_surplus == "likely").sum())}</b>'), ("Map positions", "approximate area centres")]))
                show('<div class="zw-mini" style="margin-top:8px">Positions were placed at area level, so distances can be off by 1 to 3 km. Check a pin on the Partners map and correct <code>data/partners.csv</code> if needed.</div>')
        with panel():
            show(_card_head("Reference data used by the Menu Planner", "Not kitchen data: typical values so the planner can work without your recipes"))
            show(kv([("Recipes", f'<b>{len(cat.recipes)}</b> South-Indian institutional dishes'), ("Ingredients", f'<b>{len(cat.prices)}</b> with approximate wholesale prices (INR per kg)'),
                     ("Stock sample", "data/inventory_sample.csv (edit it in the planner)")]))
        with panel():
            show(_card_head("Maintenance"))
            a, b = st.columns(2, gap="medium")
            with a:
                st.caption("Restore the waste log to the original provided dataset (removes entries you added).")
                ok = st.checkbox("I understand this deletes my added entries", key="set_ok_reset")
                if st.button("Reset waste log", key="set_reset_log", disabled=not ok):
                    shutil.copy(C.RAW_WASTE_CSV, C.WASTE_LOG); st.cache_data.clear(); st.session_state["_toast"] = "Waste log restored to the original dataset."; st.rerun()
            with b:
                st.caption("Delete all recorded donations.")
                ok2 = st.checkbox("I understand this deletes the donation log", key="set_ok_don")
                if st.button("Clear donation log", key="set_clear_don", disabled=not ok2):
                    if os.path.exists(C.DONATION_LOG): os.remove(C.DONATION_LOG)
                    st.session_state["_toast"] = "Donation log cleared."; st.rerun()
    with t3:
        l, r = st.columns(2, gap="medium")
        with l:
            show(note("Honest limits", "Waste per entry in the canteen log is statistically similar across meals, sections, categories and weekdays, so expected waste is the plain average. The event model is accurate on its dataset, but that data is event catering, not daily service. Partner map positions are approximate, and most partners have not publicly confirmed surplus intake.", "info", "info"))
        with r:
            show(note("Assumptions you can change", f"Safe-time windows per food type (services/safety_rules.py) are conservative estimates to be checked against FSSAI guidance. Trip time = road time x {C.TRAFFIC_FACTOR} traffic factor + {C.HANDLING_MIN} min handling, with a {C.BUFFER_MIN} min safety buffer. 1 meal = {C.MEAL_KG} kg and {C.CO2E_PER_KG} kg CO2e per kg of food are assumed factors. All are in config.py.", "warn", "triangle-alert"))

"""Redistribution: what is left -> safe window -> ranked recipients (cards + interactive map) -> confirm and record.
The app never contacts anyone: it shows contact details and directions."""
from datetime import datetime, timedelta
import streamlit as st
import config as C
from services import wastelog as W, impact, repurposer, routing
from services.ngo_matcher import rank_partners
from services.safety_rules import food_types, safe_until, is_cooked, SAFE_HOURS
from services.links import google_directions_url, google_place_url, osm_url
from ui import ctx, shell
from ui.kit import show, pick_card, steps, note, pill, esc, icon, kv, table, empty, money, panel
from ui import charts as ch
from ui.maps import recommendation_map, render_map
from views.dashboard import _card_head

ICON = {"Rice": "wheat", "Meat": "beef", "Vegetables": "carrot", "Soup": "soup"}
TONE = {"Rice": "amber", "Meat": "red", "Vegetables": "green", "Soup": "violet"}
SORTS = {"Best match": "best", "Nearest": "nearest", "Fastest": "fastest"}

@st.cache_data(ttl=3600, show_spinner=False)
def _road_times(klat, klon, pts):
    return routing.road_times({"lat": klat, "lon": klon}, list(pts))

@st.cache_data(ttl=3600, show_spinner=False)
def _path(klat, klon, lat, lon):
    return routing.route_path({"lat": klat, "lon": klon}, lat, lon)

def _apply_pick(cat, df):
    t = W.typical_entry(df, cat); ftype, veg = C.WASTE_CATEGORY_MAP[cat]
    st.session_state.update({"rd_cat": cat, "rd_item": f"{cat} leftovers", "rd_qty": float(round(t["mean"], 1)), "rd_ftype": ftype, "rd_veg": "Veg" if veg else "Non-veg"})

def _defaults(df):
    if "rd_cat" not in st.session_state:
        _apply_pick("Rice", df)
    st.session_state.setdefault("rd_mins", 60)
    st.session_state.setdefault("rd_chilled", False)

def _sig():
    """The batch details a recipient search was made for; if they change, the old results are stale."""
    g = st.session_state
    return (g["rd_item"], float(g["rd_qty"]), g["rd_veg"], g["rd_ftype"], bool(g["rd_chilled"]), int(g["rd_mins"]))

def _fmt_left(minutes):
    m = int(max(minutes, 0)); return f"{m // 60}h {m % 60:02d}m"

@st.dialog("Donation planned", width="small")
def donation_dialog(info):
    show(f'<div style="text-align:center;padding:4px 0 10px"><div style="width:72px;height:72px;border-radius:50%;margin:0 auto 12px;background:linear-gradient(135deg,#12A150,#4ADE80);'
         f'display:flex;align-items:center;justify-content:center;color:#fff;animation:zwPop .5s var(--ease) both;box-shadow:0 10px 24px rgba(22,163,74,.4)">{icon("check", 34, 3)}</div>'
         f'<div style="font-size:1.25rem;font-weight:800">Saved to your donation log</div><div class="zw-sub">ZeroWaste does not contact anyone. Please phone the partner before you go.</div></div>')
    show('<div class="zw-card" style="box-shadow:none">' + kv([("Partner", esc(info["partner"])), ("Phone", esc(info["phone"] or "not listed")), ("Food", f'{esc(info["item"])} · {info["qty"]:g} kg'),
                                                               ("Trip", f'{info["distance_km"]} km · about {info["eta_min"]} min'), ("Safe until", esc(info["safe_until"]))]) + "</div>")
    c = st.columns(2)
    c[0].link_button("Directions", info["directions"], width="stretch")
    if c[1].button("Done", type="primary", key="rd_done", width="stretch"):
        st.rerun()

def render():
    df = ctx.waste(); k = ctx.kitchen(); partners = ctx.partners()
    shell.header("Redistribution", "Find a safe, reachable partner for today's leftover food")
    pre = st.session_state.pop("prefill", None)
    if pre:
        st.session_state.update({"rd_item": pre["item"], "rd_qty": float(max(0.5, pre["qty"])), "rd_ftype": pre["ftype"], "rd_veg": "Veg" if pre["veg"] else "Non-veg", "rd_cat": None})
        st.session_state.pop("rd_query", None); st.session_state.pop("rd_selected", None)
    _defaults(df)
    q = st.session_state.get("rd_query")
    show(steps(["What is left", "Choose a recipient", "Confirm"], 3 if st.session_state.get("rd_selected") and q else (2 if q else 1)))

    with panel():
        show(_card_head("1 · What is left over?", "Pick a category to prefill typical amounts from your waste log, then adjust"))
        cols = st.columns(len(C.WASTE_CATEGORY_MAP), gap="medium")
        for col, cat in zip(cols, C.WASTE_CATEGORY_MAP):
            t = W.typical_entry(df, cat)
            with col:
                show(pick_card(ICON[cat], cat, f'Typical leftover <b>{t["mean"]:.1f} kg</b>', f'80% range {t["p10"]:.1f}–{t["p90"]:.1f} kg', selected=(st.session_state.get("rd_cat") == cat), tone=TONE[cat]))
                if st.button(f"Use {cat}", key=f"rd_pick_{cat}", width="stretch", type="primary" if st.session_state.get("rd_cat") == cat else "secondary"):
                    _apply_pick(cat, df); st.session_state.pop("rd_query", None); st.rerun()
        a, b, c = st.columns([1.4, 1, 1.6])
        a.text_input("Item", key="rd_item")
        b.number_input("Quantity (kg)", min_value=0.5, max_value=500.0, step=0.5, key="rd_qty")
        c.selectbox("Food type", food_types(), key="rd_ftype", help="Decides how long the food stays safe")
        d, e, f = st.columns([1.2, 1.2, 1.4], vertical_alignment="bottom")
        d.segmented_control("Diet", ["Veg", "Non-veg"], key="rd_veg")
        e.number_input("Cooked how many minutes ago?", min_value=0, max_value=2000, step=15, key="rd_mins")
        f.toggle("Chilled promptly", key="rd_chilled")
        now = datetime.now()
        cooked_at = now - timedelta(minutes=int(st.session_state["rd_mins"]))
        sa = safe_until(st.session_state["rd_ftype"], cooked_at, st.session_state["rd_chilled"])
        left = (sa - now).total_seconds() / 60
        total = SAFE_HOURS[st.session_state["rd_ftype"]][1 if st.session_state["rd_chilled"] else 0] * 60
        r1, r2 = st.columns([1, 3], vertical_alignment="center")
        with r1:
            show(ch.ring(100 * left / total if total else 0, _fmt_left(left), "safe time left", color="#16A34A" if left > 90 else ("#F59E0B" if left > 0 else "#EF4444"), size=124))
        with r2:
            if left <= 0:
                show(note("Past its safe window", "This batch should not be served or donated for eating. See the reuse and disposal options below.", "bad", "circle-alert"))
            else:
                show(note(f"Safe until {sa:%d %b, %H:%M}", f'{_fmt_left(left)} left for {esc(st.session_state["rd_item"])} ({st.session_state["rd_qty"]:g} kg). Partners must be reachable before this minus a {C.BUFFER_MIN}-minute buffer.', "good", "shield-check"))
            if st.button("Find recipients", type="primary", key="rd_find"):
                st.session_state["rd_query"] = {"qid": datetime.now().isoformat(), "item": st.session_state["rd_item"], "qty": float(st.session_state["rd_qty"]), "veg": st.session_state["rd_veg"] == "Veg",
                                                "ftype": st.session_state["rd_ftype"], "chilled": st.session_state["rd_chilled"], "cooked_at": cooked_at, "sig": _sig()}
                st.session_state.pop("rd_selected", None); st.rerun()

    q = st.session_state.get("rd_query")
    if q and q.get("sig") != _sig():
        show('<div style="height:10px"></div>' + note("Batch details changed", "Press <b>Find recipients</b> to refresh the recipient list for the new details.", "warn", "refresh-cw"))
        _reuse(st.session_state["rd_ftype"], left, st.session_state["rd_chilled"], expanded=(left <= 0))
        return
    if not q:
        show('<div style="height:10px"></div>' + empty("heart-handshake", "No search yet", "Press <b>Find recipients</b> to rank partners by safety, distance and whether they accept surplus food."))
        _reuse(st.session_state["rd_ftype"], left, st.session_state["rd_chilled"], expanded=(left <= 0))
        return

    sa = safe_until(q["ftype"], q["cooked_at"], q["chilled"]); now = datetime.now(); left = (sa - now).total_seconds() / 60
    show(_card_head("2 · Choose a recipient", f'{esc(q["item"])} · {q["qty"]:g} kg · {"veg" if q["veg"] else "non-veg"} · {_fmt_left(left)} of safe time left'))
    ctl = st.columns([1.1, 2.3, 1.3, 1.8], gap="medium", vertical_alignment="bottom")
    ctx.ensure("rd_n", C.TOP_N); ctx.ensure("rd_sort", "Best match"); ctx.ensure("rd_only", False)
    n = ctl[0].slider("Results", 1, 10, key="rd_n")
    st.session_state.setdefault("rd_sort", "Best match")
    sort = ctl[1].segmented_control("Sort by", list(SORTS), key="rd_sort") or "Best match"
    only = ctl[2].toggle("Confirmed only", key="rd_only")
    if left <= 0:
        show(note("Past its safe window", "No partner can receive this batch.", "bad", "circle-alert")); _reuse(q["ftype"], left, q["chilled"], True); return
    road = None
    if ctx.settings()["use_road"]:
        loc = partners.dropna(subset=["latitude", "longitude"])
        try:
            road = _road_times(k["lat"], k["lon"], tuple(zip(loc["name"], loc["latitude"], loc["longitude"])))
        except routing.RoutingError:
            ctl[3].caption("Road routing unavailable: using estimated trip times.")
    res, rej = rank_partners(partners, k, {"quantity_kg": q["qty"], "veg": q["veg"], "cooked": is_cooked(q["ftype"]), "safe_until": sa}, now=now, top_n=n,
                             only_confirmed=only, road=road, sort_by=SORTS[sort])
    if road:
        for r in res:
            try: r["path"] = _path(k["lat"], k["lon"], r["lat"], r["lon"])
            except routing.RoutingError: pass
    names = [r["name"] for r in res]
    if res and st.session_state.get("rd_selected") not in names:
        st.session_state["rd_selected"] = names[0]
    if not res:
        show(note("No partner can safely receive this batch in time", "Try chilling the food, picking a nearer kitchen location in Settings, or use the reuse ideas below.", "bad", "circle-alert"))
    left_col, right_col = st.columns([1.15, 1], gap="medium")
    with left_col:
        for i, r in enumerate(res, 1):
            sel = r["name"] == st.session_state.get("rd_selected")
            with panel():
                c1, c2, c3 = st.columns([0.45, 3.7, 1.35], vertical_alignment="center")
                with c1:
                    show(f'<div class="zw-rank {"on" if sel else ""}">{i}</div>')
                with c2:
                    lvl = {"yes": ("Surplus intake confirmed", "green"), "likely": ("Reported partner", "amber"), "unconfirmed": ("Not confirmed, call first", "gray")}[r["surplus_level"]]
                    show(f'<div style="font-weight:700;font-size:.98rem">{esc(r["name"])} {pill("Selected", "solid", ico="check") if sel else ""}</div>'
                         f'<div class="zw-sub">{esc(r["type"])}{" · " + esc(r["area"]) if r["area"] else ""}</div>'
                         f'<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">{pill(f"{r["distance_km"]} km", "blue", ico="navigation")}{pill(f"~{r["eta_min"]} min", "gray", ico="clock")}'
                         f'{pill(f"{r["spare_min"]} min spare", "green" if r["spare_min"] > 30 else "amber", ico="timer")}{pill(*lvl, dot=True)}</div>'
                         f'<div class="zw-mini" style="margin-top:6px">📞 <b>{esc(r["phone"] or "not listed")}</b>{" · " + esc(r["email"]) if r["email"] else ""}</div>'
                         + "".join(f'<div class="zw-mini">• {esc(x)}</div>' for x in r["notes"]))
                with c3:
                    if st.button("Selected ✓" if sel else "Select", key=f"rd_sel_{i}", type="primary" if sel else "secondary", width="stretch"):
                        st.session_state["rd_selected"] = r["name"]; st.rerun()
                    st.link_button("Directions", r["maps_url"], width="stretch")
    with right_col:
        shown = {r["name"] for r in res}
        others = [{"name": p["name"], "lat": float(p["latitude"]), "lon": float(p["longitude"]), "phone": p["phone"], "sub": str(p["area"]) or "Bengaluru"}
                  for _, p in partners.dropna(subset=["latitude", "longitude"]).iterrows() if p["name"] not in shown]
        out = render_map(recommendation_map(k, res, others, st.session_state.get("rd_selected")), key="rd_map", height=520)
        hit = ctx.consume("rd_map_tip", out["tooltip"])
        if hit in names and hit != st.session_state.get("rd_selected"):
            st.session_state["rd_selected"] = hit; st.rerun()
        show('<div class="zw-mini" style="margin-top:6px"><span style="color:#EF4444;font-weight:700">●</span> your kitchen &nbsp; <span style="color:#2563EB;font-weight:700">●</span> recommended (click a pin to select) &nbsp; <span style="color:#94A3B8;font-weight:700">●</span> other partners</div>')
    sel = next((r for r in res if r["name"] == st.session_state.get("rd_selected")), None)
    if sel:
        with panel():
            show(_card_head("3 · Confirm", "Record this donation in your log and keep the contact details"))
            a, b = st.columns([2.2, 1], vertical_alignment="center")
            with a:
                show(kv([("Partner", f'<b>{esc(sel["name"])}</b>'), ("Phone", esc(sel["phone"] or "not listed")), ("Address", esc(sel["address"] or "not listed")),
                         ("Trip", f'{sel["distance_km"]} km · about {sel["eta_min"]} min ({sel["route_source"]})')]))
            with b:
                if st.button("Confirm donation plan", type="primary", key="rd_confirm", width="stretch"):
                    token = (q.get("qid"), sel["name"])
                    if st.session_state.get("rd_logged") != token:           # never record the same batch for the same partner twice
                        impact.log_donation({"date": datetime.now().date().isoformat(), "item": q["item"], "food_type": q["ftype"], "qty_kg": q["qty"], "partner": sel["name"]}, C.DONATION_LOG)
                        st.session_state["rd_logged"] = token
                    donation_dialog({"partner": sel["name"], "phone": sel["phone"], "item": q["item"], "qty": q["qty"], "distance_km": sel["distance_km"], "eta_min": sel["eta_min"],
                                     "safe_until": f"{sa:%d %b, %H:%M}", "directions": sel["maps_url"]})
    if res:
        import pandas as pd
        exp = pd.DataFrame([{k2: r[k2] for k2 in ("name", "type", "area", "distance_km", "eta_min", "spare_min", "phone", "email", "website", "address", "maps_url")} for r in res])
        st.download_button("Download these recipients (CSV)", exp.to_csv(index=False), "recipients.csv", "text/csv", key="rd_dl")
    if rej:
        with st.expander(f"Why {len(rej)} partner(s) were excluded"):
            for name, why in rej:
                st.write(f"- {name}: {why}")
    _reuse(q["ftype"], left, q["chilled"], expanded=(not res))

def _reuse(ftype, left, chilled, expanded=False):
    ideas = repurposer.suggest(ftype, left, chilled)
    if ideas["message"]:                       # safety message is always visible (an expander can stay collapsed from an earlier run)
        show('<div style="height:8px"></div>' + note("Do not serve", esc(ideas["message"]), "bad", "circle-alert"))
    label = "Prefer to reuse it in your own kitchen? Second-life ideas" if ideas["safe_for_people"] else "Disposal options"
    with st.expander(label, expanded=expanded and bool(ideas["ideas"])):
        for i in ideas["ideas"]:
            show(f'<div style="margin:6px 0"><b>{esc(i["idea"])}</b><div class="zw-mini">{esc(i["note"])}</div></div>')
        if ideas["safe_for_people"] and not ideas["ideas"]:
            st.caption("No reuse idea fits this food in the time left; donating is the better option.")
        if not ideas["safe_for_people"]:
            st.caption("Past its safe window: compost or send to biogas (non-meat only).")

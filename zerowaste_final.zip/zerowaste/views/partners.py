"""Partner directory: searchable table, colour-coded interactive map, details panel with directions."""
import pandas as pd
import streamlit as st
from services.ngo_matcher import haversine_km, SURPLUS_LABEL
from services.links import google_directions_url, google_place_url, osm_url
from ui import ctx, shell
from services.ngo_matcher import _txt as txt
from ui.kit import show, kpi_card, table, pill, esc, icon, kv, note, empty, panel
from ui.maps import directory_map, render_map
from views.dashboard import _card_head

LEVEL = {"yes": ("Confirmed", "green"), "likely": ("Reported", "amber"), "unconfirmed": ("Not confirmed", "gray")}

def render():
    p = ctx.partners().copy(); k = ctx.kitchen()
    shell.header("Partners", "Food banks, community kitchens, shelters and NGOs in Bengaluru that can receive surplus food")
    p["km"] = [haversine_km(k["lat"], k["lon"], a, b) if pd.notna(a) and pd.notna(b) else None for a, b in zip(p["latitude"], p["longitude"])]
    c = st.columns(4, gap="medium")
    with c[0]: show(kpi_card("Partners", str(len(p)), "building-2", "green", sub="from your research file", delay=0))
    with c[1]: show(kpi_card("With a location", str(int(p.latitude.notna().sum())), "map-pin", "blue", sub=f'{int(p.latitude.isna().sum())} without an address', delay=60))
    with c[2]: show(kpi_card("Confirmed intake", str(int((p.accepts_surplus == "yes").sum())), "shield-check", "green", sub="publicly accept surplus food", delay=120))
    with c[3]: show(kpi_card("Reported partners", str(int((p.accepts_surplus == "likely").sum())), "badge-check", "amber", sub="redistribution partners, rules unclear", delay=180))
    st.write("")
    with panel():
        f = st.columns([1.6, 2.6, 1.2, 1.2], gap="medium", vertical_alignment="bottom")
        search = f[0].text_input("Search", placeholder="Name, area or type…", key="dir_search")
        ctx.ensure("dir_level", "All")
        st.session_state.setdefault("dir_level", "All")
        level = f[1].segmented_control("Surplus intake", ["All", "Confirmed", "Reported", "Not confirmed"], key="dir_level") or "All"
        sort = f[2].selectbox("Sort by", ["Nearest", "Name"], key="dir_sort")
        loc_only = f[3].toggle("Only with location", key="dir_loc")
    d = p
    if search.strip():
        s = search.strip().lower(); d = d[d.apply(lambda r: s in f"{r['name']} {r['area']} {r['type']}".lower(), axis=1)]
    if level != "All":
        want = {"Confirmed": "yes", "Reported": "likely", "Not confirmed": "unconfirmed"}[level]; d = d[d.accepts_surplus == want]
    if loc_only:
        d = d[d.latitude.notna()]
    d = d.sort_values("km", na_position="last") if sort == "Nearest" else d.sort_values("name")
    if d.empty:
        show(empty("search", "No partners match", "Clear the search or change the filter.")); return
    names = list(d["name"])
    focus = st.session_state.pop("dir_focus", None)
    if focus in names:
        st.session_state["dir_selected"] = focus
    if st.session_state.get("dir_selected") not in names:
        st.session_state["dir_selected"] = names[0]
    l, r = st.columns([1.5, 1], gap="medium")
    with l:
        with panel():
            show(_card_head(f"{len(d)} partner(s)", "Nearest first uses straight-line distance from your kitchen"))
            rows = []
            for x in d.itertuples():
                lab, tone = LEVEL[x.accepts_surplus]
                rows.append([f'<span class="name">{esc(x.name)}</span><div class="zw-mini">{esc(txt(x.area) or "Bengaluru")} · {esc(txt(x.type))}</div>', esc(txt(x.phone) or "–"),
                             ("–" if x.km is None or pd.isna(x.km) else f"{x.km:.1f} km"), pill(lab, tone, dot=True)])
            show(table(["Partner", "Phone", "Distance", "Intake"], rows, ["", "", "num", ""], delay_step=15))
    with r:
        pts = [{"name": x.name, "lat": float(x.latitude), "lon": float(x.longitude), "phone": x.phone, "sub": f"{x.area} · {x.type}", "level": x.accepts_surplus}
               for x in d.dropna(subset=["latitude"]).itertuples()]
        out = render_map(directory_map(k, pts, st.session_state.get("dir_selected")), key="dir_map", height=460)
        hit = ctx.consume("dir_map_tip", out["tooltip"])
        if hit in names and hit != st.session_state.get("dir_selected"):
            st.session_state["dir_selected"] = hit; st.rerun()
        show('<div class="zw-mini" style="margin-top:6px"><span style="color:#16A34A;font-weight:700">●</span> confirmed &nbsp; <span style="color:#F59E0B;font-weight:700">●</span> reported &nbsp; <span style="color:#94A3B8;font-weight:700">●</span> not confirmed &nbsp; <span style="color:#EF4444;font-weight:700">●</span> your kitchen. Click a pin for details.</div>')
    st.selectbox("Show full details for", names, key="dir_selected")
    x = d[d["name"] == st.session_state["dir_selected"]].iloc[0]
    lab, tone = LEVEL[x["accepts_surplus"]]
    with panel():
        a, b = st.columns([2.3, 1], gap="medium")
        with a:
            show(f'<div style="font-size:1.15rem;font-weight:800">{esc(x["name"])}</div><div class="zw-sub" style="margin-bottom:10px">{esc(x["type"])} {pill(lab, tone, dot=True)}</div>'
                 + kv([("Phone", esc(txt(x["phone"]) or "not listed")), ("Email", esc(txt(x["email"]) or "not listed")), ("Website", esc(txt(x["website"]) or "not listed")),
                       ("Address", esc(txt(x["address"]) or "not listed")), ("Cooked food", esc(txt(x["accepts_cooked"]) or "–")), ("Pickup", esc(txt(x["pickup"]) or "–")),
                       ("Non-veg", esc(txt(x["accepts_nonveg"]) or "–")), ("Location quality", esc(x["coord_quality"] or "–"))]))
            if str(x["cooked_note"]).strip() and str(x["cooked_note"]) != "nan":
                show(f'<div class="zw-mini" style="margin-top:8px">Cooked food: {esc(x["cooked_note"])}</div>')
        with b:
            if pd.notna(x["latitude"]):
                st.link_button("Directions", google_directions_url(k["lat"], k["lon"], x["latitude"], x["longitude"]), width="stretch")
                st.link_button("Open in Google Maps", google_place_url(x["latitude"], x["longitude"]), width="stretch")
                st.link_button("OpenStreetMap", osm_url(x["latitude"], x["longitude"]), width="stretch")
            else:
                show(note("No location on file", "Phone this partner to ask where to deliver.", "warn", "triangle-alert"))
            if str(x["source_url"]).strip() and str(x["source_url"]) != "nan":
                st.link_button("Source", str(x["source_url"]), width="stretch")

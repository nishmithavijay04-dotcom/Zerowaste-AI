"""Forecast & Risk: (1) expected waste per meal from the canteen log (honestly backtested),
(2) batch / event waste-risk predictor from the event dataset (cross-validated model)."""
from datetime import timedelta
import pandas as pd
import streamlit as st
import config as C
from services import wastelog as W
from services.event_model import LABELS, CATS
from ui import ctx, shell
from ui.kit import show, kpi_card, table, pill, note, money, esc, icon, panel
from ui import charts as ch
from views.dashboard import CAT_COLORS, _card_head

DEFAULT = {"food_type": "Meat", "event_type": "Wedding", "storage": "Refrigerated", "purchase_history": "Regular", "seasonality": "Summer",
           "prep_method": "Buffet", "location": "Urban", "pricing": "Moderate", "guests": 300, "quantity": 400}

def _tab_expected():
    df = ctx.waste()
    last = df["date"].max()
    c1, c2 = st.columns([1.4, 1], gap="medium", vertical_alignment="bottom")
    ctx.ensure("fx_meal", "Lunch"); ctx.ensure("fx_day", last.date() + timedelta(days=1))
    st.session_state.setdefault("fx_meal", "Lunch")
    meal = c1.segmented_control("Meal", W.MEAL_ORDER, key="fx_meal") or "Lunch"
    day = c2.date_input("Day to plan", key="fx_day")
    e = W.expected_waste(df, meal); bt = W.backtest_expected(df)
    price = W.category_prices(df)
    exp_cost = sum(r["cost"] for r in e["by_category"])
    c = st.columns(4, gap="medium")
    with c[0]: show(kpi_card(f"Expected {meal.lower()} waste", f'{e["mean"]:.1f}', "scale", "green", unit="kg", sub=f'80% range <b>{e["p10"]:.0f}–{e["p90"]:.0f} kg</b>', delay=0))
    with c[1]: show(kpi_card("Expected cost", money(exp_cost, 0), "wallet", "amber", sub=f'for <b>{day:%A %d %b}</b>', delay=60))
    with c[2]: show(kpi_card("Typical day-to-day swing", f'±{e["sd"]:.1f}', "activity", "violet", unit="kg", sub=f'from <b>{e["days"]}</b> logged days', delay=120))
    with c[3]: show(kpi_card("Interval hit-rate (backtest)", f'{100 * bt["coverage_80"]:.0f}', "target", "blue", unit="%", sub=f'target 80% · {bt["n"]} predictions', delay=180))
    st.write("")
    l, r = st.columns([1.2, 1], gap="medium")
    with l:
        with panel():
            show(_card_head("Expected leftover by food category", f"Average per {meal.lower()} (kg and cost)"))
            rows = [[pill(x["category"], "gray"), f'{x["kg"]:.1f} kg', money(x["cost"], 2),
                     f'<div style="width:140px"><div class="zw-progress"><i style="width:{100 * x["kg"] / e["mean"]:.0f}%"></i></div></div>'] for x in sorted(e["by_category"], key=lambda z: -z["kg"])]
            show(table(["Category", "Expected", "Cost", "Share"], rows, ["", "num", "num", ""]))
            show(f'<div class="zw-mini" style="margin-top:10px">Use this to line up partners before service: about <b>{e["mean"]:.0f} kg</b> of {meal.lower()} waste is typical, and almost any category can contribute.</div>')
    with r:
        with panel():
            show(_card_head("How good is this forecast?", f"Backtest on the last {bt['days']} days: each day predicted using only earlier days"))
            rows = [["Average of all earlier days (used here)", f'{bt["mae_mean"]:.2f} kg', pill("Best", "green", dot=True) if bt["best"] == "mean" else ""],
                    ["Same weekday last week", f'{bt["mae_last_week"]:.2f} kg', pill("Best", "green", dot=True) if bt["best"] == "last_week" else ""],
                    ["Yesterday", f'{bt["mae_yesterday"]:.2f} kg', pill("Best", "green", dot=True) if bt["best"] == "yesterday" else ""]]
            show(table(["Method", "Avg error (MAE)", ""], rows, ["", "num", ""]))
            verdict = {"mean": "The plain average is the most accurate predictor available, so that is what the app uses. Meals, weekdays and sections carry no extra signal in this log (see the Patterns tab).",
                       "last_week": "Last week's value did best in this backtest.", "yesterday": "Yesterday's value did best in this backtest."}[bt["best"]]
            show('<div style="height:10px"></div>' + note("Honest result", verdict, "info", "lightbulb"))

def _tab_risk():
    m = ctx.event_model(); o = m.options
    for key, k in (("rk_food_type", "food_type"), ("rk_event_type", "event_type"), ("rk_guests", "guests"), ("rk_quantity", "quantity"), ("rk_prep", "prep_method"),
                   ("rk_storage", "storage"), ("rk_purchase", "purchase_history"), ("rk_pricing", "pricing"), ("rk_season", "seasonality"), ("rk_location", "location")):
        ctx.ensure(key, DEFAULT[k])
    inp = {}
    l, r = st.columns([1, 1.45], gap="medium")
    with l:
        with panel():
            show(_card_head("Describe the batch or event", "Predicts waste before it happens"))
            a, b = st.columns(2)
            inp["food_type"] = a.selectbox(LABELS["food_type"], o["food_type"], key="rk_food_type")
            inp["event_type"] = b.selectbox(LABELS["event_type"], o["event_type"], key="rk_event_type")
            a, b = st.columns(2)
            inp["guests"] = a.number_input(LABELS["guests"], min_value=o["guests"][0], max_value=o["guests"][1] * 2, step=10, key="rk_guests")
            inp["quantity"] = b.number_input("Quantity prepared (units)", min_value=o["quantity"][0], max_value=o["quantity"][1] * 2, step=10, key="rk_quantity")
            a, b = st.columns(2)
            inp["prep_method"] = a.selectbox(LABELS["prep_method"], o["prep_method"], key="rk_prep")
            inp["storage"] = b.selectbox(LABELS["storage"], o["storage"], key="rk_storage")
            a, b = st.columns(2)
            inp["purchase_history"] = a.selectbox(LABELS["purchase_history"], o["purchase_history"], key="rk_purchase")
            inp["pricing"] = b.selectbox(LABELS["pricing"], o["pricing"], key="rk_pricing")
            a, b = st.columns(2)
            inp["seasonality"] = a.selectbox(LABELS["seasonality"], o["seasonality"], key="rk_season")
            inp["location"] = b.selectbox(LABELS["location"], o["location"], key="rk_location")
            show('<div class="zw-mini">Quantity and waste use the dataset\'s own units (treated as kg here).</div>')
    p = m.predict(inp)
    tone = {"Low": "green", "Typical": "amber", "High": "red"}[p["risk"]]
    with r:
        with panel():
            show(_card_head("Predicted waste", "Model trained on your event records, with an 80% range"))
            g1, g2 = st.columns([1, 1], vertical_alignment="center")
            with g1:
                show(ch.gauge(p["percentile"], f'{p["risk"]} risk', f'{p["percentile"]:.0f}th percentile'))
            with g2:
                show(f'<div style="font-size:2.4rem;font-weight:800;letter-spacing:-.03em;line-height:1">{p["waste"]:.1f}<span style="font-size:1rem;color:#5E6F66;font-weight:600"> units</span></div>'
                     f'<div class="zw-sub" style="margin:4px 0 10px">likely between <b>{p["low"]:.1f}</b> and <b>{p["high"]:.1f}</b></div>'
                     f'{pill(f"{p["pct"]:.1f}% of quantity", tone, dot=True)} <span class="zw-mini">dataset average {p["dataset_mean_pct"]:.1f}%</span>')
        with panel():
            show(_card_head("What you can change", "Compared with similar events in your data (same pricing tier), tested for significance"))
            best = m.best_levers(inp)
            if len(best):
                rows = [[esc(x.label), f'{esc(x.current)} → <b>{esc(x.alternative)}</b>', f'{x.pct_current:.1f}% → {x.pct_alt:.1f}%', f'<b style="color:#15803D">-{x.saving:.1f} units</b>',
                         f'<span class="zw-mini">{x.n_current} vs {x.n_alt} events</span>'] for x in best.itertuples()]
                show(table(["Lever", "Change", "Waste % of quantity", "Saves", "Evidence"], rows, ["", "", "num", "num", ""]))
            else:
                show(note("No lever helps meaningfully", "Among similar events, changing preparation, storage or purchasing did not reduce waste by a statistically reliable amount for this batch.", "info", "info"))
        with panel():
            show(_card_head("What drives waste in this data", "Share of the model's decisions that depend on each factor"))
            imp = list(m.metrics["importance"].items())[:5]
            show(ch.hbar_list([(LABELS.get(k, k), v * 100) for k, v in imp], "%"))
    c1, c2 = st.columns([3, 1.4], vertical_alignment="center")
    c1.caption(f"Expected surplus to plan for: about {p['waste']:.0f} units of {inp['food_type'].lower()}.")
    if c2.button("Plan redistribution for this surplus →", type="primary", key="rk_plan", width="stretch"):
        ftype, veg = C.EVENT_FOOD_MAP[inp["food_type"]]
        st.session_state["prefill"] = {"source": "risk", "item": f"{inp['food_type']} from {inp['event_type'].lower()}", "qty": round(float(p["waste"]), 1),
                                       "ftype": ftype, "veg": veg}
        ctx.go("redistribute")
    with st.expander("Model card: how accurate is this?"):
        mt = m.metrics
        cc = st.columns(4)
        cc[0].metric("Average error (MAE)", f'{mt["mae"]:.2f} units', help="Cross-validated")
        cc[1].metric("Guessing the average", f'{mt["mae_baseline_mean"]:.2f} units')
        cc[2].metric("Explained variance (R²)", f'{mt["r2"]:.2f}')
        cc[3].metric("80% range hit-rate", f'{100 * mt["coverage_80"]:.0f}%')
        st.caption(f'Random Forest on {mt["rows"]:,} unique events ({mt["duplicates_removed"]} exact duplicate rows removed), {mt["cv"]} cross-validation. '
                   "In this dataset the pricing tier and event size drive waste most; the effect of preparation method is small, and storage or purchase history have almost none.")

def render():
    shell.header("Forecast & Risk", "Plan ahead: expected waste per meal and the waste risk of a batch or event")
    t1, t2 = st.tabs(["Expected waste by meal", "Batch & event risk"])
    with t1:
        _tab_expected()
    with t2:
        _tab_risk()

"""Waste Log: filters, KPIs, category / meal / weekday analytics, financial view, honest pattern tests, entries table."""
import pandas as pd
import streamlit as st
from services import wastelog as W
from ui import ctx, shell, dialogs
from ui.kit import fmt_p, show, kpi_card, table, pill, delta, note, money, esc, empty, panel
from ui import charts as ch
from views.dashboard import CAT_COLORS, _card_head

def filtered():
    df = ctx.waste()
    with panel():
        c = st.columns([1.2, 1.2, 1.2, 1.8], gap="medium")
        lo, hi = df["date"].min().date(), df["date"].max().date()
        ctx.ensure("wl_meal", list(W.MEAL_ORDER)); ctx.ensure("wl_section", sorted(df["section"].unique())); ctx.ensure("wl_cat", sorted(df["category"].unique())); ctx.ensure("wl_range", (lo, hi))
        meals = c[0].multiselect("Meal", W.MEAL_ORDER, key="wl_meal")
        secs = c[1].multiselect("Section", sorted(df["section"].unique()), key="wl_section")
        cats = c[2].multiselect("Food category", sorted(df["category"].unique()), key="wl_cat")
        rng = c[3].date_input("Date range", min_value=lo, max_value=hi, key="wl_range")
    if not isinstance(rng, (tuple, list)) or len(rng) != 2:
        rng = (lo, hi)
    out = df[df["meal"].isin(meals) & df["section"].isin(secs) & df["category"].isin(cats)
             & (df["date"] >= pd.Timestamp(rng[0])) & (df["date"] <= pd.Timestamp(rng[1]))]
    return df, out

def render():
    shell.header("Waste Log", "Explore the canteen waste log: what is wasted, when, and what it costs")
    a1, a2, a3 = st.columns([8, 1.6, 1.6])
    full, df = filtered()
    if a3.button("＋ Log waste", type="primary", key="wl_log", width="stretch"):
        dialogs.log_waste()
    if df.empty:
        show(empty("funnel", "No entries match these filters", "Widen the date range or select more meals, sections or categories."))
        return
    a2.download_button("Export CSV", df.to_csv(index=False), "waste_log_filtered.csv", "text/csv", key="wl_export", width="stretch")

    tabs = st.tabs(["Overview", "Financial impact", "Patterns", "Entries"])
    daily = df.groupby("date")["weight_kg"].sum()
    with tabs[0]:
        peak = daily.idxmax()
        c = st.columns(4, gap="medium")
        with c[0]: show(kpi_card("Total waste", f'{df.weight_kg.sum():,.1f}', "scale", "green", unit="kg", sub=f'across <b>{df.date.nunique()}</b> days', delay=0))
        with c[1]: show(kpi_card("Entries logged", f'{len(df):,}', "clipboard-list", "blue", sub=f'<b>{df.groupby("section").ngroups}</b> sections · <b>{df.category.nunique()}</b> categories', delay=60))
        with c[2]: show(kpi_card("Average per entry", f'{df.weight_kg.mean():.2f}', "gauge", "violet", unit="kg", sub=f'range <b>{df.weight_kg.min():.1f}–{df.weight_kg.max():.1f} kg</b>', delay=120))
        with c[3]: show(kpi_card("Peak day", f'{daily.max():,.1f}', "flame", "red", unit="kg", sub=f'on <b>{peak:%a %d %b %Y}</b>', delay=180))
        st.write("")
        l, r = st.columns([1.15, 1], gap="medium")
        with l:
            with panel():
                show(_card_head("Top categories wasted", "Total kg in the selected period"))
                bc = W.by_category(df)
                show(ch.bar_chart([(x.category, x.kg) for x in bc.itertuples()], uid="wlcat"))
        with r:
            with panel():
                show(_card_head("Category vs previous period", "Last 7 logged days vs the 7 before"))
                show(ch.hbar_compare(W.compare_by(df, "category"), "kg", cur_label="Last 7 days", prev_label="Previous 7 days"))
        with panel():
            show(_card_head("When is the most food wasted?", "Average total waste per day (kg) by weekday and meal. Darker = more waste."))
            hm = W.heatmap(df)
            show(ch.heatmap(list(hm.index), list(hm.columns), [[None if pd.isna(v) else float(v) for v in row] for row in hm.values], " kg"))
            show('<div class="zw-mini" style="margin-top:10px">Tip: check the Patterns tab to see whether these differences are statistically real.</div>')
    with tabs[1]:
        bc = W.by_category(df); tot = df.cost.sum()
        c = st.columns(4, gap="medium")
        with c[0]: show(kpi_card("Total cost lost", money(tot, 0), "wallet", "amber", sub="at the prices in your dataset", delay=0))
        with c[1]: show(kpi_card("Average cost per kg", money(tot / df.weight_kg.sum(), 2), "scale", "green", sub="weight-weighted", delay=60))
        top = bc.sort_values("cost", ascending=False).iloc[0]
        with c[2]: show(kpi_card("Costliest category", esc(top.category), "flame", "red", sub=f'<b>{money(top.cost, 0)}</b> · {100 * top.cost / tot:.0f}% of cost', delay=120))
        with c[3]: show(kpi_card("Average cost per day", money(df.groupby("date").cost.sum().mean(), 0), "calendar", "blue", delay=180))
        st.write("")
        l, r = st.columns([1, 1.2], gap="medium")
        with l:
            with panel():
                show(_card_head("Cost by category"))
                show(ch.donut([(x.category, x.cost, CAT_COLORS.get(x.category, "#94A3B8")) for x in bc.itertuples()], money(tot, 0), "total cost", uid="wlcost", size=170))
        with r:
            with panel():
                show(_card_head("Weekly cost lost", "Hover a bar for the exact value"))
                wk = df.groupby(df["date"].dt.to_period("W").dt.start_time)["cost"].sum()
                show(ch.bar_chart([(d.strftime("%d %b"), float(v)) for d, v in wk.items()], uid="wlwk", unit="$"))
        show(note("Prices", "The dataset gives a price per kg for each category but does not state a currency (the values look like US dollars per kg).", "info", "info"))
    with tabs[2]:
        t = W.factor_tests(df); dist = W.distribution_check(df)
        with panel():
            show(_card_head("Is any pattern real?", "ANOVA / Kruskal-Wallis tests with Holm correction for testing 4 factors at once"))
            rows = [[f'<span class="name">{esc(r.factor)}</span>', str(r.groups), esc(r.lowest), esc(r.highest), f"{r.spread_pct:.1f}%", fmt_p(r.p_anova), fmt_p(r.p_holm), f"{100 * r.eta2:.2f}%",
                     pill(r.verdict, "green" if r.verdict == "Real difference" else "gray", dot=True)] for r in t.itertuples()]
            show(table(["Factor", "Groups", "Lowest avg", "Highest avg", "Spread", "p (raw)", "p (adjusted)", "Variance explained", "Verdict"], rows, ["", "num", "", "", "num", "num", "num", "num", ""]))
        l, r = st.columns(2, gap="medium")
        with l:
            show(note("How to read this", "A difference only counts as real if it passes the corrected test AND explains at least 1% of the variation. Otherwise it is the kind of random wobble you would see even if every meal wasted the same.", "info", "lightbulb"))
        with r:
            real = int((t["verdict"] == "Real difference").sum())
            show(note("What it means for this log", ("Waste per entry is statistically similar across meals, sections, categories and weekdays. There is no hotspot to target: reduce waste everywhere (portions, batch sizes) and send leftovers to partners." if not real else f"{real} factor(s) show real differences: focus there first."), "good" if real else "warn", "sparkles"))
        show(f'<div class="zw-mini" style="margin-top:8px">Each entry weighs between {dist["min"]:.1f} and {dist["max"]:.1f} kg and is spread almost evenly across that range (uniformity test p = {dist["ks_p_uniform"]:.2f}). Daily totals average {dist["daily_mean"]:.1f} kg (±{dist["daily_sd"]:.1f}); yesterday explains almost nothing about today (autocorrelation {dist["lag1_autocorr"]:.2f}).</div>')
    with tabs[3]:
        bands = W.weight_bands(full)
        q = st.text_input("Search entries", placeholder="Filter by category, section or meal…", key="wl_search", label_visibility="collapsed")
        d = df.sort_values("date", ascending=False, kind="stable")
        if q.strip():
            s = q.strip().lower(); d = d[d.apply(lambda r: s in f"{r['meal']} {r['section']} {r['category']}".lower(), axis=1)]
        ctx.ensure("wl_rows", 50)
        n = st.select_slider("Rows shown", [25, 50, 100, 200], key="wl_rows")
        rows = [[f"{r.date:%d %b %Y}", esc(r.meal), f"Section {esc(r.section)}", pill(r.category, "gray"), f"{r.weight_kg:.2f} kg", money(r.price_per_kg, 2), money(r.cost, 2),
                 pill(W.band(r.weight_kg, bands), {"High": "red", "Medium": "amber", "Low": "green"}[W.band(r.weight_kg, bands)], dot=True)] for r in d.head(n).itertuples()]
        show(table(["Date", "Meal", "Section", "Category", "Weight", "Price/kg", "Cost", "Band"], rows, ["", "", "", "", "num", "num", "num", ""]))
        st.caption(f"{min(n, len(d))} of {len(d):,} matching entries. Band = lowest / middle / highest third of all entry weights.")

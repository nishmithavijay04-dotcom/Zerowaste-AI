"""Menu Planner: stock with expiry status, optimizer-built menu, reasons, shopping list and cooking guide."""
import pandas as pd
import streamlit as st
import config as C
from services.menu_optimizer import plan_menu
from services.recipes import load_inventory
from services.scaler import cooking_guide
from ui import ctx, shell
from ui.kit import show, kpi_card, table, pill, note, money, esc, icon, empty, panel
from views.dashboard import _card_head

def _sample():
    return pd.read_csv(C.INVENTORY_SAMPLE)

def _status(q, d):
    if q <= 0: return pill("Out of stock", "gray", dot=True)
    if d < 0: return pill("Expired", "red", dot=True)
    if d <= C.NEAR_EXPIRY_DAYS: return pill("Expiring soon", "amber", dot=True)
    return pill("Good", "green", dot=True)

def _guide_text(plan, guide):
    out = [f"{plan['meal']} for {plan['servings']} servings", ""]
    for g in guide:
        out += [f"== {g['name']} ({g['category']}) - {g['servings']} servings ==", g["note"], "Ingredients (total / per batch):"]
        out += [f"  {i['item']}: {i['kg']} kg / {i['per_batch_kg']} kg" for i in g["ingredients"]]
        out += ["Steps:"] + [f"  {n}. {s}" for n, s in enumerate(g["steps"], 1)] + [""]
    return "\n".join(out)

def render():
    cat = ctx.catalog()
    shell.header("Menu Planner", "Turn the stock in your store room into a menu that uses near-expiry food first")
    inv_df = st.session_state.setdefault("inventory_df", _sample())
    inv_df = st.session_state["inventory_df"]
    stock = inv_df.copy(); stock["quantity_kg"] = pd.to_numeric(stock["quantity_kg"], errors="coerce").fillna(0); stock["days_to_expiry"] = pd.to_numeric(stock["days_to_expiry"], errors="coerce").fillna(9999)
    n_items = int((stock["quantity_kg"] > 0).sum()); n_soon = int(((stock["days_to_expiry"] >= 0) & (stock["days_to_expiry"] <= C.NEAR_EXPIRY_DAYS) & (stock["quantity_kg"] > 0)).sum())
    n_exp = int(((stock["days_to_expiry"] < 0) & (stock["quantity_kg"] > 0)).sum()); n_out = int((stock["quantity_kg"] <= 0).sum())
    c = st.columns(4, gap="medium")
    with c[0]: show(kpi_card("Items in stock", str(n_items), "package", "green", sub=f'<b>{stock.quantity_kg.sum():,.0f} kg</b> in total', delay=0))
    with c[1]: show(kpi_card("Expiring soon", str(n_soon), "clock", "amber", sub=f'within <b>{C.NEAR_EXPIRY_DAYS} days</b>', delay=60))
    with c[2]: show(kpi_card("Expired", str(n_exp), "circle-alert", "red", sub="ignored by the planner", delay=120))
    with c[3]: show(kpi_card("Out of stock", str(n_out), "x", "gray", sub="will be bought if needed", delay=180))
    st.write("")

    l, r = st.columns([1.5, 1], gap="medium")
    with l:
        with panel():
            show(_card_head("Stock overview", "Status is based on days to expiry from the cooking day"))
            rows = [[f'<span class="name">{esc(x.item.title())}</span>', f"{x.quantity_kg:,.1f} kg", ("–" if x.days_to_expiry > 9000 else f"{x.days_to_expiry:.0f} d"), _status(x.quantity_kg, x.days_to_expiry)]
                    for x in stock.sort_values("days_to_expiry").itertuples()]
            show(table(["Item", "Quantity", "Days left", "Status"], rows, ["", "num", "num", ""], delay_step=15))
    with r:
        with panel():
            show(_card_head("Plan the meal"))
            S = ctx.settings()
            ctx.ensure("pl_meal", "Lunch"); ctx.ensure("pl_nonveg", True); ctx.ensure("pl_pots", int(S["pots"])); ctx.ensure("pl_staff", int(S["staff"]))
            ctx.ensure("pl_window", int(S["window_min"])); ctx.ensure("pl_veg", int(S["veg_target"]))
            st.session_state.setdefault("pl_meal", "Lunch")
            meal = st.segmented_control("Meal", C.MEALS, key="pl_meal") or "Lunch"
            ctx.ensure(f"pl_servings_{meal}", int(S["headcount"]))
            servings = st.number_input("Servings to cook", min_value=20, max_value=20000, step=10, key=f"pl_servings_{meal}")
            nonveg = st.toggle("Include non-veg dishes", key="pl_nonveg")
            with st.expander("Kitchen limits"):
                k1, k2 = st.columns(2)
                pots = k1.number_input("Pots / vessels", min_value=1, max_value=50, key="pl_pots")
                staff = k2.number_input("Cooks available", min_value=1, max_value=50, key="pl_staff")
                window = k1.number_input("Cooking window (min)", min_value=30, max_value=600, step=15, key="pl_window")
                veg = k2.slider("Min veg share %", 0, 100, key="pl_veg")
            go = st.button("Plan menu", type="primary", key="pl_go", width="stretch")
    with st.expander("Edit stock (quantities, expiry days, add or remove rows)"):
        edited = st.data_editor(inv_df, num_rows="dynamic", key="pl_inventory", hide_index=True, width="stretch",
                                column_config={"item": st.column_config.SelectboxColumn("Item", options=sorted(cat.prices), required=True),
                                               "quantity_kg": st.column_config.NumberColumn("Quantity (kg)", min_value=0.0),
                                               "days_to_expiry": st.column_config.NumberColumn("Days to expiry", step=1)})
        if st.button("Apply changes to stock", key="pl_apply"):
            st.session_state["inventory_df"] = edited; st.rerun()
        if st.button("Reset to sample stock", key="pl_reset"):
            st.session_state["inventory_df"] = _sample(); st.rerun()

    if go:
        try:
            inv, notes = load_inventory(edited, cat)
            plan = plan_menu(cat, inv, meal, int(servings), kitchen={"pots": int(pots), "staff": int(staff), "window_min": int(window), "veg_target": veg / 100}, allow_nonveg=nonveg)
            plan["notes"] = notes
            st.session_state["plan"] = plan
        except ValueError as e:
            st.session_state.pop("plan", None); st.error(f"Check your stock table: {e}")
    plan = st.session_state.get("plan")
    if not plan:
        show(empty("chef-hat", "No menu yet", "Set the meal and servings, then press <b>Plan menu</b>. The planner covers demand exactly, uses near-expiry stock first and buys as little as possible."))
        return
    if plan["status"] == "infeasible":
        st.error(f"No valid menu found: {plan['reason']}"); return
    t = plan["totals"]
    st.write("")
    show(f'<div class="zw-note good"><span class="zw-ico green">{icon("circle-check")}</span><div><b>Menu ready: {plan["servings"]} servings of {esc(plan["meal"].lower())}</b>'
         f'<p>{t["dishes"]} dishes · {t["batches"]} batches · uses {plan["near_expiry"]["pct_used"]:.0f}% of your near-expiry stock.</p></div></div>')
    st.write("")
    c = st.columns(4, gap="medium")
    with c[0]: show(kpi_card("To buy", money(t["buy_cost"], 0).replace("&#36;", "₹"), "wallet", "amber", sub="approximate Indian wholesale prices", delay=0))
    with c[1]: show(kpi_card("Near-expiry stock used", f'{plan["near_expiry"]["pct_used"]:.0f}', "leaf", "green", unit="%", sub=f'<b>{plan["near_expiry"]["used_kg"]:.1f}</b> of {plan["near_expiry"]["stock_kg"]:.1f} kg', delay=60))
    with c[2]: show(kpi_card("Calories per plate", f'{t["kcal_per_plate"]:.0f}', "flame", "red", unit="kcal", delay=120))
    with c[3]: show(kpi_card("Protein per plate", f'{t["protein_per_plate"]:.1f}', "beef", "blue", unit="g", delay=180))
    for w in plan["warnings"]:
        show('<div style="height:8px"></div>' + note("Heads up", esc(w), "warn", "triangle-alert"))
    st.write("")
    a, b = st.columns([1.7, 1], gap="medium")
    with a:
        with panel():
            show(_card_head("The menu", "Servings and batches per dish"))
            tone = {"staple": "amber", "main": "green", "side": "violet"}
            rows = [[pill(d["category"].title(), tone[d["category"]]), f'<span class="name">{esc(d["name"])}</span>', f'{d["servings"]}', f'{d["batches"]}',
                     pill("Veg", "green") if d["veg"] else pill("Non-veg", "red"), f'{d["kcal"]:.0f} kcal · {d["protein_g"]:.0f} g']
                    for d in plan["menu"]]
            show(table(["Course", "Dish", "Servings", "Batches", "Diet", "Per serving"], rows, ["", "", "num", "num", "", ""]))
    with b:
        with panel():
            show(_card_head("Why this menu"))
            for e in plan["explanations"]:
                show(f'<div style="display:flex;gap:8px;margin:8px 0;font-size:.86rem"><span style="color:#16A34A;flex:none">{icon("check", 16, 3)}</span><span>{esc(e)}</span></div>')
    ing = plan["ingredients"]; shop = ing[ing["buy_kg"] > 0][["item", "buy_kg", "price_per_kg", "buy_cost"]]
    with panel():
        h1, h2 = st.columns([3, 1.2], vertical_alignment="center")
        with h1: show(_card_head("Shopping list", "What to buy on top of your stock"))
        if len(shop):
            h2.download_button("Download CSV", shop.to_csv(index=False), "shopping_list.csv", "text/csv", key="pl_dl_shop", width="stretch")
            show(table(["Item", "Buy (kg)", "₹ / kg", "Cost (₹)"], [[esc(x.item.title()), f"{x.buy_kg:,.2f}", f"{x.price_per_kg:,.0f}", f"{x.buy_cost:,.0f}"] for x in shop.itertuples()], ["", "num", "num", "num"]))
        else:
            show(note("Nothing to buy", "Your stock covers this whole menu.", "good", "circle-check"))
    with st.expander("All ingredients: need vs stock"):
        st.dataframe(ing, hide_index=True, width="stretch")
    guide = cooking_guide(plan, cat)
    show(_card_head("Cooking guide", "Scaled ingredients, batches and steps for each dish"))
    for g in guide:
        with st.expander(f"{g['name']}  ·  {g['servings']} servings  ·  {g['batches']} batch(es)"):
            st.write(g["note"])
            st.dataframe(pd.DataFrame(g["ingredients"]).rename(columns={"item": "Ingredient", "kg": "Total (kg)", "per_batch_kg": "Per batch (kg)"}), hide_index=True, width="stretch")
            for n, s in enumerate(g["steps"], 1):
                st.markdown(f"{n}. {s}")
    st.download_button("Download full cooking guide (text)", _guide_text(plan, guide), "cooking_guide.txt", "text/plain", key="pl_dl_guide")
